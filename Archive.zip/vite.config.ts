import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

export default defineConfig({
  plugins: [react()],
  // Relative asset paths: the built `dist/` folder works from any web root or sub-folder
  // (the app uses hash routing, so no server rewrite rules are needed).
  base: './',
  server: { port: 5180, strictPort: true },
  preview: { port: 4180 },
})
