# REO Control Tower — Asset Manager POC

A work-first "My Dashboard" for REO Asset Managers, rebuilt from the transcript feedback and the enhancement spec. See [UX_SPEC.md](UX_SPEC.md) for the critique of the current screens, the principles, the information architecture and the click paths.

## Run it

```bash
npm install
```

```bash
npm run dev
```

Open http://localhost:5180. Data is deterministic mock data for one AM book (236 files, 39 exceptions).

## Stack
- React 19 + TypeScript + Vite
- Three.js via @react-three/fiber + drei: low-poly property model (Property Cockpit) and 3D aging chart (Portfolio); "Your book" on Today is a 2D column chart (coral cap = needs attention)
- Card effects modelled on React Bits SpotlightCard / TiltedCard / AnimatedList (own implementation, no extra dependency)
- Framer Motion: Apple-style critically damped springs, scroll-linked hero parallax and camera, in-view reveals, shared-layout segmented controls, sheets that open from and return to their trigger
- Zustand for app state (work items move between queues as you act)

## Try these flows
| Flow | Where |
|---|---|
| Batch follow-up: "here are your 10 files, send?" | Today → any signal tile → **Send** (Undo in the toast) |
| Accept an investor-approved offer | Today → Act Today → **Accept & send contract** |
| Triage one exception | Click any queue row → Action Center panel (↑/↓ to move, Esc to close) |
| Rule-routed price change | Today → AI recommendations → List price reduction → **Modify**: drag to ≤ 5% and it writes to Equator directly; 5–8% routes to the investor |
| Investor approval package | Recommendation → **Route for approval** → **Send** |
| Filter by phase | Click a column in "Your book" |
| Market-aware decisions | Recommendations → any card → Review & decide (list price, reserve, plan amendment, buyer contract) |
| Data availability | AI Agents → bottom section, or any Recommendation Review |
| Paginated queue with search | My Work → `/` to search, page through results |
| Side-by-side recommendations | Recommendations → pick a card (↑/↓) to preview price ladder, offer net-to-seller or plan valuation |
| Command palette | ⌘K |
| Portfolio-wide view | Toolbar → **All · 2,759** |

## Structure
```
src/
  data/       mock portfolio, signals, templates, rules (rec.ts)
  lib/        store, hash router (with scroll restoration), motion presets
  components/ chrome (sidebar, toolbar, palette, toasts) + UI primitives
  features/   signal board, Act Today, queue, Action Center panel, batch + confirm sheets
  three/      HouseModel, AgingSkyline, DOM label projector
  pages/      Today, My Work, Properties, Property Cockpit, Recommendation, Approval, Agents, Portfolio
```

## Notes
- 3D scenes pause when off-screen and respect `prefers-reduced-motion`. Every 3D number is also shown as exact text (hover cards, labels, Table view).
- 3D labels use a small DOM projector (`three/overlay.tsx`) instead of drei `<Html>`, which conflicts with React 19 root handling.
- React StrictMode is off for the same reason (see `src/main.tsx`).
