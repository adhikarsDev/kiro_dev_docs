import { create } from 'zustand'
import { INITIAL_ITEMS, type Phase, type Queue, type SignalKey, type WorkItem } from '../data/mock'

export interface Toast {
  id: number
  title: string
  body?: string
  tone?: 'success' | 'info' | 'warn'
  undo?: () => void
}

interface BatchState {
  signal: SignalKey
  itemIds?: string[] // a subset (e.g. a single row from the Action Center)
  origin?: { x: number; y: number }
}

interface ConfirmState {
  kind: 'contract' | 'write' | 'approve'
  itemId?: string
  propertyId?: string
  payload?: Record<string, unknown>
  origin?: { x: number; y: number }
}

interface AppState {
  theme: 'light' | 'dark'
  toggleTheme: () => void
  scope: 'mine' | 'all'
  setScope: (s: 'mine' | 'all') => void

  items: WorkItem[]
  queueTab: Queue
  setQueueTab: (q: Queue) => void
  phaseFilter: Phase | 'all'
  setPhaseFilter: (p: Phase | 'all') => void

  selectedId: string | null
  select: (id: string | null) => void

  batch: BatchState | null
  openBatch: (b: BatchState) => void
  closeBatch: () => void

  confirm: ConfirmState | null
  openConfirm: (c: ConfirmState) => void
  closeConfirm: () => void

  paletteOpen: boolean
  setPaletteOpen: (v: boolean) => void

  /** Move items to a new queue with a status + note; returns an undo fn. */
  moveItems: (ids: string[], to: Queue | 'done', patch?: Partial<WorkItem>) => () => void
  addItem: (item: WorkItem) => void

  toasts: Toast[]
  toast: (t: Omit<Toast, 'id'>) => void
  dismissToast: (id: number) => void

  cleared: Partial<Record<SignalKey, { n: number; at: string }>>
  markCleared: (k: SignalKey, n: number) => void

  recDecision: Record<string, 'submitted' | 'routed' | 'rejected' | 'written'>
  setRecDecision: (pid: string, d: 'submitted' | 'routed' | 'rejected' | 'written') => void
}

let toastId = 0
const initialTheme = (document.documentElement.dataset.theme as 'light' | 'dark') || 'light'

export const nowLabel = () =>
  new Date(2026, 10, 3, 9, 50 + Math.floor((Date.now() / 60000) % 9)).toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' })

export const useApp = create<AppState>((set, get) => ({
  theme: initialTheme,
  toggleTheme: () => {
    const t = get().theme === 'dark' ? 'light' : 'dark'
    document.documentElement.classList.add('theme-anim')
    document.documentElement.dataset.theme = t
    try { localStorage.setItem('reo-theme', t) } catch { /* private mode */ }
    window.setTimeout(() => document.documentElement.classList.remove('theme-anim'), 450)
    set({ theme: t })
  },
  scope: 'mine',
  setScope: (scope) => set({ scope }),

  items: INITIAL_ITEMS,
  queueTab: 'exceptions',
  setQueueTab: (queueTab) => set({ queueTab }),
  phaseFilter: 'all',
  setPhaseFilter: (phaseFilter) => set({ phaseFilter }),

  selectedId: null,
  select: (selectedId) => set({ selectedId }),

  batch: null,
  openBatch: (batch) => set({ batch }),
  closeBatch: () => set({ batch: null }),

  confirm: null,
  openConfirm: (confirm) => set({ confirm }),
  closeConfirm: () => set({ confirm: null }),

  paletteOpen: false,
  setPaletteOpen: (paletteOpen) => set({ paletteOpen }),

  moveItems: (ids, to, patch) => {
    const before = get().items
    const next =
      to === 'done'
        ? before.filter((i) => !ids.includes(i.id))
        : before.map((i) => (ids.includes(i.id) ? { ...i, ...patch, queue: to, signal: patch?.signal ?? i.signal, approaching: false } : i))
    set({ items: next })
    if (get().selectedId && ids.includes(get().selectedId!)) set({ selectedId: null })
    return () => set({ items: before })
  },
  addItem: (item) => set({ items: [...get().items, item] }),

  toasts: [],
  toast: (t) => {
    const id = ++toastId
    set({ toasts: [...get().toasts, { ...t, id }] })
    window.setTimeout(() => get().dismissToast(id), t.undo ? 6500 : 4200)
  },
  dismissToast: (id) => set({ toasts: get().toasts.filter((x) => x.id !== id) }),

  cleared: {},
  markCleared: (k, n) => set({ cleared: { ...get().cleared, [k]: { n, at: nowLabel() } } }),

  recDecision: {},
  setRecDecision: (pid, d) => set({ recDecision: { ...get().recDecision, [pid]: d } }),
}))

// Follow the system appearance live, unless the user picked one with the toggle.
try {
  matchMedia('(prefers-color-scheme: dark)').addEventListener('change', (e) => {
    let pinned: string | null = null
    try { pinned = localStorage.getItem('reo-theme') } catch { /* private mode */ }
    if (pinned) return
    const t = e.matches ? 'dark' : 'light'
    document.documentElement.dataset.theme = t
    useApp.setState({ theme: t })
  })
} catch { /* very old browsers */ }

// ---------- selectors ----------
const RISK_W = { High: 3, Medium: 2, Low: 1 } as const
/** Ranking is explainable: risk tier first, then how far past SLA, then age. */
export function rank(a: WorkItem, b: WorkItem) {
  if (!!b.actToday !== !!a.actToday) return b.actToday ? 1 : -1
  const ra = RISK_W[a.risk], rb = RISK_W[b.risk]
  if (ra !== rb) return rb - ra
  const oa = a.slaDays ? a.days / a.slaDays : a.days
  const ob = b.slaDays ? b.days / b.slaDays : b.days
  if (oa !== ob) return ob - oa
  return b.days - a.days
}

export function countBy(items: WorkItem[]) {
  const c = { exceptions: 0, actions: 0, approvals: 0, watch: 0 }
  items.forEach((i) => { c[i.queue]++ })
  return c
}

export function overdue(i: WorkItem) {
  return i.slaDays === 0 ? i.days : i.days - i.slaDays
}
