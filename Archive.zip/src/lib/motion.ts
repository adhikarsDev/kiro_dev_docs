import type { Transition, Variants } from 'framer-motion'

// Apple-style springs: critically damped by default (no overshoot),
// a touch of bounce only where a gesture carries momentum.
export const spring: Transition = { type: 'spring', bounce: 0, duration: 0.4 }
export const springSnappy: Transition = { type: 'spring', bounce: 0, duration: 0.28 }
export const springSheet: Transition = { type: 'spring', bounce: 0.12, duration: 0.42 }
export const springSoft: Transition = { type: 'spring', bounce: 0, duration: 0.7 }

export const fadeUp: Variants = {
  hidden: { opacity: 0, y: 18, filter: 'blur(6px)' },
  show: { opacity: 1, y: 0, filter: 'blur(0px)', transition: { ...spring, duration: 0.6 } },
}

export const stagger = (s = 0.06, d = 0): Variants => ({
  hidden: {},
  show: { transition: { staggerChildren: s, delayChildren: d } },
})

export const inView = { once: true, amount: 0.2 } as const

export const press = { scale: 0.97 }
