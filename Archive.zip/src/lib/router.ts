import { useEffect, useState } from 'react'

export type Route =
  | { name: 'today' }
  | { name: 'work' }
  | { name: 'properties' }
  | { name: 'property'; id: string }
  | { name: 'recs' }
  | { name: 'rec'; id: string; type: string }
  | { name: 'approval'; id: string; type: string }
  | { name: 'agents' }
  | { name: 'portfolio' }

const current = () => window.location.hash.replace(/^#/, '') || '/'

export function parse(path: string): Route {
  const [only, qs] = path.split('?')
  const q = new URLSearchParams(qs ?? '')
  const seg = only.split('/').filter(Boolean)
  switch (seg[0]) {
    case undefined: return { name: 'today' }
    case 'work': return { name: 'work' }
    case 'properties': return { name: 'properties' }
    case 'property': return seg[1] ? { name: 'property', id: seg[1] } : { name: 'properties' }
    case 'recs': return { name: 'recs' }
    case 'rec': return seg[1] ? { name: 'rec', id: seg[1], type: q.get('type') ?? 'list' } : { name: 'recs' }
    case 'approval': return seg[1] ? { name: 'approval', id: seg[1], type: q.get('type') ?? 'list' } : { name: 'work' }
    case 'agents': return { name: 'agents' }
    case 'portfolio': return { name: 'portfolio' }
    default: return { name: 'today' }
  }
}

// Scroll positions per path, so "Back" returns to the same place in the queue.
const scrollMemory = new Map<string, number>()
let lastPath = current()
window.addEventListener('scroll', () => { scrollMemory.set(lastPath, window.scrollY) }, { passive: true })

export function navigate(path: string) {
  if (current() === path) return
  scrollMemory.set(lastPath, window.scrollY)
  window.location.hash = path
}

export function useRoute() {
  const [path, setPath] = useState(current())
  useEffect(() => {
    const on = () => { lastPath = current(); setPath(current()) }
    window.addEventListener('hashchange', on)
    return () => window.removeEventListener('hashchange', on)
  }, [])
  return { path, route: parse(path) }
}

export function restoreScroll(path: string) {
  const y = scrollMemory.get(path) ?? 0
  window.scrollTo({ top: y, behavior: 'instant' as ScrollBehavior })
}
