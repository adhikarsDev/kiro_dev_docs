import { useEffect, useMemo, useRef, useState, type ReactElement } from 'react'
import { AnimatePresence, motion } from 'framer-motion'
import {
  AlarmClock, ChevronDown, ChevronUp, CircleAlert, CircleCheck, CircleDashed, ExternalLink, Sparkles,
  TriangleAlert, UserPlus, X,
} from 'lucide-react'
import { overdue, rank, useApp } from '../lib/store'
import { navigate } from '../lib/router'
import { MARKET, money, propertyById, type WorkItem } from '../data/mock'
import { spring, springSheet } from '../lib/motion'
import { PhasePill, RiskPill, Stepper } from '../components/ui'
import { itemContext, type SysState } from './context'
import { originOf, performAction } from './actions'
import { useQueueList } from './WorkQueue'

const SYS_ICON: Record<SysState, ReactElement> = {
  ok: <CircleCheck size={16} style={{ color: 'var(--green)' }} />,
  warn: <TriangleAlert size={16} style={{ color: 'var(--orange)' }} />,
  bad: <CircleAlert size={16} style={{ color: 'var(--red)' }} />,
  idle: <CircleDashed size={16} style={{ color: 'var(--label-4)' }} />,
}

/** Action Center detail — a non-modal panel (no scrim) so the queue keeps its context. */
export function WorkItemPanel() {
  const selectedId = useApp((s) => s.selectedId)
  return <AnimatePresence>{selectedId && <Panel key="panel" />}</AnimatePresence>
}

function Panel() {
  const { selectedId, select, items, moveItems, toast } = useApp()
  const { filtered } = useQueueList()
  // Keep showing the last item while the panel animates out (or after it was resolved).
  const last = useRef<WorkItem | undefined>(undefined)
  const live = items.find((i) => i.id === selectedId)
  if (live) last.current = live
  const item = live ?? last.current
  const list = useMemo(() => (item && filtered.some((f) => f.id === item.id) ? filtered : [...items].sort(rank)), [filtered, items, item])
  const idx = item ? list.findIndex((i) => i.id === item.id) : -1
  const [dir, setDir] = useState(1)
  const [showWhy, setShowWhy] = useState(false)
  const [snoozeOpen, setSnoozeOpen] = useState(false)

  const go = (d: number) => {
    const n = list[idx + d]
    if (n) { setDir(d); select(n.id); setShowWhy(false) }
  }
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const t = e.target as HTMLElement
      if (t?.isContentEditable || ['INPUT', 'TEXTAREA'].includes(t?.tagName)) return
      if (useApp.getState().batch || useApp.getState().confirm || useApp.getState().paletteOpen) return
      if (e.key === 'Escape') select(null)
      if (e.key === 'ArrowDown' || e.key === 'j') { e.preventDefault(); go(1) }
      if (e.key === 'ArrowUp' || e.key === 'k') { e.preventDefault(); go(-1) }
    }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  })

  if (!item) return null
  const p = propertyById(item.propertyId)
  const ctx = itemContext(item, p)
  const late = overdue(item)

  const snooze = (label: string) => {
    const undo = moveItems([item.id], 'watch', { status: 'Waiting External', reason: `Snoozed · ${item.reason}`, detail: `Returns to Exceptions ${label}` })
    toast({ title: `Snoozed until ${label}`, body: `${p.street} returns to your queue automatically.`, undo })
    setSnoozeOpen(false)
  }

  return (
    <motion.aside className="panel" aria-label="Action Center detail"
      initial={{ x: '108%', opacity: 0.6 }} animate={{ x: 0, opacity: 1 }} exit={{ x: '108%', opacity: 0.6 }} transition={springSheet}>
      <div className="panel-head">
        <span className="t-eyebrow">Action Center</span>
        <span className="spacer" />
        <span className="t-caption num">{idx + 1} of {list.length}</span>
        <button className="icon-btn" style={{ width: 30, height: 30 }} onClick={() => go(-1)} disabled={idx <= 0} aria-label="Previous (↑)"><ChevronUp size={17} /></button>
        <button className="icon-btn" style={{ width: 30, height: 30 }} onClick={() => go(1)} disabled={idx >= list.length - 1} aria-label="Next (↓)"><ChevronDown size={17} /></button>
        <button className="icon-btn" style={{ width: 30, height: 30 }} onClick={() => select(null)} aria-label="Close (Esc)"><X size={17} /></button>
      </div>
      <AnimatePresence mode="wait" initial={false} custom={dir}>
        <motion.div key={item.id} className="panel-body"
          initial={{ opacity: 0, y: dir * 24 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: dir * -24 }} transition={{ ...spring, duration: 0.32 }}>
          <div className="stack gap-6">
            <div className="hstack gap-8 wrap">
              <RiskPill risk={item.risk} />
              <PhasePill phase={p.phase} />
              <span className="pill" data-tone="gray">{item.status}</span>
            </div>
            <div className="t-title2" style={{ marginTop: 4 }}>{p.street}</div>
            <div className="t-sub">{p.city}, {p.state} {p.zip} · {p.loan} · {p.investor} · {p.type}</div>
          </div>
          <div className="inset" style={{ padding: '14px 8px 10px' }}><Stepper stage={p.stage} compact /></div>

          <div className="grid" style={{ gridTemplateColumns: '1fr 112px', gap: 10 }}>
            <div className="callout" data-tone={item.queue === 'exceptions' ? 'red' : item.queue === 'actions' ? 'green' : 'blue'}>
              <div className="t-headline t-tone" style={{ marginBottom: 4 }}>{item.queue === 'exceptions' ? 'Why attention is needed' : item.queue === 'actions' ? 'Ready for your decision' : 'Being tracked'}</div>
              <div style={{ fontSize: 13.5, lineHeight: 1.5 }}>{ctx.why}</div>
            </div>
            <div className="callout stack" data-tone={late > 0 && item.queue === 'exceptions' ? 'red' : 'gray'} style={{ justifyContent: 'center' }}>
              <span className="t-eyebrow">SLA</span>
              <span className="days" style={{ fontSize: 30, color: 'var(--label)' }}>{item.days}<span style={{ fontSize: 14 }}> d</span></span>
              <span className="t-caption">Target {item.slaDays}d</span>
              {item.queue === 'exceptions' && late > 0 && <span className="t-caption t-tone strong">{late}d overdue</span>}
            </div>
          </div>

          <section>
            <div className="t-headline" style={{ marginBottom: 6 }}>Source systems</div>
            <div className="inset" style={{ padding: '4px 12px' }}>
              {ctx.sources.map((s) => (
                <div key={s.name} className="sys-row">
                  {SYS_ICON[s.state]}
                  <span className="strong" style={{ fontSize: 13 }}>{s.name}</span>
                  <span className="t-sub" style={{ fontSize: 12.5 }}>{s.text}</span>
                  <span className="t-caption num" style={{ minWidth: 30, textAlign: 'right' }}>{s.age ?? ''}</span>
                </div>
              ))}
            </div>
          </section>

          <section className="grid" style={{ gridTemplateColumns: '1fr 1fr', gap: 10 }}>
            {[
              ['Days in inventory', `${p.daysInInventory}`],
              ['Occupancy', p.occupancy],
              ['Current list price', money(p.listPrice)],
              ['Prev. highest offer', money(p.prevHighOffer)],
            ].map(([k, v]) => (
              <div key={k} className="inset" style={{ padding: '10px 12px' }}>
                <div className="t-caption">{k}</div>
                <div className="t-headline">{v}</div>
              </div>
            ))}
          </section>

          {ctx.missing.length > 0 && (
            <div className="callout" data-tone="orange">
              <div className="t-headline t-tone" style={{ marginBottom: 4 }}>Missing data</div>
              <ul style={{ margin: 0, paddingLeft: 18, fontSize: 13 }}>{ctx.missing.map((m) => <li key={m}>{m}</li>)}</ul>
            </div>
          )}

          {p.phase !== 'pre' && (
            <section>
              <div className="t-headline" style={{ marginBottom: 6 }}>Market context <span className="t-caption">· {p.msa} MSA</span></div>
              <div className="inset" style={{ padding: '4px 12px' }}>
                {MARKET.metrics.slice(0, 3).map((m) => (
                  <div key={m.key} className="sys-row" style={{ gridTemplateColumns: '1fr auto auto' }}>
                    <span className="t-sub">{m.label}</span><span className="strong num">{m.value}</span>
                    <span className="t-caption" style={{ color: 'var(--red-text)' }}>{m.delta}</span>
                  </div>
                ))}
              </div>
            </section>
          )}

          <section>
            <div className="t-headline" style={{ marginBottom: 8 }}>Task history</div>
            <div className="timeline">
              {ctx.history.map((h, k) => (
                <div key={k} className="tl-item" data-tone={h.tone}>
                  <span className="t-caption num" style={{ display: 'inline-block', width: 52 }}>{h.date}</span>{h.text}
                </div>
              ))}
            </div>
          </section>

          <div className="callout" data-tone="green">
            <div className="hstack gap-8" style={{ marginBottom: 4 }}>
              <Sparkles size={15} style={{ color: 'var(--green-text)' }} />
              <span className="t-headline t-tone">AI recommended next step</span>
              <span className="spacer" />
              <button className="btn-plain" style={{ fontSize: 12.5, fontWeight: 600, color: 'var(--blue-text)' }} onClick={() => setShowWhy((v) => !v)}>{showWhy ? 'Hide' : 'View'} reasoning</button>
            </div>
            <div style={{ fontSize: 13.5 }}>{ctx.next}</div>
            <AnimatePresence initial={false}>
              {showWhy && (
                <motion.ul initial={{ height: 0, opacity: 0 }} animate={{ height: 'auto', opacity: 1 }} exit={{ height: 0, opacity: 0 }} transition={spring}
                  style={{ margin: '8px 0 0', paddingLeft: 18, fontSize: 12.5, color: 'var(--label-2)', overflow: 'hidden' }}>
                  {ctx.reasoning.map((r) => <li key={r}>{r}</li>)}
                </motion.ul>
              )}
            </AnimatePresence>
          </div>
        </motion.div>
      </AnimatePresence>
      <div className="panel-foot">
        <motion.button className="btn btn-primary" style={{ flex: '1 1 100%', height: 40 }} whileTap={{ scale: 0.98 }} onClick={(e) => performAction(item, originOf(e))}>
          {item.nextAction}
        </motion.button>
        <button className="btn btn-gray" style={{ flex: 1 }} onClick={() => toast({ title: `Assigned to Jesse R.`, body: p.street, tone: 'info' })}><UserPlus size={14} />Assign</button>
        <div style={{ position: 'relative', flex: 1, display: 'flex' }}>
          <button className="btn btn-gray" style={{ flex: 1 }} onClick={() => setSnoozeOpen((v) => !v)}><AlarmClock size={14} />Snooze</button>
          <AnimatePresence>
            {snoozeOpen && (
              <motion.div initial={{ opacity: 0, scale: 0.9, y: 8 }} animate={{ opacity: 1, scale: 1, y: 0 }} exit={{ opacity: 0, scale: 0.9, y: 8 }} transition={springSheet}
                style={{ position: 'absolute', bottom: 44, left: 0, right: 0, transformOrigin: 'bottom center', padding: 6, borderRadius: 14, background: 'var(--elev)', boxShadow: 'var(--shadow-3)', zIndex: 5 }}>
                {['tomorrow 9:00 AM', 'Thu, Nov 6', 'Mon, Nov 10'].map((l) => (
                  <button key={l} className="pal-item" style={{ width: '100%', margin: 0 }} onClick={() => snooze(l)}>{l}</button>
                ))}
              </motion.div>
            )}
          </AnimatePresence>
        </div>
        <button className="btn btn-gray" style={{ flex: 1.3 }} onClick={() => { select(null); navigate(`/property/${p.id}`) }}><ExternalLink size={14} />Open property</button>
      </div>
    </motion.aside>
  )
}
