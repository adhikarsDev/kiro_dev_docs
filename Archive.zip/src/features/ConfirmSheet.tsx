import { useEffect, useState } from 'react'
import { AnimatePresence, motion } from 'framer-motion'
import { ArrowRight, Check as CheckIcon, FileSignature, ShieldCheck, X } from 'lucide-react'
import { useApp, nowLabel } from '../lib/store'
import { money, propertyById } from '../data/mock'
import { springSheet } from '../lib/motion'

/** Every write is explicit: show changed fields, re-check facts, attribute to the user's Equator session. */
export function ConfirmSheet() {
  const confirm = useApp((s) => s.confirm)
  return <AnimatePresence>{confirm && <Inner key="confirm" />}</AnimatePresence>
}

function Inner() {
  const { closeConfirm, items, moveItems, toast, setRecDecision } = useApp()
  // Snapshot on open so the exit animation never reads a cleared store value.
  const [c] = useState(() => useApp.getState().confirm!)
  const [snapItem] = useState(() => (c.itemId ? useApp.getState().items.find((i) => i.id === c.itemId) : undefined))
  const item = (c.itemId ? items.find((i) => i.id === c.itemId) : undefined) ?? snapItem
  const pid = item?.propertyId ?? c.propertyId!
  const p = propertyById(pid)
  const [step, setStep] = useState(-1) // -1 = review, 0..n = running steps
  const running = step >= 0

  let title = '', sub = '', steps: string[] = [], diff: [string, string, string][] = [], cta = 'Confirm'
  if (c.kind === 'contract' && item?.offer) {
    const o = item.offer
    title = o.type === 'accept' ? 'Accept offer & send contract' : `Send counter at ${money(o.amount)}`
    sub = `${p.street}, ${p.city} ${p.state} · ${p.investor} approval received ${item.approvedAgo}`
    diff = [
      ['Offer status', o.type === 'accept' ? 'Investor approved' : 'Counter approved', o.type === 'accept' ? 'Accepted' : 'Countered'],
      ['Buyer', '—', `${o.buyer} · ${o.financing}`],
      ['Contract price', money(p.listPrice), money(o.amount)],
    ]
    steps = o.type === 'accept'
      ? ['Re-check offer and approval facts', 'Accept offer in Equator', 'Send purchase contract via DocuSign', 'Open closing tasks · order title in ResWare']
      : ['Re-check offer and approval facts', 'Submit counter in Equator', 'Notify buyer agent via Hubzu']
    cta = o.type === 'accept' ? 'Accept & send contract' : 'Send counter'
  } else if (c.kind === 'write') {
    const from = c.payload!.from as number, to = c.payload!.to as number
    title = 'Write price change to Equator'
    sub = `${p.street}, ${p.city} ${p.state} · within delegated authority (${c.payload!.pct as string})`
    diff = [
      ['List price', money(from), money(to)],
      ['Change reason', '—', 'Market adjustment · AI rec R-20481'],
      ['Effective date', '—', 'Nov 4, 2026'],
    ]
    steps = ['Re-check facts since 9:14 AM', 'Validate against rule SPS-LPR-2.3', 'Write list price to Equator', 'Queue Hubzu listing update · broker e-sign']
    cta = 'Write to Equator'
  } else {
    title = item?.nextAction ?? 'Approve'
    sub = `${p.street}, ${p.city} ${p.state} · ${item?.reason ?? ''}`
    diff = [['Task status', 'Ready for approval', 'Approved'], ['Details', '—', item?.detail ?? '']]
    steps = ['Re-check task facts', 'Approve in Equator', 'Notify counterparty']
    cta = 'Approve'
  }

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => { if (e.key === 'Escape' && !running) closeConfirm() }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [closeConfirm, running])

  const run = () => {
    setStep(0)
    steps.forEach((_, k) => window.setTimeout(() => setStep(k + 1), 380 * (k + 1)))
    window.setTimeout(() => {
      const at = nowLabel()
      let undo: (() => void) | undefined
      if (item) undo = moveItems([item.id], 'done')
      if (c.kind === 'write') {
        setRecDecision(pid, 'written')
        const rel = useApp.getState().items.filter((i) => i.propertyId === pid && i.queue === 'exceptions')
        if (rel.length) undo = moveItems(rel.map((r) => r.id), 'done')
      }
      toast({
        title: c.kind === 'contract' ? (item?.offer?.type === 'accept' ? `Contract sent · ${p.street}` : `Counter sent · ${p.street}`) : c.kind === 'write' ? `List price updated · ${p.street}` : `Approved · ${p.street}`,
        body: `Written to Equator ${at} as Srini · receipt EQ-${String(Math.abs(hash(pid))).slice(0, 6)}`,
        undo,
      })
      closeConfirm()
    }, 380 * (steps.length + 1) + 200)
  }

  const o = c.origin
  const from = o ? { x: o.x - window.innerWidth / 2, y: o.y - window.innerHeight / 2 } : { x: 0, y: 30 }

  return (
    <>
      <motion.div className="scrim" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={() => !running && closeConfirm()} />
      <div className="sheet-wrap">
        <motion.div className="sheet narrow" role="dialog" aria-modal aria-label={title}
          initial={{ opacity: 0, scale: 0.5, x: from.x, y: from.y, filter: 'blur(10px)' }} animate={{ opacity: 1, scale: 1, x: 0, y: 0, filter: 'blur(0px)' }}
          exit={{ opacity: 0, scale: 0.5, x: from.x, y: from.y, filter: 'blur(10px)' }} transition={springSheet}>
          <div className="sheet-head">
            <div className="signal-ico" data-tone="blue" style={{ width: 42, height: 42, borderRadius: 12 }}><FileSignature size={20} /></div>
            <div className="stack gap-4" style={{ flex: 1 }}>
              <div className="t-title3">{title}</div>
              <div className="t-sub">{sub}</div>
            </div>
            <button className="icon-btn" onClick={closeConfirm} disabled={running} aria-label="Close"><X size={18} /></button>
          </div>
          <div className="sheet-body single">
            <div className="t-eyebrow" style={{ margin: '6px 0 8px' }}>Changes to be written</div>
            <div className="inset" style={{ padding: '4px 14px' }}>
              {diff.map(([k, a, b]) => (
                <div key={k} className="calc-row" style={{ alignItems: 'center', gap: 10 }}>
                  <span className="t-2" style={{ width: 120, flex: 'none' }}>{k}</span>
                  <span className="t-3" style={{ textDecoration: a !== '—' ? 'line-through' : undefined, flex: 1, textAlign: 'right' }}>{a}</span>
                  <ArrowRight size={14} className="t-3" />
                  <span className="strong" style={{ flex: 1.3 }}>{b}</span>
                </div>
              ))}
            </div>
            <div className="t-eyebrow" style={{ margin: '18px 0 8px' }}>What happens</div>
            <div className="stack gap-8">
              {steps.map((s, k) => {
                const done = step > k, cur = step === k
                return (
                  <div key={s} className="hstack gap-10" style={{ fontSize: 13.5 }}>
                    <motion.span className="check" style={{ borderRadius: '50%', background: done ? 'var(--green)' : 'transparent', boxShadow: done ? 'none' : undefined }}
                      animate={cur ? { scale: [1, 1.15, 1] } : { scale: 1 }} transition={{ repeat: cur ? Infinity : 0, duration: 0.8 }}>
                      {done && <CheckIcon size={12} strokeWidth={3.4} />}
                    </motion.span>
                    <span style={{ color: done ? 'var(--label)' : 'var(--label-2)' }}>{k + 1}. {s}</span>
                  </div>
                )
              })}
            </div>
            <div className="callout hstack gap-10" data-tone="green" style={{ marginTop: 16, fontSize: 12.5 }}>
              <ShieldCheck size={18} style={{ color: 'var(--green-text)', flex: 'none' }} />
              <span>Facts re-checked now: no changes since the recommendation. The action runs in <b>your Equator session</b> and is logged with the rule version and your decision.</span>
            </div>
          </div>
          <div className="sheet-foot">
            <span className="spacer" />
            <button className="btn btn-gray" onClick={closeConfirm} disabled={running}>Cancel</button>
            <motion.button className="btn btn-primary btn-lg" onClick={run} disabled={running} whileTap={{ scale: 0.97 }}>
              {running ? (step >= steps.length ? <><CheckIcon size={16} strokeWidth={3} />Done</> : 'Working…') : cta}
            </motion.button>
          </div>
        </motion.div>
      </div>
    </>
  )
}

function hash(s: string) { let h = 7; for (let i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) | 0; return h * 9301 }
