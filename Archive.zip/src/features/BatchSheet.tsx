import { useEffect, useMemo, useState } from 'react'
import { AnimatePresence, motion } from 'framer-motion'
import { CalendarClock, Check as CheckIcon, FileText, Hourglass, KeyRound, Mail, Pencil, Send, Trash2, TrendingDown, FileWarning, X } from 'lucide-react'
import { useApp, nowLabel } from '../lib/store'
import { money, propertyById, signalDef, type SignalKey } from '../data/mock'
import { springSheet, springSnappy } from '../lib/motion'
import { Check } from '../components/ui'

export const SIGNAL_ICON: Record<SignalKey, typeof Trash2> = {
  trashout: Trash2, novalue: FileWarning, investor: Hourglass, reduction: TrendingDown, eviction: KeyRound, closing: CalendarClock,
}
// Calm pastel identity per signal (severity is carried by the threshold text, not alarm red).
export const SIGNAL_TONE: Record<SignalKey, string> = {
  trashout: 'peach', novalue: 'sky', investor: 'lavender', reduction: 'rose', eviction: 'sand', closing: 'mint',
}

export function BatchSheet() {
  const batch = useApp((s) => s.batch)
  return <AnimatePresence>{batch && <BatchSheetInner key="batch" />}</AnimatePresence>
}

function BatchSheetInner() {
  const { closeBatch, items, moveItems, toast, markCleared } = useApp()
  // Snapshot on open: the store clears `batch` while this sheet is still animating out.
  const [batch] = useState(() => useApp.getState().batch!)
  const sig = batch.signal
  const def = signalDef(sig)
  const Icon = SIGNAL_ICON[sig]
  const list = useMemo(() => {
    const src = batch.itemIds ? items.filter((i) => batch.itemIds!.includes(i.id)) : items.filter((i) => i.queue === 'exceptions' && i.signal === sig)
    return [...src].sort((a, b) => b.days - a.days)
  }, [batch, items, sig])
  const [sel, setSel] = useState<Set<string>>(() => new Set(list.map((i) => i.id)))
  const [phase, setPhase] = useState<'idle' | 'sending' | 'done'>('idle')
  const [sent, setSent] = useState(0)
  const [subject, setSubject] = useState(def.template.subject(list.length))
  const chosen = list.filter((i) => sel.has(i.id))

  useEffect(() => { setSubject(def.template.subject(chosen.length)) }, [chosen.length, def])
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => { if (e.key === 'Escape' && phase === 'idle') closeBatch() }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [closeBatch, phase])

  const toggle = (id: string) => setSel((s) => { const n = new Set(s); n.has(id) ? n.delete(id) : n.add(id); return n })
  const allOn = chosen.length === list.length

  const send = () => {
    if (!chosen.length) return
    setPhase('sending')
    const ids = chosen.map((i) => i.id)
    ids.forEach((_, k) => window.setTimeout(() => setSent(k + 1), 120 + k * 110))
    window.setTimeout(() => {
      setPhase('done')
      const at = nowLabel()
      const isReduction = sig === 'reduction'
      const undo = moveItems(ids, isReduction ? 'approvals' : 'watch', isReduction
        ? { status: 'Approval Pending', reason: 'Reduction request · with investor', detail: `Package sent ${at} · day-3 follow-up scheduled`, days: 0, slaDays: 3, actionKind: 'view', nextAction: 'View package', risk: 'Low' }
        : { status: 'Waiting External', reason: `Follow-up sent · ${def.owner}`, detail: `Sent ${at} · re-check in ${def.recheck}`, days: 0, slaDays: 3, actionKind: 'view', nextAction: 'View', risk: 'Low' })
      const remaining = useApp.getState().items.filter((i) => i.queue === 'exceptions' && i.signal === sig).length
      if (remaining === 0) markCleared(sig, ids.length)
      toast({
        title: def.sentLabel(ids.length),
        body: `Responses are tracked per property. Unresolved files return to Exceptions in ${def.recheck}.`,
        undo: () => { undo(); useApp.setState((s) => { const c = { ...s.cleared }; delete c[sig]; return { cleared: c } }) },
      })
    }, 120 + ids.length * 110 + 260)
    window.setTimeout(() => closeBatch(), 120 + ids.length * 110 + 900)
  }

  const o = batch.origin
  const from = o ? { x: o.x - window.innerWidth / 2, y: o.y - window.innerHeight / 2 } : { x: 0, y: 30 }
  const first = chosen[0] ? propertyById(chosen[0].propertyId) : null

  return (
    <>
      <motion.div className="scrim" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={() => phase === 'idle' && closeBatch()} />
      <div className="sheet-wrap">
        <motion.div className="sheet" role="dialog" aria-modal aria-label={def.title} data-tone={SIGNAL_TONE[sig]}
          initial={{ opacity: 0, scale: 0.4, x: from.x, y: from.y, filter: 'blur(12px)' }}
          animate={{ opacity: 1, scale: 1, x: 0, y: 0, filter: 'blur(0px)' }}
          exit={{ opacity: 0, scale: 0.4, x: from.x, y: from.y, filter: 'blur(10px)' }}
          transition={springSheet}>
          <div className="sheet-head">
            <div className="signal-ico" style={{ width: 42, height: 42, borderRadius: 12 }}><Icon size={21} /></div>
            <div className="stack gap-4" style={{ flex: 1 }}>
              <div className="t-title3">{def.title} <span className="t-3" style={{ fontWeight: 500 }}>· {def.threshold}</span></div>
              <div className="t-sub">{list.length} propert{list.length === 1 ? 'y' : 'ies'} · {def.owner} · Template <b>{def.template.name}</b></div>
            </div>
            <button className="icon-btn" onClick={closeBatch} aria-label="Close" disabled={phase !== 'idle'}><X size={18} /></button>
          </div>
          <div className="sheet-body">
            <div className="sheet-list">
              <div className="sheet-li" style={{ paddingTop: 6, paddingBottom: 8 }}>
                <Check on={allOn} onClick={() => setSel(allOn ? new Set() : new Set(list.map((i) => i.id)))} label="Select all" />
                <span className="t-eyebrow">{chosen.length} of {list.length} selected</span>
                <span className="t-eyebrow">Days</span>
              </div>
              {list.map((it, k) => {
                const p = propertyById(it.propertyId)
                const idx = chosen.findIndex((c) => c.id === it.id)
                const isSent = phase !== 'idle' && idx >= 0 && idx < sent
                return (
                  <motion.button key={it.id} className="sheet-li" onClick={() => phase === 'idle' && toggle(it.id)}
                    initial={{ opacity: 0, x: -10 }} animate={{ opacity: 1, x: 0 }} transition={{ ...springSnappy, delay: 0.04 * k }}>
                    {isSent
                      ? <motion.span className="check on" style={{ background: 'var(--green)' }} initial={{ scale: 0.3 }} animate={{ scale: 1 }} transition={{ type: 'spring', bounce: 0.4, duration: 0.4 }}><CheckIcon size={13} strokeWidth={3.2} /></motion.span>
                      : <Check on={sel.has(it.id)} />}
                    <span className="stack min0">
                      <span className="strong ellipsis" style={{ fontSize: 13.5 }}>{p.street}, {p.city} {p.state}</span>
                      <span className="t-caption ellipsis">{p.loan} · {p.investor} · {it.detail}</span>
                    </span>
                    <span className="days" style={{ fontSize: 17 }} data-tone={SIGNAL_TONE[sig]}>{it.days}<span className="t-caption" style={{ fontSize: 11 }}>d</span></span>
                  </motion.button>
                )
              })}
            </div>
            <div className="mail">
              <div className="hstack gap-8">
                <span className="pill" data-tone="blue"><FileText size={12} />{def.template.name}</span>
                <span className="t-caption">Configurable per client / investor</span>
                <span className="spacer" />
                <button className="btn btn-sm btn-gray"><Pencil size={12} />Edit template</button>
              </div>
              <div className="mail-meta">
                <span className="k">To</span><span><b>{def.template.to}</b> <span className="t-3">&lt;{def.template.toEmail}&gt;</span></span>
                <span className="k">Cc</span><span>{def.template.cc}</span>
                <span className="k">Subject</span>
                <span className="editable strong" contentEditable suppressContentEditableWarning onBlur={(e) => setSubject(e.currentTarget.textContent || '')}>{subject}</span>
              </div>
              <div className="mail-body">
                <p style={{ marginTop: 0 }}>Hello {def.template.to.split(' ')[0]} team,</p>
                <p>{def.template.intro}</p>
                <table>
                  <thead><tr><th>Property</th><th>Loan</th><th>Days</th>{sig === 'reduction' && <th>Proposed</th>}</tr></thead>
                  <tbody>
                    {chosen.slice(0, 6).map((it) => {
                      const p = propertyById(it.propertyId)
                      return (
                        <tr key={it.id}>
                          <td><span className="merge">{p.street}, {p.city}</span></td>
                          <td className="num">{p.loan}</td>
                          <td className="num"><span className="merge">{it.days}</span></td>
                          {sig === 'reduction' && <td className="num">{money(Math.round(((p.listPrice ?? 0) * 0.94) / 1000) * 1000)}</td>}
                        </tr>
                      )
                    })}
                    {chosen.length > 6 && <tr><td colSpan={4} className="t-3">+ {chosen.length - 6} more</td></tr>}
                  </tbody>
                </table>
                <p>{def.template.ask}</p>
                <p style={{ marginBottom: 0 }}>Thank you,<br />Srini<br /><span className="t-3">Asset Manager · Real Estate Asset Management</span></p>
              </div>
              <div className="callout hstack gap-10" data-tone="blue" style={{ fontSize: 12.5 }}>
                <Mail size={16} style={{ color: 'var(--blue-text)', flex: 'none' }} />
                <span>Each property gets its own tracked thread. Replies attach to the file{first ? ` (e.g. ${first.street})` : ''}. If there's no response by the re-check point, the file comes back automatically.</span>
              </div>
            </div>
          </div>
          <div className="sheet-foot">
            <span className="t-caption">Sent as <b>Srini</b> · logged to each property's communications and audit trail</span>
            <span className="spacer" />
            <button className="btn btn-gray" onClick={closeBatch} disabled={phase !== 'idle'}>Cancel</button>
            <motion.button className="btn btn-primary btn-lg" onClick={send} disabled={!chosen.length || phase !== 'idle'} whileTap={{ scale: 0.97 }} layout>
              <AnimatePresence mode="wait" initial={false}>
                {phase === 'idle' && <motion.span key="i" className="hstack gap-8" initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -6 }}><Send size={16} />{sig === 'reduction' ? `Prepare ${chosen.length} request${chosen.length === 1 ? '' : 's'}` : `Send ${chosen.length} follow-up${chosen.length === 1 ? '' : 's'}`}</motion.span>}
                {phase === 'sending' && <motion.span key="s" className="hstack gap-8" initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -6 }}>Sending {sent}/{chosen.length}…</motion.span>}
                {phase === 'done' && <motion.span key="d" className="hstack gap-8" initial={{ opacity: 0, scale: 0.8 }} animate={{ opacity: 1, scale: 1 }}><CheckIcon size={17} strokeWidth={3} />Sent</motion.span>}
              </AnimatePresence>
            </motion.button>
          </div>
        </motion.div>
      </div>
    </>
  )
}
