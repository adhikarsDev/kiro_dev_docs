import { useState } from 'react'
import { AnimatePresence, motion } from 'framer-motion'
import { Check, CircleAlert, CircleCheck, CircleMinus, Copy, Database, FileText, MapPin, TriangleAlert } from 'lucide-react'
import type { Property } from '../data/mock'
import { money } from '../data/mock'
import { RULE_VERSION } from '../data/rec'
import {
  DATA_INPUTS, DECISIONS, MIN_SAMPLE, geoLabel, marketRow, type Availability, type DecisionType, type GeoKey, type Period, type Read, type Segment, type Signal, evidenceFor,
} from '../data/market'
import { spring } from '../lib/motion'
import { Segmented } from '../components/ui'
import { useApp } from '../lib/store'

export type Evidence = ReturnType<typeof evidenceFor>

const READ: Record<Read, { label: string; tone: string; icon: typeof CircleCheck }> = {
  supports: { label: 'Supports', tone: 'mint', icon: CircleCheck },
  contrary: { label: 'Contrary', tone: 'peach', icon: CircleAlert },
  neutral: { label: 'Neutral', tone: 'gray', icon: CircleMinus },
}
export const AVAIL: Record<Availability, { label: string; tone: string }> = {
  available: { label: 'Available', tone: 'mint' },
  partial: { label: 'Partial', tone: 'sand' },
  sourcing: { label: 'Needs sourcing', tone: 'rose' },
}

/* ---------------------------------------------------------- verdict */
export function VerdictBanner({ ev, type, p }: { ev: Evidence; type: DecisionType; p: Property }) {
  const v = ev.verdict
  const tone = v === 'supported' ? 'mint' : v === 'partial' ? 'sand' : 'rose'
  const top = ev.ranked.filter((s) => s.read === 'supports').slice(0, 3).map((s) => s.label.toLowerCase())
  return (
    <motion.div className="verdict" data-tone={tone} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={spring}>
      <span className="verdict-ico">{v === 'supported' ? <CircleCheck size={22} /> : <TriangleAlert size={22} />}</span>
      <div className="stack gap-4" style={{ flex: 1 }}>
        <span className="t-headline t-tone">{v === 'supported' ? 'Supported by current market conditions' : v === 'partial' ? 'Partially supported: review the contrary signals' : 'Not supported by current market conditions'}</span>
        <span style={{ fontSize: 13.5, lineHeight: 1.5 }}>
          {ev.supportCount} of {ev.total} signals support the request to {DECISIONS[type].action}. {p.valuation ? <>The valuation ({money(p.valuation)}) points higher, but </> : null}{top.join(', ')} outweigh it for this property right now.
        </span>
      </div>
      <div className="verdict-meter" aria-label={`Support score ${Math.round(((ev.score + 1) / 2) * 100)} of 100`}>
        <motion.span initial={{ width: 0 }} animate={{ width: `${Math.round(((ev.score + 1) / 2) * 100)}%` }} transition={{ ...spring, duration: 1 }} />
      </div>
    </motion.div>
  )
}

/* ---------------------------------------------------------- evidence tables */
export function MarketEvidence({ type, p, geo, setGeo, seg, setSeg, period, setPeriod, ev, skipped }: {
  type: DecisionType; p: Property; geo: GeoKey; setGeo: (g: GeoKey) => void; seg: Segment; setSeg: (s: Segment) => void; period: Period; setPeriod: (p: Period) => void
  ev: Evidence; skipped: { geo: GeoKey; n: number }[]
}) {
  const n = marketRow(geo, seg, period).n
  return (
    <div className="card card-pad stack gap-14">
      <div className="hstack gap-10 wrap">
        <div className="stack" style={{ flex: '1 1 260px' }}>
          <span className="t-title3">Market & property evidence</span>
          <span className="t-sub">How each signal reads for the request to {DECISIONS[type].action}.</span>
        </div>
        <Segmented layoutId="ev-geo" size="sm" value={geo} onChange={setGeo} items={(['zip', 'msa', 'state'] as GeoKey[]).map((g) => ({ key: g, label: g === 'zip' ? 'ZIP' : g === 'msa' ? 'MSA' : 'State' }))} />
        <Segmented layoutId="ev-seg" size="sm" value={seg} onChange={setSeg} items={[{ key: 'all', label: 'All listings' }, { key: 'reo', label: 'REO only' }]} />
        <Segmented layoutId="ev-per" size="sm" value={period} onChange={setPeriod} items={[{ key: '30d', label: '30 days' }, { key: '90d', label: '90 days' }]} />
      </div>
      <div className="hstack gap-8 wrap t-caption">
        <MapPin size={13} />
        <span>Comparing <b style={{ color: 'var(--label)' }}>{geoLabel(geo, p)}</b> · {seg === 'reo' ? 'REO listings' : 'all listings'} · last {period === '30d' ? '30' : '90'} days vs prior · {n.toLocaleString()} closed sales</span>
        {n < MIN_SAMPLE && <span className="pill" data-tone="sand">Sample under {MIN_SAMPLE}: treat as directional</span>}
        {skipped.length > 0 && geo !== 'zip' && <span className="pill" data-tone="gray">Fell back from {skipped.map((s) => `${s.geo.toUpperCase()} (n=${s.n})`).join(', ')}</span>}
        <span className="pill" data-tone="rose" title="Market provider not yet selected">Sample market data</span>
      </div>
      <div className="grid" style={{ gridTemplateColumns: 'repeat(auto-fit, minmax(420px, 1fr))', gap: 18 }}>
        <SignalTable title="Market signals" rows={ev.market} />
        <SignalTable title="Property performance" rows={[...ev.property, ev.valuation]} />
      </div>
    </div>
  )
}

function SignalTable({ title, rows }: { title: string; rows: Signal[] }) {
  const [open, setOpen] = useState<string | null>(null)
  return (
    <div className="stack">
      <div className="sig-row head"><span>{title}</span><span>Value</span><span>Reads as</span><span>Influence</span></div>
      {rows.map((r) => {
        const R = READ[r.read]
        const on = open === r.key
        return (
          <div key={r.key}>
            <button className="sig-row" onClick={() => setOpen(on ? null : r.key)} aria-expanded={on}>
              <span className="stack min0"><span className="strong ellipsis" style={{ fontSize: 13.5 }}>{r.label}</span><span className="t-caption ellipsis">{r.detail}</span></span>
              <span className="strong num" style={{ fontSize: 13.5 }}>{r.value}</span>
              <span className="pill" data-tone={R.tone}><R.icon size={12} />{R.label}</span>
              <span className="sig-weight" data-tone={R.tone}><motion.span initial={{ width: 0 }} whileInView={{ width: `${r.weight * 100}%` }} viewport={{ once: true }} transition={{ ...spring, duration: 0.8 }} /></span>
            </button>
            <AnimatePresence initial={false}>
              {on && (
                <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: 'auto', opacity: 1 }} exit={{ height: 0, opacity: 0 }} transition={spring} style={{ overflow: 'hidden' }}>
                  <div className="sig-why"><span>{r.why}</span><span className="pill" data-tone={AVAIL[r.availability].tone}>{AVAIL[r.availability].label}</span></div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        )
      })}
    </div>
  )
}

/* ---------------------------------------------------------- what drove it */
export function Influences({ ev }: { ev: Evidence }) {
  const sup = ev.ranked.filter((s) => s.read === 'supports').slice(0, 4)
  const con = ev.ranked.filter((s) => s.read === 'contrary').slice(0, 3)
  return (
    <div className="stack gap-10">
      <div className="t-eyebrow">Strongest supporting signals</div>
      {sup.map((s) => (
        <div key={s.key} className="hstack gap-10" style={{ alignItems: 'flex-start' }}>
          <CircleCheck size={16} style={{ color: 'var(--mint-text)', flex: 'none', marginTop: 2 }} />
          <span className="stack"><span className="strong" style={{ fontSize: 13.5 }}>{s.label} · {s.value}</span><span className="t-sub" style={{ fontSize: 12.5 }}>{s.why}</span></span>
        </div>
      ))}
      <div className="t-eyebrow" style={{ marginTop: 4 }}>Contrary signals considered</div>
      {con.map((s) => (
        <div key={s.key} className="hstack gap-10" style={{ alignItems: 'flex-start' }}>
          <CircleAlert size={16} style={{ color: 'var(--peach-text)', flex: 'none', marginTop: 2 }} />
          <span className="stack"><span className="strong" style={{ fontSize: 13.5 }}>{s.label} · {s.value}</span><span className="t-sub" style={{ fontSize: 12.5 }}>{s.why}</span></span>
        </div>
      ))}
    </div>
  )
}

/* ---------------------------------------------------------- investor-ready brief */
export function briefText(type: DecisionType, p: Property, ev: Evidence, geo: string, period: Period, proposal: string) {
  const m = ev.m
  const per = period === '30d' ? 'last 30 days' : 'last 90 days'
  return [
    `Recommendation: ${proposal}`,
    `Market context (${geo}, ${per} vs prior): for-sale inventory ${m.inventory.toLocaleString()} (${m.invDelta > 0 ? '+' : ''}${m.invDelta}%); contract fallout ${m.fallout}% (${m.falloutDelta > 0 ? '+' : ''}${m.falloutDelta} pts); ${m.redCount.toLocaleString()} listings (${m.redPct}%) reduced price; average sale price ${m.stlPct}% of list (${money(m.stlUsd)}); median days on market ${m.dom} (${m.domDelta > 0 ? '+' : ''}${m.domDelta}).`,
    `Property performance: first listed ${ev.property[0].value} (${p.dom ?? 42} days on market); ${p.bidders || 3} bidders and ${p.bids || 5} bids; previous highest offer ${ev.property[4].value} (${ev.property[4].detail}).`,
    `Although the current valuation (${ev.valuation.value}) supports a higher price, current market conditions and this property's activity indicate the request is ${ev.verdict === 'supported' ? 'reasonable and supported' : 'only partly supported'}. ${ev.supportCount} of ${ev.total} signals support it.`,
    `Rule ${RULE_VERSION}. Market data is a stored snapshot used for this recommendation.`,
  ].join('\n\n')
}

export function CustomerBrief({ text, onAdd }: { text: string; onAdd?: () => void }) {
  const toast = useApp((s) => s.toast)
  const [copied, setCopied] = useState(false)
  return (
    <div className="card card-pad stack gap-12">
      <div className="hstack gap-10">
        <span className="rec-ico" data-tone="lavender"><FileText size={18} /></span>
        <div className="stack" style={{ flex: 1 }}><span className="t-title3">Investor-ready brief</span><span className="t-caption">Consistent wording for every customer. Edit before sending.</span></div>
        <button className="btn btn-gray btn-sm" onClick={() => { try { navigator.clipboard?.writeText(text) } catch { /* clipboard blocked */ } setCopied(true); toast({ title: 'Brief copied', tone: 'info' }); setTimeout(() => setCopied(false), 1600) }}>
          {copied ? <Check size={13} /> : <Copy size={13} />}{copied ? 'Copied' : 'Copy'}
        </button>
        {onAdd && <button className="btn btn-tinted btn-sm" onClick={onAdd}>Use in approval package</button>}
      </div>
      <div className="brief editable" contentEditable suppressContentEditableWarning>
        {text.split('\n\n').map((para, i) => <p key={i}>{para}</p>)}
      </div>
    </div>
  )
}

/* ---------------------------------------------------------- data availability */
export function DataReadiness({ compact }: { compact?: boolean }) {
  const counts = DATA_INPUTS.reduce((a, d) => ({ ...a, [d.status]: (a[d.status] ?? 0) + 1 }), {} as Record<Availability, number>)
  const groups = ['Market', 'Property', 'Context'] as const
  return (
    <div className="card card-pad stack gap-12">
      <div className="hstack gap-10 wrap">
        <span className="rec-ico" data-tone="sky"><Database size={18} /></span>
        <div className="stack" style={{ flex: 1 }}>
          <span className="t-title3">Data inputs: available vs to source</span>
          <span className="t-caption">What the market-aware agents use, and where it comes from.</span>
        </div>
        {(['available', 'partial', 'sourcing'] as Availability[]).map((s) => <span key={s} className="pill" data-tone={AVAIL[s].tone}>{counts[s] ?? 0} {AVAIL[s].label.toLowerCase()}</span>)}
      </div>
      {groups.map((g) => (
        <div key={g} className="stack">
          <div className="t-eyebrow" style={{ padding: '6px 0 4px' }}>{g === 'Market' ? 'Market / MSA signals' : g === 'Property' ? 'Property-specific signals' : 'Decision context'}</div>
          {DATA_INPUTS.filter((d) => d.group === g).map((d) => (
            <div key={d.input} className={`ready-row ${compact ? 'compact' : ''}`}>
              <span className="strong" style={{ fontSize: 13.5 }}>{d.input}</span>
              <span><span className="pill" data-tone={AVAIL[d.status].tone}>{AVAIL[d.status].label}</span></span>
              {!compact && <span className="t-sub" style={{ fontSize: 12.5 }}>{d.source}</span>}
              {!compact && <span className="t-caption">{d.note}</span>}
            </div>
          ))}
        </div>
      ))}
    </div>
  )
}
