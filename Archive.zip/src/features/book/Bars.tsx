import { useState } from 'react'
import { motion } from 'framer-motion'
import type { Phase } from '../../data/mock'
import { spring } from '../../lib/motion'
import { AnimatedNumber } from '../../components/ui'
import { PH_TONE, type BookPhase } from './types'

interface Props { phases: BookPhase[]; active: Phase | 'all'; onPick: (p: Phase) => void; titleCount: number }

const niceMax = (v: number) => { const step = v > 500 ? 250 : v > 200 ? 100 : 25; return Math.ceil(v / step) * step }

/** "Your book": rounded columns per phase on a light grid. Height = properties; coral cap = need attention; bracket = Title in parallel. */
export function BookColumns({ phases, active, onPick, titleCount }: Props) {
  const [hover, setHover] = useState<Phase | null>(null)
  const max = niceMax(Math.max(...phases.map((p) => p.total)))
  const ticks = [0, 0.25, 0.5, 0.75, 1].map((f) => Math.round(max * f))
  const ci = phases.findIndex((p) => p.phase === 'contract'), cl = phases.findIndex((p) => p.phase === 'closing')
  return (
    <div className="vc" onMouseLeave={() => setHover(null)}>
      <div className="vc-plot">
        <div className="vc-grid" aria-hidden>{ticks.map((t) => <span key={t} style={{ bottom: `${(t / max) * 100}%` }}><em>{t}</em></span>)}</div>
        {phases.map((p, i) => {
          const h = (p.total / max) * 100
          const dim = hover && hover !== p.phase
          return (
            <button key={p.phase} className={`vc-col ${dim ? 'dim' : ''} ${active === p.phase ? 'on' : ''}`} data-tone={PH_TONE[p.phase]} onMouseEnter={() => setHover(p.phase)} onClick={() => onPick(p.phase)} aria-label={`${p.label} ${p.total}`}>
              <motion.span className="vc-bar" initial={{ height: 0 }} animate={{ height: `${h}%` }} transition={{ ...spring, duration: 1, delay: 0.08 * i }}>
                <span className="vc-num"><AnimatedNumber value={p.total} /></span>
                {p.attention > 0 && <span className="vc-att" style={{ height: `${(p.attention / p.total) * 100}%` }} />}
              </motion.span>
            </button>
          )
        })}
      </div>
      <div className="vc-labels">
        {phases.map((p) => (
          <span key={p.phase} className={hover && hover !== p.phase ? 'dim' : ''}>
            <b>{p.label}</b>
            <em className={p.attention ? 'att' : ''}>{p.attention ? `${p.attention} need attention` : 'All on track'}</em>
          </span>
        ))}
      </div>
      {ci >= 0 && cl >= 0 && (
        <div className="vc-bracket" style={{ left: `calc(${(ci / phases.length) * 100}% + 3%)`, width: `calc(${((cl - ci + 1) / phases.length) * 100}% - 6%)` }}>
          <span>Title · {titleCount} in parallel</span>
        </div>
      )}
    </div>
  )
}
