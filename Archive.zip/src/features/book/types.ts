import type { Phase } from '../../data/mock'

export interface BookPhase { phase: Phase; label: string; total: number; attention: number }

export const PH_TONE: Record<Phase, string> = { pre: 'ph-pre', on: 'ph-on', contract: 'ph-contract', closing: 'ph-closing', sold: 'ph-sold' }
