import { useMemo, useState } from 'react'
import { AnimatePresence, motion } from 'framer-motion'
import {
  ArrowRight, BadgeCheck, ChevronRight, CircleCheck, ClipboardList, Handshake, Mail, Sparkles, TrendingDown, Zap,
} from 'lucide-react'
import { useApp } from '../lib/store'
import { navigate } from '../lib/router'
import { AI_RECS, KEY_DATES, MARKET, SIGNALS, SYSTEMS, money, propertyById, type SignalDef, type WorkItem } from '../data/mock'
import { fadeUp, inView, spring, springSnappy, stagger } from '../lib/motion'
import { AnimatedNumber, Sparkline, SpotlightCard } from '../components/ui'
import { originOf } from './actions'
import { SIGNAL_ICON, SIGNAL_TONE } from './BatchSheet'

/* ------------------------------------------------------------ Act Today */
export function ActToday() {
  const all = useApp((s) => s.items)
  const openConfirm = useApp((s) => s.openConfirm)
  const items = useMemo(() => all.filter((i) => i.actToday && i.queue === 'actions'), [all])
  const [hadAny] = useState(items.length > 0)
  if (!hadAny) return null
  return (
    <motion.section className="act-today" layout transition={spring} variants={fadeUp} initial="hidden" whileInView="show" viewport={inView} aria-label="Act today">
      <div className="act-head">
        <span className="act-ico" data-tone="mint" style={{ width: 44, height: 44 }}><Zap size={20} /></span>
        <div className="stack gap-4" style={{ flex: 1 }}>
          <div className="hstack gap-10">
            <span className="t-title2">Act today</span>
            <AnimatePresence initial={false} mode="popLayout">
              <motion.span key={items.length} className="pill" data-tone="mint" initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -6 }}>
                <span className="live-dot" style={{ width: 7, height: 7 }} />{items.length ? `${items.length} investor approval${items.length === 1 ? '' : 's'} in hand` : 'All done'}
              </motion.span>
            </AnimatePresence>
          </div>
          <span className="t-sub" style={{ fontSize: 14 }}>
            {items.length ? 'Investors approved these offers. Accept them and get contracts moving today.' : 'Closing tasks are open and title has been ordered. New approvals appear here the moment they arrive.'}
          </span>
        </div>
      </div>
      <AnimatePresence initial={false}>
        {items.length > 0 && (
          <motion.div className="act-table" exit={{ opacity: 0, height: 0 }} transition={spring}>
            <div className="act-cols"><span /><span>Property</span><span>Investor decision</span><span>Offer</span><span /></div>
            <AnimatePresence initial={false}>
              {items.map((it) => <ActRow key={it.id} it={it} onAct={(e) => openConfirm({ kind: 'contract', itemId: it.id, origin: originOf(e) })} />)}
            </AnimatePresence>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.section>
  )
}

function ActRow({ it, onAct }: { it: WorkItem; onAct: (e: React.MouseEvent) => void }) {
  const p = propertyById(it.propertyId)
  const o = it.offer!
  const pct = p.listPrice ? Math.round((o.amount / p.listPrice) * 1000) / 10 : null
  const accept = o.type === 'accept'
  return (
    <motion.div className="act-row" layout initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, height: 0, paddingTop: 0, paddingBottom: 0, marginTop: -8, scale: 0.98, transition: { duration: 0.35, ease: [0.32, 0.72, 0, 1] } }}>
      <span className="act-ico" data-tone={accept ? 'mint' : 'lavender'}>{accept ? <Handshake size={19} /> : <BadgeCheck size={19} />}</span>
      <span className="stack min0">
        <span className="strong ellipsis" style={{ fontSize: 14.5 }}>{p.street}</span>
        <span className="t-caption ellipsis">{p.city}, {p.state} · {p.loan}</span>
      </span>
      <span className="stack min0">
        <span className="hstack gap-6"><span className="pill" data-tone={accept ? 'mint' : 'lavender'} style={{ height: 20 }}>{accept ? 'Accept' : 'Counter'}</span><span className="strong" style={{ fontSize: 13 }}>{p.investor}</span></span>
        <span className="t-caption" style={{ marginTop: 2 }}>Approved {it.approvedAgo}</span>
      </span>
      <span className="stack min0">
        <span className="strong num" style={{ fontSize: 14.5 }}>{money(o.amount)}</span>
        <span className="t-caption ellipsis">{o.buyer} · {o.financing}{pct ? ` · ${pct}% of list` : ''}</span>
      </span>
      <span className="hstack gap-6" style={{ justifyContent: 'flex-end' }}>
        <motion.button className="btn btn-primary act-btn" whileTap={{ scale: 0.96 }} transition={springSnappy} onClick={onAct}>
          {accept ? 'Accept & send contract' : 'Send counter offer'}
        </motion.button>
        <button className="icon-btn" aria-label={`Open ${p.street}`} onClick={() => navigate(`/property/${p.id}`)}><ChevronRight size={18} /></button>
      </span>
    </motion.div>
  )
}

/* ------------------------------------------------------------ Signals */
export function SignalBoard() {
  const items = useApp((s) => s.items)
  const total = items.filter((i) => i.queue === 'exceptions').length
  return (
    <section className="stack gap-16" id="signals">
      <div className="hstack gap-12 wrap" style={{ alignItems: 'flex-end' }}>
        <div className="stack gap-4" style={{ flex: 1 }}>
          <div className="t-eyebrow">Step 1 · Problem assets</div>
          <div className="t-title1">Clear your exceptions</div>
          <div className="t-sub">Six signals catch the files that fall through the gaps. Each one can be resolved as a batch in two clicks.</div>
        </div>
        <div className="hstack gap-8 t-sub">
          <span className="status-dot" data-tone="green" /> Live · no 48-hour exception report delay
          <span className="pill" data-tone="rose" style={{ marginLeft: 6 }}><AnimatedNumber value={total} /> open</span>
        </div>
      </div>
      <motion.div className="signals" variants={stagger(0.07)} initial="hidden" whileInView="show" viewport={inView}>
        {SIGNALS.map((s) => <SignalTile key={s.key} def={s} items={items} />)}
      </motion.div>
    </section>
  )
}

function SignalTile({ def, items }: { def: SignalDef; items: WorkItem[] }) {
  const openBatch = useApp((s) => s.openBatch)
  const cleared = useApp((s) => s.cleared[def.key])
  const list = useMemo(() => items.filter((i) => i.queue === 'exceptions' && i.signal === def.key).sort((a, b) => a.days - b.days), [items, def.key])
  const approaching = items.filter((i) => i.approaching && i.signal === def.key && i.queue === 'watch').length
  const n = list.length
  const Icon = SIGNAL_ICON[def.key]
  const [hover, setHover] = useState<WorkItem | null>(null)
  const max = Math.max(...list.map((i) => i.days), (list[0]?.slaDays ?? 1) * 1.6, 1)
  const sla = list[0]?.slaDays ?? 0
  const oldest = list[list.length - 1]
  const tone = n === 0 ? 'mint' : SIGNAL_TONE[def.key]

  return (
    <motion.div variants={fadeUp} layout transition={spring} style={{ display: 'flex' }}>
    <SpotlightCard className={`signal ${n === 0 ? 'clear' : ''}`} tone={tone} tilt={3} style={{ flex: 1 }}>
      <div className="hstack gap-10" style={{ position: 'relative' }}>
        <div className="signal-ico">{n === 0 ? <CircleCheck size={18} /> : <Icon size={18} />}</div>
        <div className="stack min0" style={{ flex: 1 }}>
          <span className="t-headline ellipsis">{def.title}</span>
          <span className="t-caption ellipsis">{def.threshold}</span>
        </div>
      </div>
      <div className="hstack gap-12" style={{ alignItems: 'flex-end', position: 'relative', minHeight: 64 }}>
        <div className="stack">
          <span className={`signal-big ${n === 0 ? 'zero' : ''}`}><AnimatedNumber value={n} /></span>
          <span className="t-caption" style={{ marginTop: 4 }}>{n === 1 ? 'file' : 'files'} · {def.owner}</span>
        </div>
        <span className="spacer" />
        {n > 0 && (
          <svg width={128} height={56} style={{ overflow: 'visible' }} onMouseLeave={() => setHover(null)} aria-label={`Aging of ${n} files`}>
            {sla > 0 && (
              <>
                <line x1={0} x2={128} y1={56 - (sla / max) * 52} y2={56 - (sla / max) * 52} stroke="var(--label-4)" strokeDasharray="3 3" />
                <text x={128} y={56 - (sla / max) * 52 - 4} textAnchor="end" fontSize={9.5} fill="var(--label-3)">{sla}d</text>
              </>
            )}
            {list.map((it, k) => {
              const w = Math.min(14, 128 / n - 3)
              const h = Math.max(4, (it.days / max) * 52)
              const x = k * (128 / n) + (128 / n - w) / 2
              return (
                <motion.rect key={it.id} x={x} width={w} rx={Math.min(4, w / 2)} y={56 - h} height={h}
                  style={{ fill: 'var(--tone)', opacity: hover && hover.id !== it.id ? 0.35 : 0.9, cursor: 'pointer', transformOrigin: `${x}px 56px` }}
                  initial={{ scaleY: 0 }} whileInView={{ scaleY: 1 }} viewport={{ once: true }} transition={{ ...spring, delay: 0.15 + k * 0.03 }}
                  onMouseEnter={() => setHover(it)} />
              )
            })}
          </svg>
        )}
      </div>
      <div className="signal-foot" style={{ minHeight: 18 }}>
        <AnimatePresence mode="wait" initial={false}>
          <motion.span key={hover?.id ?? 'meta'} initial={{ opacity: 0, y: 4 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -4 }} transition={{ duration: 0.15 }} className="ellipsis">
            {hover ? <><b style={{ color: 'var(--label)' }}>{propertyById(hover.propertyId).street}</b> · {hover.days} days · {hover.detail}</>
              : n > 0 ? <>Oldest <b style={{ color: 'var(--label-2)' }}>{oldest.days}d</b>{approaching ? <> · <span style={{ color: 'var(--tone-text)' }}>+{approaching} approaching</span></> : null} · re-check every {def.recheck}</>
              : cleared ? <>{def.sentLabel(cleared.n)} at {cleared.at} · re-check in {def.recheck}</>
              : <>Nothing past threshold{approaching ? ` · ${approaching} approaching` : ''}</>}
          </motion.span>
        </AnimatePresence>
      </div>
      <motion.button className="btn btn-tone" whileTap={{ scale: 0.97 }} disabled={n === 0}
        onClick={(e) => openBatch({ signal: def.key, origin: originOf(e) })}>
        {n === 0 ? <><CircleCheck size={15} />All clear</> : <>{def.cta(n)}<ArrowRight size={15} /></>}
      </motion.button>
    </SpotlightCard>
    </motion.div>
  )
}

/* ------------------------------------------------------------ Right rail */
const REC_ICON = { price: TrendingDown, offer: Handshake, mail: Mail, check: ClipboardList } as const
const REC_TONE = { price: 'blue', offer: 'purple', mail: 'teal', check: 'green' } as const

export function AIRecsCard() {
  return (
    <motion.div className="card" variants={fadeUp} initial="hidden" whileInView="show" viewport={inView}>
      <div className="card-h">
        <Sparkles size={18} style={{ color: 'var(--blue)' }} />
        <span className="t-title3">AI recommendations</span>
        <button className="btn btn-plain btn-sm" onClick={() => navigate('/recs')}>View all</button>
      </div>
      <div className="card-pad" style={{ paddingTop: 8 }}>
        {AI_RECS.map((r) => {
          const p = propertyById(r.propertyId)
          const Icon = REC_ICON[r.kind]
          return (
            <motion.button key={r.id} className="list-row" style={{ width: '100%', textAlign: 'left' }} whileHover={{ x: 2 }} transition={springSnappy}
              onClick={() => navigate(r.kind === 'price' && r.id === 'R1' ? `/rec/${p.id}` : `/property/${p.id}`)}>
              <span className="mini-ico" data-tone={REC_TONE[r.kind]} style={{ width: 34, height: 34, borderRadius: 10 }}><Icon size={17} /></span>
              <span className="stack min0" style={{ flex: 1 }}>
                <span className="strong ellipsis" style={{ fontSize: 13.5 }}>{r.title}</span>
                <span className="t-caption ellipsis">{p.street}, {p.city} {p.state}</span>
              </span>
              <span className="pill" data-tone={r.conf >= 85 ? 'green' : 'orange'}>{r.conf}%</span>
            </motion.button>
          )
        })}
      </div>
    </motion.div>
  )
}

export function KeyDatesCard() {
  return (
    <motion.div className="card" variants={fadeUp} initial="hidden" whileInView="show" viewport={inView}>
      <div className="card-h"><span className="t-title3">Upcoming key dates</span><button className="btn btn-plain btn-sm">Calendar</button></div>
      <div className="card-pad" style={{ paddingTop: 8 }}>
        {KEY_DATES.map((d) => (
          <div key={d.title + d.day} className="list-row">
            <div className="date-tile"><div className="m">{d.mon}</div><div className="d">{d.day}</div></div>
            <div className="stack min0" style={{ flex: 1 }}>
              <span className="strong ellipsis" style={{ fontSize: 13.5 }}>{d.title}</span>
              <span className="t-caption ellipsis">{d.who}</span>
            </div>
            <span className="pill" data-tone={d.tone}>{d.tag}</span>
          </div>
        ))}
      </div>
    </motion.div>
  )
}

export function MarketPulseCard({ compact }: { compact?: boolean }) {
  return (
    <motion.div className="card" variants={fadeUp} initial="hidden" whileInView="show" viewport={inView}>
      <div className="card-h">
        <span className="t-title3">Market pulse</span>
        <span className="t-caption">{MARKET.msa}</span>
      </div>
      <div className="card-pad" style={{ paddingTop: 6 }}>
        {MARKET.metrics.slice(0, compact ? 3 : 5).map((m) => (
          <div key={m.key} className="list-row" style={{ padding: '9px 0' }}>
            <span className="t-sub" style={{ flex: 1 }}>{m.label}</span>
            <Sparkline values={m.spark} tone={m.bad ? 'red' : 'green'} w={64} h={22} />
            <span className="strong num" style={{ width: 52, textAlign: 'right' }}>{m.value}</span>
            <span className="t-caption num" style={{ width: 58, textAlign: 'right', color: m.bad ? 'var(--red-text)' : 'var(--green-text)' }}>{m.delta}</span>
          </div>
        ))}
        <div className="t-caption" style={{ marginTop: 6 }}>Source {MARKET.source} · as of {MARKET.asOf} · vs prior month</div>
      </div>
    </motion.div>
  )
}

export function SystemsCard() {
  return (
    <motion.div className="card" variants={fadeUp} initial="hidden" whileInView="show" viewport={inView}>
      <div className="card-h"><span className="t-title3">Systems & data freshness</span></div>
      <div className="card-pad" style={{ paddingTop: 8 }}>
        {SYSTEMS.map((s) => (
          <div key={s.name} className="list-row" style={{ padding: '8px 0' }}>
            <span className="status-dot" data-tone={s.status === 'ok' ? 'green' : 'orange'} />
            <span className="stack min0" style={{ flex: 1 }}>
              <span className="strong" style={{ fontSize: 13 }}>{s.name}</span>
              <span className="t-caption ellipsis">{s.role}</span>
            </span>
            <span className="t-caption num" style={{ color: s.status === 'ok' ? undefined : 'var(--orange-text)' }}>{s.status === 'ok' ? s.sync : `Delayed · ${s.sync}`}</span>
          </div>
        ))}
      </div>
    </motion.div>
  )
}
