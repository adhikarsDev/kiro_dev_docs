import type { Property, WorkItem } from '../data/mock'

export type SysState = 'ok' | 'warn' | 'bad' | 'idle'
export interface ItemContext {
  why: string
  sources: { name: string; state: SysState; text: string; age?: string }[]
  missing: string[]
  next: string
  reasoning: string[]
  history: { date: string; text: string; tone?: string }[]
}

const day = (offset: number) => {
  const d = new Date(2026, 10, 3)
  d.setDate(d.getDate() - offset)
  return d.toLocaleDateString('en-US', { month: 'short', day: 'numeric' })
}

export function itemContext(i: WorkItem, p: Property): ItemContext {
  const inv = p.daysInInventory
  const base = {
    history: [
      { date: day(inv), text: 'Property boarded in Equator' },
      { date: day(Math.max(0, inv - 1)), text: `Assigned to ${p.broker}` },
      { date: day(Math.max(0, inv - 2)), text: 'Occupancy task ordered' },
    ],
  }
  switch (i.signal) {
    case 'trashout':
      return {
        why: `Triple R hasn't confirmed trash-out completion, and the property has been in inventory for ${i.days} days (target 15). It can't go to market until initial services are done, and every extra day here adds to days in inventory.`,
        sources: [
          { name: 'Equator', state: 'ok', text: 'Initial services task open', age: `${i.days}d` },
          { name: 'Triple R', state: 'bad', text: 'Ordered · no completion photos', age: `${i.days - 9}d` },
          { name: 'Palladium / AFS', state: 'ok', text: 'Re-secured · lockbox set' },
          { name: 'Valuation (BPO)', state: 'ok', text: 'Received' },
          { name: 'Hubzu', state: 'idle', text: 'Not listed' },
        ],
        missing: ['Trash-out completion photos', 'Lawn service confirmation', 'Safe-to-market sign-off'],
        next: 'Send the templated status request to Triple R covering debris, lawn and safety. If there\'s no reply within 72 h, escalate to Vendor Management.',
        reasoning: ['Past the 15-day trash-out threshold', 'Triple R report last synced 6:00 AM (delayed)', '9 other files share this vendor gap, so batch them'],
        history: [...base.history, { date: day(i.days - 6), text: 'Occupancy completed: vacant', tone: 'green' }, { date: day(i.days - 9), text: 'Trash-out ordered with Triple R' }, { date: day(3), text: '72 h vendor check-in missed', tone: 'red' }],
      }
    case 'novalue':
      return {
        why: `No BPO has been received from the vendor, and the property has been in inventory for ${i.days} days. Valuations are required before the marketing plan and list price can be set.`,
        sources: [
          { name: 'Equator', state: 'ok', text: 'Valuation task open', age: `${i.days}d` },
          { name: 'Valuation (BPO)', state: 'bad', text: 'Not received', age: `${i.days - 2}d` },
          { name: 'Triple R', state: 'ok', text: 'Initial services complete' },
          { name: 'Palladium / AFS', state: 'ok', text: 'Secured' },
          { name: 'Hubzu', state: 'idle', text: 'Not listed' },
        ],
        missing: ['BPO valuation report', 'Interior photos', 'Estimated repair costs'],
        next: 'Draft a follow-up to the BPO vendor asking for status and an expected delivery date. If there\'s no response in 2 days, escalate to Vendor Management.',
        reasoning: ['10-day escalation threshold passed (warned at day 5)', 'Blocks CMP agent from drafting the marketing plan'],
        history: [...base.history, { date: day(i.days - 2), text: 'BPO ordered from ValuePoint' }, { date: day(i.days - 5), text: '5-day valuation warning raised', tone: 'orange' }],
      }
    case 'investor':
      return {
        why: `${i.reason} with ${p.investor} for ${i.days} days. Per the operating model, follow-up starts on day 3 and continues daily, copying management, until there's a decision.`,
        sources: [
          { name: 'Equator', state: 'ok', text: 'Approval task open' },
          { name: `${p.investor} portal`, state: 'bad', text: 'No decision', age: `${i.days}d` },
          { name: 'Hubzu', state: p.phase === 'pre' ? 'idle' : 'ok', text: p.phase === 'pre' ? 'Not listed' : `${p.dom} DOM · ${p.bids} bids` },
          { name: 'Market data', state: 'warn', text: 'Sample feed · provider TBD' },
        ],
        missing: [],
        next: `Send a professional, direct reminder to ${p.investor} that this has been outstanding for ${i.days} days, attaching the original package and refreshed market data.`,
        reasoning: [`${i.days} days pending against a 3-day expectation`, 'Investor delays are the largest source of lost days this month', 'Reminder template keeps messaging consistent'],
        history: [...base.history, { date: day(i.days), text: `Request submitted to ${p.investor}` }, { date: day(Math.max(0, i.days - 3)), text: 'Day-3 escalation threshold reached', tone: 'orange' }],
      }
    case 'reduction':
      return {
        why: `${p.dom} days on market with ${p.bids} bids from ${p.bidders} bidders and no accepted offer. The 2-week review cadence and 30-day signal both say it's time to build a reduction case.`,
        sources: [
          { name: 'Hubzu', state: 'warn', text: `${p.bids} bids · showings ↓40%`, age: 'live' },
          { name: 'Market data', state: 'ok', text: 'MSA inventory +12%' },
          { name: 'Equator', state: 'ok', text: 'No pending approvals or active offers' },
          { name: 'Valuation', state: 'warn', text: 'BPO is 21 days old' },
        ],
        missing: ['Interior inspection (last 14 days)', 'Updated BPO'],
        next: 'Review the AI reduction recommendation. If it\'s within delegated authority, approve and submit. Otherwise route the drafted package to the investor.',
        reasoning: ['30+ DOM, no accepted offer', 'No active offers or pending approvals that would block a reduction', 'MSA reductions up 9 pts'],
        history: [...base.history, { date: day(p.dom ?? 30), text: 'Listed on Hubzu' }, { date: day(14), text: '2-week marketing review completed' }, { date: day(0), text: 'Review Marketing Plan agent: analysis ready', tone: 'blue' }],
      }
    case 'eviction':
      return {
        why: i.reason.startsWith('Occupied')
          ? 'Occupancy came back occupied. The file must be routed to the eviction team (ESD) right away so attorney work can start.'
          : `ESD hasn't updated this file in ${i.days} days. Weekly check-ins should confirm attorney communication, ongoing inspections and updated values during a prolonged eviction.`,
        sources: [
          { name: 'Equator', state: 'ok', text: 'Occupancy: occupied' },
          { name: 'ESD · Pam’s team', state: 'bad', text: i.reason.startsWith('Occupied') ? 'Not engaged' : `Last update ${i.days}d ago` },
          { name: 'Palladium / AFS', state: 'ok', text: 'Inspection current' },
        ],
        missing: ['Attorney assignment', 'Latest occupancy inspection photos'],
        next: i.reason.startsWith('Occupied') ? 'Route the file to ESD (Pam’s team) with the occupancy report attached.' : 'Request a status update from ESD on attorney communication and the hearing date.',
        reasoning: ['Occupied files stall pre-marketing entirely', 'Weekly cadence per AM operating model'],
        history: [...base.history, { date: day(i.days), text: 'Occupancy result: occupied', tone: 'red' }],
      }
    case 'closing':
      return {
        why: `${i.reason}. ${i.detail}. Closing delays push out funds and can trigger amended closing tasks.`,
        sources: [
          { name: 'ResWare', state: 'bad', text: 'Condition open', age: 'read-only' },
          { name: 'Equator', state: 'ok', text: 'Closing task open' },
          { name: 'DocuSign', state: 'ok', text: 'Contract fully executed' },
        ],
        missing: ['Amended closing date', 'Buyer lender status'],
        next: 'Follow up with the buyer agent and title on the amended date, open conditions and any per diem owed.',
        reasoning: ['Past target closing date', 'Per diem must be captured at closing (SPS)'],
        history: [...base.history, { date: day(30), text: 'Contract executed' }, { date: day(i.days), text: 'Target closing date passed', tone: 'red' }],
      }
    default:
      return {
        why: i.queue === 'actions' ? `${i.reason}. This is ready for your decision and will move the property forward.` : `${i.reason}. Tracked automatically, and it comes back to Exceptions if the expected update doesn't arrive.`,
        sources: [
          { name: 'Equator', state: 'ok', text: 'Task open' },
          { name: 'Hubzu', state: p.phase === 'pre' ? 'idle' : 'ok', text: p.phase === 'pre' ? 'Not listed' : 'Listed' },
          { name: 'ResWare', state: p.titleTrack ? 'ok' : 'idle', text: p.titleTrack ? 'Title in progress' : 'Not started' },
        ],
        missing: [],
        next: i.nextAction,
        reasoning: [i.detail],
        history: base.history,
      }
  }
}
