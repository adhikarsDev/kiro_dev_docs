import { navigate } from '../lib/router'
import { useApp } from '../lib/store'
import type { WorkItem } from '../data/mock'

export type Origin = { x: number; y: number } | undefined
export const originOf = (e?: { currentTarget: EventTarget | null }) => {
  const el = e?.currentTarget as HTMLElement | null
  if (!el?.getBoundingClientRect) return undefined
  const r = el.getBoundingClientRect()
  return { x: r.left + r.width / 2, y: r.top + r.height / 2 }
}

/** One place that maps a work item's "next best action" to the flow that resolves it. */
export function performAction(item: WorkItem, origin?: Origin) {
  const s = useApp.getState()
  switch (item.actionKind) {
    case 'vendor':
    case 'investor':
    case 'eviction':
    case 'closing':
      if (item.signal) return s.openBatch({ signal: item.signal, itemIds: [item.id], origin })
      return s.select(item.id)
    case 'recommendation':
      return navigate(`/rec/${item.propertyId}`)
    case 'contract':
      return s.openConfirm({ kind: 'contract', itemId: item.id, origin })
    case 'approve':
      return s.openConfirm({ kind: 'approve', itemId: item.id, origin })
    case 'review':
      return navigate(`/property/${item.propertyId}`)
    case 'view':
      if (item.queue === 'approvals') return navigate(`/approval/${item.propertyId}`)
      return s.select(item.id)
  }
}
