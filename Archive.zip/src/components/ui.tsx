import { useEffect, useRef, type ReactNode } from 'react'
import { animate, motion, useInView, useMotionValue, useMotionValueEvent, useReducedMotion, useSpring } from 'framer-motion'
import { Check as CheckIcon } from 'lucide-react'
import { fadeUp, inView, spring, springSnappy } from '../lib/motion'
import { LIFECYCLE, PHASES, type Phase, type Risk } from '../data/mock'

/* Animated number — springs from its current on-screen value (interruptible). */
export function AnimatedNumber({
  value, format = (n) => Math.round(n).toLocaleString('en-US'), className, duration = 0.9,
}: { value: number; format?: (n: number) => string; className?: string; duration?: number }) {
  const ref = useRef<HTMLSpanElement>(null)
  const mv = useMotionValue(0)
  const seen = useInView(ref, { once: true, amount: 0.3 })
  const reduce = useReducedMotion()
  useEffect(() => {
    if (!seen) return
    const c = animate(mv, value, reduce ? { duration: 0 } : { type: 'spring', bounce: 0, duration })
    return () => c.stop()
  }, [seen, value, reduce, duration, mv])
  useMotionValueEvent(mv, 'change', (v) => { if (ref.current) ref.current.textContent = format(v) })
  return <span ref={ref} className={className}>{format(mv.get())}</span>
}

/* Segmented control with a sliding thumb (shared layout). */
export function Segmented<T extends string>({
  items, value, onChange, layoutId, size,
}: {
  items: { key: T; label: ReactNode; count?: number; tone?: string }[]
  value: T
  onChange: (k: T) => void
  layoutId: string
  size?: 'sm'
}) {
  return (
    <div className="seg" role="tablist">
      {items.map((it) => {
        const on = it.key === value
        return (
          <button
            key={it.key}
            role="tab"
            aria-selected={on}
            className={`seg-item ${on ? 'on' : ''}`}
            style={size === 'sm' ? { height: 26, padding: '0 11px', fontSize: 12.5 } : undefined}
            data-tone={it.tone}
            onClick={() => onChange(it.key)}
          >
            {on && <motion.span layoutId={layoutId} className="seg-thumb" transition={springSnappy} />}
            <span>{it.label}</span>
            {it.count != null && (
              <span className="seg-count">
                <AnimatedNumber value={it.count} duration={0.5} />
              </span>
            )}
          </button>
        )
      })}
    </div>
  )
}

export function Sparkline({ values, w = 72, h = 24, tone = 'blue', fill = true }: { values: number[]; w?: number; h?: number; tone?: string; fill?: boolean }) {
  const min = Math.min(...values), max = Math.max(...values)
  const span = max - min || 1
  const pts = values.map((v, i) => [(i / (values.length - 1)) * (w - 4) + 2, h - 3 - ((v - min) / span) * (h - 6)])
  const d = pts.map((p, i) => `${i ? 'L' : 'M'}${p[0].toFixed(1)},${p[1].toFixed(1)}`).join(' ')
  const last = pts[pts.length - 1]
  return (
    <svg className="spark" width={w} height={h} data-tone={tone} aria-hidden>
      {fill && <path d={`${d} L${last[0]},${h} L${pts[0][0]},${h} Z`} style={{ fill: 'var(--tone-bg-2)', stroke: 'none' }} />}
      <motion.path d={d} style={{ stroke: 'var(--tone)' }} initial={{ pathLength: 0 }} whileInView={{ pathLength: 1 }} viewport={{ once: true }} transition={{ duration: 1.1, ease: [0.32, 0.72, 0, 1] }} />
      <circle cx={last[0]} cy={last[1]} r={2.6} style={{ fill: 'var(--tone)' }} />
    </svg>
  )
}

const PHASE_TONE: Record<Phase, string> = { pre: 'indigo', on: 'teal', contract: 'orange', closing: 'blue', sold: 'gray' }
export const phaseTone = (p: Phase) => PHASE_TONE[p]
export function PhasePill({ phase }: { phase: Phase }) {
  return <span className="pill" data-tone={PHASE_TONE[phase]}>{PHASES.find((x) => x.key === phase)!.label.replace(' · 30d', '')}</span>
}
export const riskTone = (r: Risk) => (r === 'High' ? 'red' : r === 'Medium' ? 'orange' : 'gray')
export function RiskPill({ risk }: { risk: Risk }) {
  return <span className="pill pill-dot" data-tone={riskTone(risk)}>{risk}</span>
}

export function Reveal({ children, className, delay = 0, as = 'div' }: { children: ReactNode; className?: string; delay?: number; as?: 'div' | 'section' }) {
  const C = as === 'section' ? motion.section : motion.div
  return (
    <C className={className} variants={fadeUp} initial="hidden" whileInView="show" viewport={inView} transition={{ ...spring, duration: 0.6, delay }}>
      {children}
    </C>
  )
}

export function Check({ on, onClick, label }: { on: boolean; onClick?: (e: React.MouseEvent) => void; label?: string }) {
  return (
    <motion.span role="checkbox" aria-checked={on} aria-label={label} tabIndex={0} className={`check ${on ? 'on' : ''}`} onClick={onClick}
      whileTap={{ scale: 0.85 }}
      onKeyDown={(e) => { if (e.key === ' ' || e.key === 'Enter') { e.preventDefault(); onClick?.(e as unknown as React.MouseEvent) } }}>
      {on && <motion.span initial={{ scale: 0.4, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} transition={springSnappy}><CheckIcon size={13} strokeWidth={3.2} /></motion.span>}
    </motion.span>
  )
}

/* Lifecycle stepper — the fill line draws in on mount. */
export function Stepper({ stage, dates, steps = LIFECYCLE, compact }: { stage: number; dates?: string[]; steps?: string[]; compact?: boolean }) {
  const n = steps.length
  const inset = `calc(100% / ${n * 2})`
  return (
    <div className="stepper" style={compact ? { transform: 'scale(.92)', transformOrigin: 'left' } : undefined}>
      <div className="step-line" style={{ left: inset, right: inset }} />
      <motion.div className="step-line-fill" style={{ left: inset, width: `calc((100% - 100% / ${n}) * ${stage / (n - 1)})` }}
        initial={{ scaleX: 0 }} whileInView={{ scaleX: 1 }} viewport={{ once: true }} transition={{ duration: 1.1, ease: [0.32, 0.72, 0, 1] }} />
      {steps.map((s, i) => {
        const state = i < stage ? 'done' : i === stage ? 'cur' : ''
        return (
          <motion.div key={s} className={`step ${state}`} initial={{ opacity: 0, y: 6 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }}
            transition={{ ...spring, delay: 0.05 * i }}>
            <div className="step-dot">{i < stage ? <CheckIcon size={14} strokeWidth={3} /> : i + 1}</div>
            {!compact && <div className="lbl">{s}</div>}
            {!compact && dates?.[i] && <div className="dt">{dates[i]}</div>}
          </motion.div>
        )
      })}
    </div>
  )
}

export function ConfidenceRing({ value, size = 104, stroke = 10, tone = 'green' }: { value: number; size?: number; stroke?: number; tone?: string }) {
  const r = (size - stroke) / 2
  return (
    <div style={{ position: 'relative', width: size, height: size }} data-tone={tone}>
      <svg width={size} height={size} style={{ transform: 'rotate(-90deg)' }}>
        <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke="var(--fill)" strokeWidth={stroke} />
        <motion.circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke="var(--tone)" strokeWidth={stroke} strokeLinecap="round"
          initial={{ pathLength: 0 }} whileInView={{ pathLength: value / 100 }} viewport={{ once: true }} transition={{ duration: 1.3, ease: [0.32, 0.72, 0, 1] }} />
      </svg>
      <div style={{ position: 'absolute', inset: 0, display: 'grid', placeItems: 'center' }}>
        <span className="ring-num" style={{ fontSize: size * 0.26 }}><AnimatedNumber value={value} />%</span>
      </div>
    </div>
  )
}

export function SectionHead({ title, sub, right, eyebrow }: { title: ReactNode; sub?: ReactNode; right?: ReactNode; eyebrow?: ReactNode }) {
  return (
    <div className="hstack gap-12 wrap" style={{ alignItems: 'flex-end' }}>
      <div className="stack gap-4 min0" style={{ flex: 1 }}>
        {eyebrow && <div className="t-eyebrow">{eyebrow}</div>}
        <div className="t-title2">{title}</div>
        {sub && <div className="t-sub">{sub}</div>}
      </div>
      {right}
    </div>
  )
}

/* Apple Activity–style rings: today's progress, in pastel. */
export function DayRings({ rings, size = 148, stroke = 13 }: { rings: { label: string; done: number; total: number; tone: string }[]; size?: number; stroke?: number }) {
  const gap = 3
  return (
    <div className="hstack gap-20">
      <svg width={size} height={size} style={{ transform: 'rotate(-90deg)', flex: 'none' }} aria-hidden>
        {rings.map((r, i) => {
          const rad = size / 2 - stroke / 2 - i * (stroke + gap)
          const pct = r.total ? Math.min(1, r.done / r.total) : 0
          return (
            <g key={r.label} data-tone={r.tone}>
              <circle cx={size / 2} cy={size / 2} r={rad} fill="none" stroke="var(--tone-bg)" strokeWidth={stroke} />
              <motion.circle className="ring-arc" cx={size / 2} cy={size / 2} r={rad} fill="none" stroke="var(--tone)" strokeWidth={stroke} strokeLinecap="round"
                initial={{ pathLength: 0 }} animate={{ pathLength: Math.max(0.001, pct) }} transition={{ type: 'spring', bounce: 0, duration: 1.2, delay: 0.15 + i * 0.12 }} />
            </g>
          )
        })}
      </svg>
      <div className="rings-legend">
        {rings.map((r) => (
          <div key={r.label} className="row" data-tone={r.tone}>
            <i />
            <span className="v"><AnimatedNumber value={r.done} duration={0.8} /> <span>/ {r.total}</span></span>
            <span className="l">{r.label}</span>
          </div>
        ))}
      </div>
    </div>
  )
}

/* Pointer-tracked spotlight + edge glow, with optional spring tilt (after React Bits SpotlightCard / TiltedCard). */
export function SpotlightCard({ children, className = '', style, tilt = 0, tone, as = 'div', ...rest }:
  { children: ReactNode; className?: string; style?: React.CSSProperties; tilt?: number; tone?: string; as?: 'div' | 'button' } & Record<string, unknown>) {
  const ref = useRef<HTMLElement>(null)
  const reduce = useReducedMotion()
  const rx = useSpring(0, { stiffness: 180, damping: 22 })
  const ry = useSpring(0, { stiffness: 180, damping: 22 })
  const C = as === 'button' ? motion.button : motion.div
  const move = (e: React.PointerEvent) => {
    const el = ref.current
    if (!el) return
    const r = el.getBoundingClientRect()
    const x = e.clientX - r.left, y = e.clientY - r.top
    el.style.setProperty('--mx', `${x}px`)
    el.style.setProperty('--my', `${y}px`)
    if (tilt && !reduce) { ry.set(((x / r.width) - 0.5) * tilt); rx.set(-((y / r.height) - 0.5) * tilt) }
  }
  return (
    <C ref={ref as never} className={`spot-card ${className}`} data-tone={tone}
      style={{ ...style, rotateX: rx, rotateY: ry, transformPerspective: 1200 }}
      onPointerMove={move}
      onPointerEnter={() => ref.current?.style.setProperty('--spot', '1')}
      onPointerLeave={() => { ref.current?.style.setProperty('--spot', '0'); rx.set(0); ry.set(0) }}
      {...rest}>
      {children}
    </C>
  )
}
