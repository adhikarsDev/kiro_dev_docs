import { createRoot } from 'react-dom/client'
import './styles/index.css'
import App from './App'

if ('scrollRestoration' in history) history.scrollRestoration = 'manual'

createRoot(document.getElementById('root')!).render(
  // StrictMode is off: drei <Html> labels mount their own React roots, and the
  // dev-only double mount makes them unmount mid-render under React 19.
  <App />,
)
