import { useMemo, useRef } from 'react'
import { Canvas, useFrame } from '@react-three/fiber'
import { ContactShadows, OrbitControls, RoundedBox } from '@react-three/drei'
import * as THREE from 'three'

/** Stylised low-poly house. Windows glow when occupied; a status beacon floats above. */
function House({ occupied, beacon, dark, reduce }: { occupied: boolean; beacon: string; dark: boolean; reduce: boolean }) {
  const ring = useRef<THREE.Mesh>(null)
  const roof = useMemo(() => {
    const s = new THREE.Shape()
    s.moveTo(-0.95, 0); s.lineTo(0, 0.72); s.lineTo(0.95, 0); s.lineTo(-0.95, 0)
    const g = new THREE.ExtrudeGeometry(s, { depth: 1.5, bevelEnabled: true, bevelSize: 0.03, bevelThickness: 0.03, bevelSegments: 2 })
    g.translate(0, 0, -0.75)
    return g
  }, [])
  useFrame(({ clock }) => {
    if (!ring.current || reduce) return
    const t = clock.elapsedTime
    ring.current.position.y = 2.05 + Math.sin(t * 1.6) * 0.06
    ring.current.rotation.z = t * 0.8
  })
  const wall = dark ? '#d8d4cc' : '#f4efe6'
  const win = occupied ? '#ffcf70' : dark ? '#2a3542' : '#9fb4c8'
  return (
    <group position={[0, -0.55, 0]}>
      <RoundedBox args={[1.6, 1.0, 1.3]} radius={0.04} position={[0, 0.5, 0]} castShadow receiveShadow>
        <meshStandardMaterial color={wall} roughness={0.8} />
      </RoundedBox>
      <mesh geometry={roof} position={[0, 1.0, 0]} castShadow>
        <meshStandardMaterial color={dark ? '#7a4a3a' : '#b4553c'} roughness={0.6} />
      </mesh>
      <mesh position={[0.48, 1.42, -0.25]} castShadow>
        <boxGeometry args={[0.18, 0.42, 0.18]} />
        <meshStandardMaterial color="#8b8178" roughness={0.9} />
      </mesh>
      {/* door */}
      <mesh position={[0, 0.32, 0.655]}>
        <boxGeometry args={[0.3, 0.56, 0.03]} />
        <meshStandardMaterial color="#3a5f8a" roughness={0.5} />
      </mesh>
      {/* windows */}
      {[[-0.48, 0.55], [0.48, 0.55]].map(([x, y]) => (
        <mesh key={x} position={[x, y, 0.655]}>
          <boxGeometry args={[0.32, 0.28, 0.03]} />
          <meshStandardMaterial color={win} emissive={occupied ? '#ffb340' : '#000'} emissiveIntensity={occupied ? 0.9 : 0} roughness={0.2} metalness={0.2} />
        </mesh>
      ))}
      <mesh position={[0.805, 0.55, 0]} rotation={[0, Math.PI / 2, 0]}>
        <boxGeometry args={[0.36, 0.28, 0.03]} />
        <meshStandardMaterial color={win} emissive={occupied ? '#ffb340' : '#000'} emissiveIntensity={occupied ? 0.9 : 0} roughness={0.2} />
      </mesh>
      {/* tree */}
      <group position={[-1.25, 0, 0.35]}>
        <mesh position={[0, 0.22, 0]}><cylinderGeometry args={[0.05, 0.06, 0.44, 8]} /><meshStandardMaterial color="#7b5b3e" /></mesh>
        <mesh position={[0, 0.72, 0]} castShadow><icosahedronGeometry args={[0.36, 0]} /><meshStandardMaterial color={dark ? '#2f8a4a' : '#4cb36a'} roughness={0.7} flatShading /></mesh>
      </group>
      {/* lawn */}
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, 0.001, 0]} receiveShadow>
        <circleGeometry args={[1.9, 48]} />
        <meshStandardMaterial color={dark ? '#1f3a2a' : '#cfe8d2'} roughness={1} />
      </mesh>
      {/* status beacon */}
      <mesh ref={ring} position={[0, 2.05, 0]} rotation={[Math.PI / 2, 0, 0]}>
        <torusGeometry args={[0.16, 0.035, 12, 40]} />
        <meshStandardMaterial color={beacon} emissive={beacon} emissiveIntensity={1.2} />
      </mesh>
    </group>
  )
}

export default function HouseModel({ occupied, beacon, dark, reduce }: { occupied: boolean; beacon: string; dark: boolean; reduce: boolean }) {
  return (
    <Canvas dpr={[1, 2]} shadows="percentage" camera={{ position: [3.2, 2.1, 3.6], fov: 34 }} gl={{ antialias: true, alpha: true }}>
      <ambientLight intensity={dark ? 0.5 : 0.8} />
      <directionalLight position={[4, 6, 3]} intensity={1.6} castShadow shadow-mapSize={[1024, 1024]} />
      <hemisphereLight args={['#ffffff', '#b7c4d8', 0.4]} />
      <House occupied={occupied} beacon={beacon} dark={dark} reduce={reduce} />
      <ContactShadows position={[0, -0.55, 0]} opacity={0.35} scale={6} blur={2.2} far={2} />
      <OrbitControls enableZoom={false} enablePan={false} autoRotate={!reduce} autoRotateSpeed={0.9} minPolarAngle={0.9} maxPolarAngle={1.35} target={[0, 0.25, 0]} />
    </Canvas>
  )
}
