import { useMemo, useRef, useState } from 'react'
import { Canvas, useFrame } from '@react-three/fiber'
import { ContactShadows, OrbitControls, RoundedBox } from '@react-three/drei'
import { Projector, type AnchorMap, type ElMap } from './overlay'
import * as THREE from 'three'

// Sequential blue ramp (one hue, light → dark) for aging magnitude.
const RAMP = ['#9ec5f4', '#6da7ec', '#3987e5', '#256abf', '#184f95']
const RAMP_DARK = ['#86b6ef', '#5598e7', '#2a78d6', '#1c5cab', '#104281']

interface Props {
  rows: { label: string; values: number[] }[]
  buckets: string[]
  dark: boolean
  reduce: boolean
  running: boolean
}

function Bar({ x, z, value, max, color, label, delay, reduce, hovered, onHover }: {
  x: number; z: number; value: number; max: number; color: string; label: string; delay: number; reduce: boolean; hovered: boolean; onHover: (s: string | null) => void
}) {
  const ref = useRef<THREE.Group>(null)
  const t = useRef(reduce ? 10 : 0)
  const h = Math.max(0.06, (value / max) * 3.2)
  useFrame((_, dt) => {
    t.current += dt
    const k = Math.min(1, Math.max(0, (t.current - delay) / 0.9))
    const e = 1 - Math.pow(1 - k, 3)
    if (ref.current) {
      ref.current.scale.y = Math.max(0.001, e)
      const target = hovered ? 1.06 : 1
      ref.current.scale.x = THREE.MathUtils.damp(ref.current.scale.x, target, 10, dt)
      ref.current.scale.z = ref.current.scale.x
    }
  })
  return (
    <group position={[x, 0, z]}>
      <group ref={ref}>
        <RoundedBox args={[0.62, h, 0.62]} radius={0.05} smoothness={3} position={[0, h / 2, 0]} castShadow
          onPointerOver={(e) => { e.stopPropagation(); onHover(label); document.body.style.cursor = 'pointer' }}
          onPointerOut={() => { onHover(null); document.body.style.cursor = '' }}>
          <meshStandardMaterial color={color} roughness={0.35} metalness={0.05} emissive={hovered ? color : '#000'} emissiveIntensity={hovered ? 0.35 : 0} />
        </RoundedBox>
      </group>
    </group>
  )
}

export default function AgingSkyline({ rows, buckets, dark, reduce, running }: Props) {
  const [hover, setHover] = useState<string | null>(null)
  const max = useMemo(() => Math.max(...rows.flatMap((r) => r.values)), [rows])
  const ramp = dark ? RAMP_DARK : RAMP
  const gap = 1.0
  const ox = -((buckets.length - 1) * gap) / 2, oz = -((rows.length - 1) * gap) / 2
  const els = useRef<ElMap>({})
  const anchors = useRef<AnchorMap>({})
  const next: AnchorMap = {}
  rows.forEach((r, ri) => { const v = new THREE.Vector3(ox + (buckets.length - 1) * gap + 0.55, 0.05, oz + ri * gap); next[`r${ri}`] = () => v })
  buckets.forEach((b, bi) => { const v = new THREE.Vector3(ox + bi * gap, 0, oz + rows.length * gap - 0.25); next[`b${bi}`] = () => v })
  let hv: { v: number; label: string } | null = null
  if (hover) {
    const [rl, bl] = hover.split('|')
    const ri = rows.findIndex((r) => r.label === rl), bi = buckets.indexOf(bl)
    const val = rows[ri].values[bi]
    const top = new THREE.Vector3(ox + bi * gap, Math.max(0.06, (val / max) * 3.2) + 0.25, oz + ri * gap)
    next.tip = () => top
    hv = { v: val, label: hover }
  }
  anchors.current = next
  return (
    <div style={{ position: 'absolute', inset: 0 }}>
    <Canvas frameloop={running ? 'always' : 'never'} dpr={[1, 2]} shadows="percentage" camera={{ position: [6.2, 6.4, 8.6], fov: 32 }} gl={{ antialias: true, alpha: true }}>
      <ambientLight intensity={dark ? 0.5 : 0.8} />
      <directionalLight position={[5, 9, 4]} intensity={1.5} castShadow shadow-mapSize={[1024, 1024]} />
      <group position={[-((buckets.length - 1) * gap) / 2, 0, -((rows.length - 1) * gap) / 2]}>
        {rows.map((r, ri) => r.values.map((v, bi) => {
          const label = `${r.label}|${buckets[bi]}`
          return (
            <Bar key={label} x={bi * gap} z={ri * gap} value={v} max={max} color={ramp[bi]} label={label} delay={0.1 + (ri + bi) * 0.06}
              reduce={reduce} hovered={hover === label} onHover={setHover} />
          )
        }))}
        <mesh rotation={[-Math.PI / 2, 0, 0]} position={[((buckets.length - 1) * gap) / 2, -0.001, ((rows.length - 1) * gap) / 2]} receiveShadow>
          <planeGeometry args={[buckets.length * gap + 0.6, rows.length * gap + 0.6]} />
          <meshStandardMaterial color={dark ? '#1c1c1e' : '#ffffff'} roughness={0.9} />
        </mesh>
      </group>
      <ContactShadows position={[0, -0.01, 0]} opacity={0.25} scale={14} blur={2} far={4} />
      <OrbitControls enableZoom={false} enablePan={false} minPolarAngle={0.6} maxPolarAngle={1.2} minAzimuthAngle={-0.2} maxAzimuthAngle={1.4}
        target={[0, 0.8, 0]} autoRotate={false} />
      <Projector anchors={anchors} els={els} />
    </Canvas>
    <div className="scene-overlay" aria-hidden>
      {rows.map((r, ri) => (
        <div key={r.label} className="anchor" ref={(el) => { els.current[`r${ri}`] = el }}>
          <div className="scene-label" style={{ transform: 'translate(0, -50%)', textAlign: 'left' }}><div className="p">{r.label}</div></div>
        </div>
      ))}
      {buckets.map((b, bi) => (
        <div key={b} className="anchor" ref={(el) => { els.current[`b${bi}`] = el }}>
          <div className="scene-label"><div className="t-caption">{b}</div></div>
        </div>
      ))}
      <div className="anchor" ref={(el) => { els.current.tip = el }} style={{ display: hv ? 'block' : 'none', zIndex: 3 }}>
        {hv && <div className="scene-tip"><div className="strong">{hv.label.split('|')[0]}</div><div className="row-k"><span>{hv.label.split('|')[1]}</span><b>{hv.v} properties</b></div></div>}
      </div>
    </div>
    </div>
  )
}
