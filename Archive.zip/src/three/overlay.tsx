import { useMemo } from 'react'
import { useFrame } from '@react-three/fiber'
import * as THREE from 'three'

/**
 * Projects 3D anchor points to a plain DOM overlay each frame.
 * Labels stay ordinary React DOM (crisp text, theme tokens) without
 * drei <Html>'s per-label React roots.
 */
export type AnchorMap = Record<string, () => THREE.Vector3>
export type ElMap = Record<string, HTMLElement | null>

export function Projector({ anchors, els }: { anchors: React.MutableRefObject<AnchorMap>; els: React.MutableRefObject<ElMap> }) {
  const v = useMemo(() => new THREE.Vector3(), [])
  useFrame(({ camera, size }) => {
    for (const id in anchors.current) {
      const el = els.current[id]
      if (!el) continue
      v.copy(anchors.current[id]()).project(camera)
      const x = (v.x * 0.5 + 0.5) * size.width
      const y = (-v.y * 0.5 + 0.5) * size.height
      el.style.transform = `translate3d(${x.toFixed(1)}px, ${y.toFixed(1)}px, 0)`
      el.style.visibility = v.z < 1 ? 'visible' : 'hidden'
    }
  })
  return null
}
