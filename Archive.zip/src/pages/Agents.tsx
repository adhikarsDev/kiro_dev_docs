import { useEffect, useState } from 'react'
import { AnimatePresence, motion, useReducedMotion } from 'framer-motion'
import { Activity, CalendarClock, ClipboardList, FileText, Handshake, Hourglass, House, Info, Play, ShieldCheck, Sparkles, Tag, Timer, TrendingUp } from 'lucide-react'
import { AGENTS, PROPERTIES } from '../data/mock'
import { fadeUp, inView, spring, springSheet, stagger } from '../lib/motion'
import { AnimatedNumber, ConfidenceRing, Segmented, SpotlightCard } from '../components/ui'
import { useApp } from '../lib/store'
import { DATA_INPUTS } from '../data/market'
import { DataReadiness } from '../features/evidence'
import { navigate } from '../lib/router'

const ICON = { pre: House, cmp: ClipboardList, reserve: Tag, rmp: TrendingUp, offer: Handshake, investor: Hourglass, closing: CalendarClock } as const
type Status = 'Queued' | 'Analyzing' | 'Ready for review' | 'Blocked' | 'Completed'
const STATUS_TONE: Record<Status, string> = { Queued: 'gray', Analyzing: 'blue', 'Ready for review': 'green', Blocked: 'red', Completed: 'teal' }
interface Ev { id: number; agent: string; prop: string; status: Status; note: string; at: string }

const SEED: Ev[] = [
  { id: 1, agent: 'Pre-Marketing Monitor', prop: '4321 Elm St, Houston, TX', status: 'Analyzing', note: 'Started 2 min ago', at: '9:48' },
  { id: 2, agent: 'Set Reserve Price', prop: '1500 Palm Way, Las Vegas, NV', status: 'Ready for review', note: 'Completed 6 min ago', at: '9:44' },
  { id: 3, agent: 'Investor Approval', prop: '2222 Cedar Ln, Orlando, FL', status: 'Queued', note: 'In queue 8 min ago', at: '9:42' },
  { id: 4, agent: 'Review Marketing Plan', prop: '9101 Pine Rd, Atlanta, GA', status: 'Blocked', note: 'Missing Hubzu analytics data', at: '9:38' },
  { id: 5, agent: 'Offer Acceptance', prop: '3456 Birch Ct, Charlotte, NC', status: 'Completed', note: 'Completed 18 min ago', at: '9:32' },
]

function AgentInfo({ text, mode }: { text: string; mode: string }) {
  const [open, setOpen] = useState(false)
  return (
    <span style={{ position: 'relative', display: 'inline-flex' }} onMouseEnter={() => setOpen(true)} onMouseLeave={() => setOpen(false)} onFocus={() => setOpen(true)} onBlur={() => setOpen(false)}>
      <button className="icon-btn" style={{ width: 22, height: 22, borderRadius: 11 }} aria-label="About this agent"><Info size={14} /></button>
      <AnimatePresence>
        {open && (
          <motion.span className="tooltip" style={{ left: -8, top: 28, width: 260, whiteSpace: 'normal', lineHeight: 1.45, transformOrigin: 'top left' }}
            initial={{ opacity: 0, y: -4, scale: 0.97 }} animate={{ opacity: 1, y: 0, scale: 1 }} exit={{ opacity: 0, y: -4, scale: 0.97 }} transition={{ duration: 0.16 }}>
            {text}<br /><span className="t-caption">{mode === 'Shadow' ? 'Shadow: observes and recommends, never writes.' : 'Supervised: queues the exact action for your review.'}</span>
          </motion.span>
        )}
      </AnimatePresence>
    </span>
  )
}

type Agent = (typeof AGENTS)[number]
const MARKET_AWARE = new Set<Agent['key']>(['cmp', 'reserve', 'rmp', 'offer'])
const META: Record<Agent['key'], { tone: string; tagline: string; hours: number; accept: number }> = {
  pre: { tone: 'peach', tagline: 'Occupancy, services & trash-out', hours: 6.4, accept: 88 },
  cmp: { tone: 'lavender', tagline: 'Drafts the full marketing plan', hours: 9.2, accept: 91 },
  reserve: { tone: 'sand', tagline: 'Auction reserve & approval pack', hours: 3.1, accept: 84 },
  rmp: { tone: 'sky', tagline: 'Two-week price reviews', hours: 5.8, accept: 82 },
  offer: { tone: 'mint', tagline: 'Net-to-seller offer analysis', hours: 7.5, accept: 87 },
  investor: { tone: 'rose', tagline: 'Chases investor decisions daily', hours: 8.3, accept: 93 },
  closing: { tone: 'teal', tagline: 'Contract-to-close milestones', hours: 2.9, accept: 86 },
}

/* Agent card: GlassIcon + aura header, shine border sweep and spotlight (after React Bits GlassIcons / MagicBento / BorderGlow, 21st.dev Shine Border). */
function AgentCard({ a, live, pickerOpen, onToggle, onRun }: { a: Agent; live: boolean; pickerOpen: boolean; onToggle: () => void; onRun: (pid: string) => void }) {
  const Icon = ICON[a.key]
  const m = META[a.key]
  const ready = a.eligible - a.exceptions - a.blockers
  const segs = [
    { k: 'Ready', v: ready, tone: m.tone },
    { k: 'Exceptions', v: a.exceptions, tone: 'rose' },
    { k: 'Blocked', v: a.blockers, tone: 'sand' },
  ]
  return (
    <motion.div variants={fadeUp} layout transition={spring} style={{ display: 'flex', position: 'relative', zIndex: pickerOpen ? 5 : undefined }}>
      <SpotlightCard className="agent2" tone={m.tone} tilt={3} style={{ flex: 1 }}>
        <div className="agent2-aura">
          <div className="glass-icon"><span className="back" /><span className="front"><Icon size={23} strokeWidth={2} /></span></div>
          <span className="spacer" />
          <div className="stack" style={{ alignItems: 'flex-end', gap: 6 }}>
            <span className={`agent-live ${live ? 'on' : ''}`}><i />{live ? 'Working' : 'Idle'}</span>
            <span className="hstack gap-6">
              {MARKET_AWARE.has(a.key) && <span className="pill" data-tone="mint" title="Uses MSA market signals + property performance">Market-aware</span>}
              <span className="pill" data-tone={a.mode === 'Shadow' ? 'lavender' : 'sky'} title={a.mode === 'Shadow' ? 'Observes and recommends, never writes' : 'Queues the exact action for your review'}>{a.mode}</span>
            </span>
          </div>
        </div>
        <div className="agent2-body">
          <div className="stack" style={{ gap: 2 }}>
            <span className="hstack gap-6"><span className="t-title3">{a.name}</span><AgentInfo text={a.desc} mode={a.mode} /></span>
            <span className="t-sub">{m.tagline}</span>
          </div>
          <div className="hstack gap-12">
            <div className="stack" style={{ flex: 1 }}>
              <span className="agent-big"><AnimatedNumber value={a.eligible} /></span>
              <span className="t-caption">properties in scope</span>
            </div>
            <div className="hstack gap-8">
              <ConfidenceRing value={m.accept} size={52} stroke={5.5} tone={m.tone} />
              <span className="t-caption" style={{ width: 70, lineHeight: 1.3 }}>accepted<br />as drafted</span>
            </div>
          </div>
          <div className="stack gap-6">
            <div className="agent-segbar">
              {segs.map((s, i) => (
                <motion.span key={s.k} data-tone={s.tone} initial={{ flexGrow: 0 }} whileInView={{ flexGrow: s.v }} viewport={{ once: true }} transition={{ ...spring, duration: 0.9, delay: 0.15 + i * 0.08 }} />
              ))}
            </div>
            <div className="hstack gap-12 wrap">
              {segs.map((s) => <span key={s.k} className="agent-leg" data-tone={s.tone}><i /><b className="num">{s.v}</b> {s.k.toLowerCase()}</span>)}
            </div>
          </div>
          <div className="agent2-foot">
            <span className="hstack gap-6 t-sub" style={{ flex: 1 }}><Timer size={14} style={{ color: 'var(--tone-text)' }} /><b style={{ color: 'var(--label)' }}>{m.hours} h</b> saved this week</span>
            <div style={{ position: 'relative' }}>
              <motion.button className="btn btn-tone" whileTap={{ scale: 0.96 }} onClick={onToggle}><Play size={13} fill="currentColor" />Run agent</motion.button>
              <AnimatePresence>
                {pickerOpen && (
                  <motion.div initial={{ opacity: 0, scale: 0.92, y: -6 }} animate={{ opacity: 1, scale: 1, y: 0 }} exit={{ opacity: 0, scale: 0.92, y: -6 }} transition={springSheet}
                    style={{ position: 'absolute', right: 0, top: 42, width: 290, padding: 6, borderRadius: 14, background: 'var(--elev)', boxShadow: 'var(--shadow-4)', zIndex: 20, transformOrigin: 'top right' }}>
                    <div className="t-eyebrow" style={{ padding: '6px 10px' }}>Run on an eligible property</div>
                    {PROPERTIES.filter((p) => a.phase === 'closing' ? p.phase === 'closing' : p.phase === a.phase).slice(0, 5).map((p) => (
                      <button key={p.id} className="pal-item" style={{ width: '100%', margin: 0 }} onClick={() => onRun(p.id)}>
                        <span className="stack" style={{ flex: 1 }}><span>{p.street}</span><span className="t-caption">{p.city}, {p.state} · {p.loan}</span></span>
                      </button>
                    ))}
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </div>
          <span className="t-caption" style={{ marginTop: -6 }}>Last run today {a.last} · {a.impact.toLowerCase()}</span>
        </div>
      </SpotlightCard>
    </motion.div>
  )
}

export default function Agents() {
  const reduce = useReducedMotion()
  const toast = useApp((s) => s.toast)
  const [phase, setPhase] = useState<'all' | 'pre' | 'on' | 'closing'>('all')
  const [events, setEvents] = useState<Ev[]>(SEED)
  const [runFor, setRunFor] = useState<string | null>(null)
  const [filter, setFilter] = useState<'All' | Status>('All')

  useEffect(() => {
    if (reduce) return
    let n = 100
    const t = window.setInterval(() => {
      const a = AGENTS[Math.floor(Math.random() * AGENTS.length)]
      const p = PROPERTIES[Math.floor(Math.random() * 60)]
      const id = ++n
      setEvents((ev) => [{ id, agent: a.name, prop: `${p.street}, ${p.city}, ${p.state}`, status: 'Queued' as Status, note: 'Just now', at: 'now' }, ...ev].slice(0, 9))
      window.setTimeout(() => setEvents((ev) => ev.map((e) => (e.id === id ? { ...e, status: 'Analyzing', note: 'Reading facts & rules' } : e))), 1600)
      window.setTimeout(() => setEvents((ev) => ev.map((e) => (e.id === id ? { ...e, status: Math.random() > 0.2 ? 'Ready for review' : 'Blocked', note: Math.random() > 0.2 ? 'Recommendation ready' : 'Stale valuation · routed to review' } : e))), 4200)
    }, 6500)
    return () => window.clearInterval(t)
  }, [reduce])

  const run = (agent: string, propId: string) => {
    const p = PROPERTIES.find((x) => x.id === propId)!
    const id = Date.now()
    setEvents((ev) => [{ id, agent, prop: `${p.street}, ${p.city}, ${p.state}`, status: 'Queued' as Status, note: 'Manually triggered by you', at: 'now' }, ...ev].slice(0, 9))
    window.setTimeout(() => setEvents((ev) => ev.map((e) => (e.id === id ? { ...e, status: 'Analyzing' } : e))), 900)
    window.setTimeout(() => setEvents((ev) => ev.map((e) => (e.id === id ? { ...e, status: 'Ready for review', note: 'Recommendation ready · supervised' } : e))), 3200)
    setRunFor(null)
    toast({ title: `${agent} started`, body: `${p.street} · eligibility checks passed`, tone: 'info' })
  }

  const shown = AGENTS.filter((a) => phase === 'all' || a.phase === phase)
  const feed = events.filter((e) => filter === 'All' || e.status === filter)

  const busy = (name: string) => events.some((e) => e.agent === name && (e.status === 'Queued' || e.status === 'Analyzing'))
  const hours = AGENTS.reduce((t, a) => t + META[a.key].hours, 0)
  const running = AGENTS.filter((a) => busy(a.name)).length

  return (
    <div className="page">
      <div className="hstack gap-12 wrap" style={{ alignItems: 'flex-end' }}>
        <div className="stack gap-4" style={{ flex: 1 }}>
          <span className="t-large">AI Agents</span>
          <span className="t-sub" style={{ fontSize: 14.5 }}>Your automation team. Agents prepare the work; you decide in one click.</span>
        </div>
        <Segmented layoutId="agent-phase" value={phase} onChange={setPhase} items={[{ key: 'all', label: 'All phases' }, { key: 'pre', label: 'Pre-Marketing' }, { key: 'on', label: 'On-Market' }, { key: 'closing', label: 'Closing' }]} />
      </div>

      <motion.div className="agent-stats" variants={stagger(0.06)} initial="hidden" animate="show">
        {[
          { icon: Timer, tone: 'mint', v: hours, f: (n: number) => n.toFixed(1), u: 'h', l: 'Saved for you this week' },
          { icon: Sparkles, tone: 'sky', v: 89, f: (n: number) => Math.round(n).toString(), u: '', l: 'Recommendations prepared' },
          { icon: ShieldCheck, tone: 'lavender', v: 85, f: (n: number) => Math.round(n).toString(), u: '%', l: 'Accepted as drafted' },
          { icon: Activity, tone: 'peach', v: running, f: (n: number) => Math.round(n).toString(), u: '', l: 'Agents working right now' },
        ].map((x) => (
          <motion.div key={x.l} className="rec-stat" variants={fadeUp}>
            <span className="rec-ico" data-tone={x.tone}><x.icon size={18} /></span>
            <div className="stack"><span className="v"><AnimatedNumber value={x.v} format={x.f} />{x.u && <span style={{ fontSize: 16, color: 'var(--label-3)', marginLeft: 2 }}>{x.u}</span>}</span><span className="t-caption">{x.l}</span></div>
          </motion.div>
        ))}
      </motion.div>

      <div className="grid g-12" style={{ alignItems: 'start' }}>
        <motion.div className="span-8 r-full grid" style={{ gridTemplateColumns: 'repeat(auto-fill, minmax(320px, 1fr))', gap: 18 }} variants={stagger(0.06)} initial="hidden" animate="show" key={phase}>
          {shown.map((a) => (
            <AgentCard key={a.key} a={a} live={busy(a.name)} pickerOpen={runFor === a.key} onToggle={() => setRunFor(runFor === a.key ? null : a.key)} onRun={(pid) => run(a.name, pid)} />
          ))}
        </motion.div>

        <div className="span-4 r-full stack gap-16" style={{ position: 'sticky', top: 'calc(var(--toolbar-h) + 16px)' }}>
          <motion.div className="card" variants={fadeUp} initial="hidden" animate="show">
            <div className="card-h"><span className="t-title3">Agent activity</span><span className="pill pill-dot" data-tone="green">Live</span></div>
            <div className="hstack gap-6 wrap" style={{ padding: '12px 22px 4px' }}>
              {(['All', 'Queued', 'Analyzing', 'Ready for review', 'Blocked'] as const).map((s) => (
                <button key={s} className={`chip ${filter === s ? 'on' : ''}`} style={{ height: 26, fontSize: 12 }} onClick={() => setFilter(s)}>{s}</button>
              ))}
            </div>
            <div className="card-pad" style={{ paddingTop: 6 }}>
              <AnimatePresence initial={false}>
                {feed.map((e) => (
                  <motion.div key={e.id} layout className="list-row" initial={{ opacity: 0, height: 0, y: -10 }} animate={{ opacity: 1, height: 'auto', y: 0 }} exit={{ opacity: 0, height: 0 }} transition={spring}
                    style={{ cursor: e.status === 'Ready for review' ? 'pointer' : undefined }} onClick={() => e.status === 'Ready for review' && navigate('/rec/P001')}>
                    <span className="mini-ico" data-tone={STATUS_TONE[e.status]}><FileText size={14} /></span>
                    <span className="stack min0" style={{ flex: 1 }}>
                      <span className="strong ellipsis" style={{ fontSize: 13 }}>{e.agent}</span>
                      <span className="t-caption ellipsis">{e.prop}</span>
                      <span className="t-caption ellipsis">{e.note}</span>
                    </span>
                    <AnimatePresence mode="wait" initial={false}>
                      <motion.span key={e.status} className="pill" data-tone={STATUS_TONE[e.status]} initial={{ opacity: 0, scale: 0.8 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0, scale: 0.8 }}>{e.status}</motion.span>
                    </AnimatePresence>
                  </motion.div>
                ))}
              </AnimatePresence>
            </div>
          </motion.div>
          <motion.div className="card card-pad" variants={fadeUp} initial="hidden" whileInView="show" viewport={inView}>
            <div className="hstack" style={{ marginBottom: 10 }}><span className="t-title3" style={{ flex: 1 }}>Audit & outcomes</span><span className="t-caption">Last 7 days</span></div>
            <div className="grid" style={{ gridTemplateColumns: '1fr 1fr', gap: 10 }}>
              {[['Runs', 112, 'gray'], ['Recommendations', 89, 'blue'], ['Accepted', 76, 'green'], ['Needs review', 13, 'orange'], ['Blocked', 9, 'red'], ['Auto-completed', 14, 'teal']].map(([l, v, t]) => (
                <div key={l as string} className="inset" style={{ padding: '10px 12px' }} data-tone={t as string}>
                  <div className="round" style={{ fontSize: 22, fontWeight: 700, color: t === 'gray' ? undefined : 'var(--tone-text)' }}><AnimatedNumber value={v as number} /></div>
                  <div className="t-caption">{l}</div>
                </div>
              ))}
            </div>
            <div className="callout hstack gap-8 t-caption" data-tone="blue" style={{ marginTop: 12 }}>
              <Info size={14} style={{ color: 'var(--blue-text)', flex: 'none' }} />Acceptance rate 85%. Every run stores its facts, rule version, recommendation and your decision.
            </div>
          </motion.div>
        </div>
      </div>

      <motion.div className="stack gap-4" variants={fadeUp} initial="hidden" whileInView="show" viewport={inView} style={{ marginTop: 8 }}>
        <span className="t-eyebrow">Market-aware recommendations</span>
        <span className="t-title2">What the agents use, and what we still need to source</span>
        <span className="t-sub">Agents marked Market-aware combine MSA market trends with property performance. {DATA_INPUTS.filter((d) => d.status === 'available').length} inputs are available today, {DATA_INPUTS.filter((d) => d.status === 'partial').length} are partial, and {DATA_INPUTS.filter((d) => d.status === 'sourcing').length} need a market data provider.</span>
      </motion.div>
      <motion.div variants={fadeUp} initial="hidden" whileInView="show" viewport={inView}><DataReadiness /></motion.div>
    </div>
  )
}
