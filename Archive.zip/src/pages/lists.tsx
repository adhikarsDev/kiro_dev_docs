import { useMemo, useState } from 'react'
import { motion } from 'framer-motion'
import { ArrowRight, Search } from 'lucide-react'
import { navigate } from '../lib/router'
import { useApp } from '../lib/store'
import { PHASES, PROPERTIES, money, type Phase } from '../data/mock'
import { fadeUp } from '../lib/motion'
import { PhasePill, Segmented } from '../components/ui'
import { WorkQueue } from '../features/WorkQueue'

export function MyWork() {
  return (
    <div className="page">
      <motion.div className="stack gap-4" variants={fadeUp} initial="hidden" animate="show">
        <span className="t-large">My Work</span>
        <span className="t-sub" style={{ fontSize: 14.5 }}>Every file that needs you, across all phases. Select rows to batch a follow-up, snooze or reassign.</span>
      </motion.div>
      <WorkQueue selectable search paginate />
    </div>
  )
}

export function Properties() {
  const items = useApp((s) => s.items)
  const [phase, setPhase] = useState<Phase | 'all'>('all')
  const [q, setQ] = useState('')
  const [n, setN] = useState(40)
  const status = useMemo(() => {
    const m = new Map<string, 'exceptions' | 'actions' | 'approvals' | 'watch'>()
    const order = { exceptions: 0, actions: 1, approvals: 2, watch: 3 } as const
    items.forEach((i) => { const c = m.get(i.propertyId); if (!c || order[i.queue] < order[c]) m.set(i.propertyId, i.queue) })
    return m
  }, [items])
  const list = PROPERTIES.filter((p) => (phase === 'all' || p.phase === phase) && (!q || `${p.street} ${p.city} ${p.loan} ${p.investor}`.toLowerCase().includes(q.toLowerCase())))
  const tone = { exceptions: 'red', actions: 'green', approvals: 'orange', watch: 'gray' } as const
  const label = { exceptions: 'Exception', actions: 'Action ready', approvals: 'Approval pending', watch: 'Watching' } as const
  return (
    <div className="page">
      <div className="hstack gap-12 wrap" style={{ alignItems: 'flex-end' }}>
        <div className="stack gap-4" style={{ flex: 1 }}>
          <span className="t-large">Properties</span>
          <span className="t-sub" style={{ fontSize: 14.5 }}>{PROPERTIES.length} files in your book. Open any property for its full cockpit.</span>
        </div>
        <label className="hstack gap-6 field" style={{ width: 280 }}>
          <Search size={14} className="t-3" />
          <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Address, loan # or investor" style={{ border: 0, background: 'transparent', outline: 'none', flex: 1 }} />
        </label>
      </div>
      <Segmented layoutId="prop-phase" value={phase} onChange={setPhase} items={[{ key: 'all', label: 'All', count: PROPERTIES.length }, ...PHASES.map((p) => ({ key: p.key, label: p.label, count: PROPERTIES.filter((x) => x.phase === p.key).length }))]} />
      <motion.div className="card" variants={fadeUp} initial="hidden" animate="show" style={{ overflow: 'hidden' }}>
        <table className="table">
          <thead><tr><th style={{ paddingLeft: 22 }}>Property</th><th>Phase</th><th>Investor</th><th style={{ textAlign: 'right' }}>Days in inv.</th><th style={{ textAlign: 'right' }}>List price</th><th>Status</th><th /></tr></thead>
          <tbody>
            {list.slice(0, n).map((p) => {
              const s = status.get(p.id)
              return (
                <tr key={p.id} onClick={() => navigate(`/property/${p.id}`)} style={{ cursor: 'pointer' }} className="hover-row">
                  <td style={{ paddingLeft: 22 }}><div className="strong">{p.street}</div><div className="t-caption">{p.city}, {p.state} · {p.loan}</div></td>
                  <td><PhasePill phase={p.phase} /></td>
                  <td>{p.investor}</td>
                  <td style={{ textAlign: 'right' }}>{p.daysInInventory}</td>
                  <td style={{ textAlign: 'right' }}>{money(p.listPrice)}</td>
                  <td>{s ? <span className="pill pill-dot" data-tone={tone[s]}>{label[s]}</span> : <span className="pill pill-dot" data-tone="blue">On track</span>}</td>
                  <td style={{ textAlign: 'right', paddingRight: 18 }}><ArrowRight size={15} className="t-3" /></td>
                </tr>
              )
            })}
          </tbody>
        </table>
        {list.length > n && <button className="btn btn-plain" style={{ width: '100%', height: 44 }} onClick={() => setN((x) => x + 60)}>Show more ({list.length - n})</button>}
      </motion.div>
    </div>
  )
}
