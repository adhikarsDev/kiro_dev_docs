import { useMemo, useRef } from 'react'
import { motion, useReducedMotion, useScroll, useTransform } from 'framer-motion'
import { ArrowDown, ArrowRight } from 'lucide-react'
import { countBy, useApp } from '../lib/store'
import { navigate } from '../lib/router'
import { ALL_SCOPE, INITIAL_ITEMS, PHASES, PROPERTIES, type Phase } from '../data/mock'
import { fadeUp, spring, stagger } from '../lib/motion'
import { DayRings } from '../components/ui'
import { BookColumns } from '../features/book/Bars'
import { ActToday, AIRecsCard, KeyDatesCard, MarketPulseCard, SignalBoard, SystemsCard } from '../features/today'
import { WorkQueue } from '../features/WorkQueue'
import type { BookPhase } from '../features/book/types'


// Portfolio-wide distribution for the "All properties" scope.
const ALL_PHASES: BookPhase[] = [
  { phase: 'pre', label: 'Pre-Marketing', total: 1190, attention: 238 },
  { phase: 'on', label: 'On-Market', total: 902, attention: 121 },
  { phase: 'contract', label: 'Under Contract', total: 338, attention: 9 },
  { phase: 'closing', label: 'Closing', total: 211, attention: 44 },
  { phase: 'sold', label: 'Sold · 30d', total: 118, attention: 0 },
]

// Work already done earlier this morning (so the rings start alive, not empty).
const EARLIER = { exceptions: 6, decisions: 2 }
const START = (() => {
  const c = countBy(INITIAL_ITEMS)
  const today = INITIAL_ITEMS.filter((i) => i.actToday).length
  return { exceptions: c.exceptions, offers: today, decisions: c.actions - today }
})()

export default function Today() {
  const items = useApp((s) => s.items)
  const { theme, scope, phaseFilter, setPhaseFilter, setQueueTab } = useApp()
  const reduce = !!useReducedMotion()
  const heroRef = useRef<HTMLDivElement>(null)
  const flowRef = useRef<HTMLDivElement>(null)
  const { scrollYProgress } = useScroll({ target: heroRef, offset: ['start start', 'end start'] })
  const copyY = useTransform(scrollYProgress, [0, 1], [0, 50])
  const copyOpacity = useTransform(scrollYProgress, [0, 0.6], [1, 0])
  const flowScale = useTransform(scrollYProgress, [0, 1], [1, 0.96])

  const c = countBy(items)
  const actToday = items.filter((i) => i.actToday && i.queue === 'actions').length
  const signalsOpen = new Set(items.filter((i) => i.queue === 'exceptions' && i.signal).map((i) => i.signal)).size
  const minutes = Math.max(5, Math.round((signalsOpen * 4 + actToday * 3 + c.exceptions * 0.5) / 5) * 5)

  const rings = [
    { label: 'Exceptions cleared', done: EARLIER.exceptions + Math.max(0, START.exceptions - c.exceptions), total: START.exceptions + EARLIER.exceptions, tone: 'ring1' },
    { label: 'Offers moved today', done: START.offers - actToday, total: START.offers, tone: 'ring2' },
    { label: 'Decisions made', done: EARLIER.decisions + Math.max(0, START.decisions - (c.actions - actToday)), total: START.decisions + EARLIER.decisions, tone: 'ring3' },
  ]

  const phases = useMemo<BookPhase[]>(() => {
    if (scope === 'all') return ALL_PHASES
    return PHASES.map((ph) => {
      const ids = new Set(PROPERTIES.filter((p) => p.phase === ph.key).map((p) => p.id))
      const attention = new Set(items.filter((i) => i.queue === 'exceptions' && ids.has(i.propertyId)).map((i) => i.propertyId)).size
      return { phase: ph.key, label: ph.label, total: ids.size, attention }
    })
  }, [items, scope])
  const total = phases.reduce((a, p) => a + p.total, 0)
  const titleCount = scope === 'all' ? 286 : PROPERTIES.filter((p) => p.titleTrack).length

  const pickPhase = (p: Phase) => {
    if (p === 'sold') return
    setPhaseFilter(phaseFilter === p ? 'all' : p)
    setQueueTab('exceptions')
    document.getElementById('my-work')?.scrollIntoView({ behavior: reduce ? 'auto' : 'smooth', block: 'start' })
  }
  const start = () => document.getElementById(actToday ? 'act-today' : 'signals')?.scrollIntoView({ behavior: reduce ? 'auto' : 'smooth', block: 'start' })

  return (
    <div className="page">
      {/* ---------------- Orient ---------------- */}
      <section className="hero2" ref={heroRef}>
        <div className="hero2-top">
          <motion.div className="stack gap-12" style={{ y: copyY, opacity: copyOpacity }} variants={stagger(0.08, 0.05)} initial="hidden" animate="show">
            <motion.div className="t-eyebrow" variants={fadeUp}>Monday, November 3</motion.div>
            <motion.h1 className="t-large" style={{ margin: 0, fontSize: 40, letterSpacing: '-0.03em' }} variants={fadeUp}>Good morning, Srini</motion.h1>
            <motion.p variants={fadeUp} style={{ margin: 0, fontSize: 17, lineHeight: 1.5, color: 'var(--label-2)', maxWidth: 560, letterSpacing: '-0.014em' }}>
              {scope === 'mine'
                ? <><b style={{ color: 'var(--label)', fontWeight: 600 }}>{c.exceptions} files</b> need attention{actToday > 0 && <> and <b style={{ color: 'var(--label)', fontWeight: 600 }}>{actToday} offers</b> are ready to move</>}. With batch follow-ups, that's about {minutes} minutes.</>
                : <>Viewing all {ALL_SCOPE.total.toLocaleString()} properties across {ALL_SCOPE.ams} asset managers. You can act only on your own files.</>}
            </motion.p>
            <motion.div className="hstack gap-8 wrap" variants={fadeUp} style={{ marginTop: 4 }}>
              <motion.button className="btn btn-primary btn-lg" whileTap={{ scale: 0.97 }} onClick={start}>Start my day <ArrowDown size={16} /></motion.button>
              <button className="btn btn-gray btn-lg" onClick={() => navigate('/work')}>Open My Work</button>
            </motion.div>
          </motion.div>
          <motion.div className="stack gap-12" variants={fadeUp} initial="hidden" animate="show" transition={{ ...spring, delay: 0.25 }}>
            <span className="t-eyebrow rings-title">Today's progress</span>
            <DayRings rings={rings} />
          </motion.div>
        </div>

        <motion.div className="hero2-flow" ref={flowRef} style={{ scale: flowScale }}>
          <div className="flow-head">
            <span className="t-headline">{scope === 'mine' ? 'Your book' : 'All books'}</span>
            <span className="t-sub">{total.toLocaleString()} properties by phase · click a phase to filter</span>
            <span className="spacer" />
            <span className="legend-chip" data-tone="rose"><i style={{ borderRadius: 2, width: 14, height: 4 }} />Coral = needs attention</span>
          </div>
          <div className="book-body">
            <BookColumns phases={phases} active={phaseFilter} onPick={pickPhase} titleCount={titleCount} />
          </div>
        </motion.div>
      </section>

      {/* ---------------- Insight: what the agents and the market are saying ---------------- */}
      <div className="grid g-12 eq-row" style={{ alignItems: 'stretch' }}>
        <div className="span-7 r-full stack"><AIRecsCard /></div>
        <div className="span-5 r-full stack"><MarketPulseCard /></div>
      </div>

      {/* ---------------- Prioritize ---------------- */}
      <div id="act-today" style={{ scrollMarginTop: 80 }}><ActToday /></div>
      <div style={{ scrollMarginTop: 80 }}><SignalBoard /></div>

      {/* ---------------- Understand → Act ---------------- */}
      <motion.div className="stack gap-4" variants={fadeUp} initial="hidden" whileInView="show" viewport={{ once: true, amount: 0.5 }} style={{ marginTop: 10 }}>
        <div className="t-eyebrow">Step 2 · Actionables</div>
        <div className="t-title1">Work the queue</div>
      </motion.div>
      <div className="grid g-12" style={{ alignItems: 'start' }}>
        <div className="span-8 r-full" style={{ scrollMarginTop: 80 }} id="queue-anchor">
          <WorkQueue limit={8} compact />
        </div>
        <div className="span-4 r-full stack gap-16 rail-grid">
          <KeyDatesCard />
          <SystemsCard />
        </div>
      </div>
    </div>
  )
}
