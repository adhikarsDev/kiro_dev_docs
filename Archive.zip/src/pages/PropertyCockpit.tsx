import { Suspense, lazy, useMemo, useState } from 'react'
import { AnimatePresence, motion, useReducedMotion } from 'framer-motion'
import {
  ArrowRight, ChevronLeft, ChevronRight, CircleCheck, FileText, Mail, Phone, Sparkles, TriangleAlert,
} from 'lucide-react'
import { navigate } from '../lib/router'
import { rank, useApp } from '../lib/store'
import { LIFECYCLE, SYSTEMS, money, propertyById } from '../data/mock'
import { recFor } from '../data/rec'
import { fadeUp, inView, spring, springSnappy, stagger } from '../lib/motion'
import { PhasePill, RiskPill, Stepper } from '../components/ui'
import { originOf, performAction } from '../features/actions'
import { itemContext } from '../features/context'
import { MarketPulseCard } from '../features/today'

const HouseModel = lazy(() => import('../three/HouseModel'))

const TABS = ['Overview', 'Tasks', 'Recommendations', 'Market', 'Documents', 'Communications', 'Audit trail'] as const

export default function PropertyCockpit({ id }: { id: string }) {
  const p = propertyById(id)
  const { items, theme } = useApp()
  const reduce = !!useReducedMotion()
  const [tab, setTab] = useState<(typeof TABS)[number]>('Overview')
  const mine = items.filter((i) => i.propertyId === id).sort(rank)
  const top = mine[0]
  const rec = recFor(p)

  const nav = useMemo(() => [...items].sort(rank).filter((v, i, a) => a.findIndex((x) => x.propertyId === v.propertyId) === i), [items])
  const qi = nav.findIndex((i) => i.propertyId === id)
  const prev = qi > 0 ? nav[qi - 1] : null
  const next = qi >= 0 && qi < nav.length - 1 ? nav[qi + 1] : null

  const dates = useMemo(() => {
    const out: string[] = []
    let offset = p.daysInInventory + 20
    LIFECYCLE.forEach((_, k) => {
      if (k > p.stage) return out.push('')
      const d = new Date(2026, 10, 3); d.setDate(d.getDate() - offset)
      out.push(d.toLocaleDateString('en-US', { month: 'short', day: 'numeric' }))
      offset = Math.max(0, offset - Math.round((p.daysInInventory + 20) / (p.stage + 1)))
    })
    return out
  }, [p])

  const beacon = top?.queue === 'exceptions' ? '#ff3b30' : top?.queue === 'actions' ? '#34c759' : '#0a84ff'
  const ctx = top ? itemContext(top, p) : null
  const checklist = [
    ['Listing agreement executed', p.stage >= 5], ['Listing data sent to Hubzu', p.stage >= 5], ['Marketing plan approved', p.stage >= 5],
    ['Initial list price set', p.stage >= 5], ['Property listed on Hubzu', p.stage >= 5], ['Monitor market activity (weekly)', p.stage >= 5],
    ['Review market performance (14 days)', false], ['Evaluate price reduction (if needed)', false],
  ] as const
  const done = checklist.filter((c) => c[1]).length

  return (
    <div className="page" style={{ gap: 18 }}>
      <div className="hstack gap-8">
        <button className="btn btn-plain btn-sm" onClick={() => history.length > 1 ? history.back() : navigate('/work')}><ChevronLeft size={15} />Back</button>
        <span className="spacer" />
        {qi >= 0 && <span className="t-caption">{qi + 1} of {nav.length} in your queue</span>}
        <button className="btn btn-gray btn-sm" disabled={!prev} onClick={() => prev && navigate(`/property/${prev.propertyId}`)}><ChevronLeft size={14} />Previous</button>
        <button className="btn btn-gray btn-sm" disabled={!next} onClick={() => next && navigate(`/property/${next.propertyId}`)}>Next<ChevronRight size={14} /></button>
      </div>

      <motion.div className="card" style={{ padding: 18 }} variants={fadeUp} initial="hidden" animate="show">
        <div className="hstack gap-20 wrap" style={{ alignItems: 'stretch' }}>
          <div className="house-canvas">
            <Suspense fallback={null}><HouseModel occupied={p.occupancy === 'Occupied'} beacon={beacon} dark={theme === 'dark'} reduce={reduce} /></Suspense>
            <span className="legend-chip" style={{ position: 'absolute', left: 10, bottom: 10, height: 22, fontSize: 11 }}>Drag to rotate</span>
          </div>
          <div className="stack gap-10" style={{ flex: '1 1 380px', minWidth: 0 }}>
            <div className="hstack gap-8 wrap">
              {top && <RiskPill risk={top.risk} />}
              <PhasePill phase={p.phase} />
              <span className="pill" data-tone="orange">{p.daysInPhase} days in current phase</span>
            </div>
            <div>
              <div className="t-title1">{p.street}</div>
              <div className="t-sub" style={{ fontSize: 14 }}>{p.city}, {p.state} {p.zip} · {p.beds} bd · {p.baths} ba · {p.sqft.toLocaleString()} sq ft</div>
            </div>
            <div className="grid" style={{ gridTemplateColumns: 'repeat(auto-fit, minmax(110px, 1fr))', gap: 10 }}>
              {[['Loan #', p.loan], ['Investor', p.investor], ['Property type', p.type], ['Occupancy', p.occupancy], ['Broker', p.broker], ['Listing ID (Hubzu)', p.hubzuId ?? '—']].map(([k, v]) => (
                <div key={k} className="stack"><span className="t-caption">{k}</span><span className="strong ellipsis" style={{ fontSize: 13.5 }}>{v}</span></div>
              ))}
            </div>
          </div>
          <div className="grid" style={{ gridTemplateColumns: 'repeat(3, minmax(120px, 1fr))', gap: 10, flex: '1 1 380px', alignContent: 'center' }}>
            {[
              ['Days in inventory', `${p.daysInInventory}`, p.daysInInventory > 40 ? `↑ ${p.daysInInventory - 40} d vs target` : 'on target', p.daysInInventory > 40 ? 'red' : 'green'],
              ['Current list price', money(p.listPrice), p.listPrice ? `Since ${rec.firstList.replace(', 2026', '')}` : 'Not listed', 'gray'],
              ['Previous highest offer', money(p.prevHighOffer), p.prevHighOffer ? 'Oct 20, 2026' : 'No offers', 'gray'],
            ].map(([k, v, d, t]) => (
              <div key={k} className="inset stack" style={{ padding: '12px 14px' }} data-tone={t}>
                <span className="t-caption">{k}</span>
                <span className="round" style={{ fontSize: 24, fontWeight: 700, letterSpacing: '-0.02em' }}>{v}</span>
                <span className="t-caption" style={{ color: t === 'red' ? 'var(--red-text)' : undefined }}>{d}</span>
              </div>
            ))}
          </div>
        </div>
        <div style={{ marginTop: 20, padding: '0 6px' }}><Stepper stage={p.stage} dates={dates} /></div>
      </motion.div>

      {top && (
        <motion.div className="callout hstack gap-12 wrap" data-tone={top.queue === 'exceptions' ? 'red' : top.queue === 'actions' ? 'green' : 'blue'} variants={fadeUp} initial="hidden" animate="show">
          {top.queue === 'exceptions' ? <TriangleAlert size={20} style={{ color: 'var(--tone-text)' }} /> : <CircleCheck size={20} style={{ color: 'var(--tone-text)' }} />}
          <div className="stack" style={{ flex: '1 1 300px' }}>
            <span className="t-headline t-tone">{top.reason}</span>
            <span className="t-sub">{ctx?.next}</span>
          </div>
          <motion.button className="btn btn-primary" whileTap={{ scale: 0.97 }} onClick={(e) => performAction(top, originOf(e))}>{top.nextAction}<ArrowRight size={15} /></motion.button>
        </motion.div>
      )}

      <div className="tabs" role="tablist">
        {TABS.map((t) => (
          <button key={t} role="tab" aria-selected={tab === t} className={`tab ${tab === t ? 'on' : ''}`} onClick={() => setTab(t)}>
            {t}{t === 'Tasks' ? ' (8)' : t === 'Documents' ? ' (14)' : t === 'Communications' ? ' (6)' : t === 'Recommendations' ? ' (1)' : ''}
            {tab === t && <motion.span layoutId="prop-tab" className="tab-ul" transition={springSnappy} />}
          </button>
        ))}
      </div>

      <AnimatePresence mode="wait">
        <motion.div key={tab} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -6 }} transition={{ ...spring, duration: 0.3 }}>
          {tab === 'Overview' && (
            <motion.div className="grid g-12" variants={stagger(0.05)} initial="hidden" whileInView="show" viewport={inView}>
              <motion.div className="card card-pad span-4 r-full" variants={fadeUp}>
                <div className="hstack" style={{ marginBottom: 6 }}><span className="t-title3" style={{ flex: 1 }}>{LIFECYCLE[p.stage]} checklist</span><span className="t-caption">{done} of {checklist.length}</span></div>
                <div style={{ height: 6, borderRadius: 3, background: 'var(--fill)', overflow: 'hidden', marginBottom: 8 }}>
                  <motion.div style={{ height: '100%', background: 'var(--green)', borderRadius: 3 }} initial={{ width: 0 }} whileInView={{ width: `${(done / checklist.length) * 100}%` }} viewport={{ once: true }} transition={{ duration: 0.9, ease: [0.32, 0.72, 0, 1] }} />
                </div>
                {checklist.map(([t, ok]) => (
                  <div key={t} className="list-row" style={{ padding: '7px 0' }}>
                    <span className={`check ${ok ? 'on' : ''}`} style={{ background: ok ? 'var(--green)' : undefined }}>{ok && <CircleCheck size={12} />}</span>
                    <span style={{ flex: 1, fontSize: 13.5, color: ok ? 'var(--label)' : 'var(--label-2)' }}>{t}</span>
                    <span className="t-caption">{ok ? 'Done' : 'Due Nov 15'}</span>
                  </div>
                ))}
              </motion.div>
              <motion.div className="card card-pad span-4 r-full" variants={fadeUp}>
                <div className="t-title3" style={{ marginBottom: 6 }}>Open tasks</div>
                {(mine.length ? mine : []).map((m) => (
                  <div key={m.id} className="list-row">
                    <span className="stack" style={{ flex: 1, minWidth: 0 }}><span className="strong ellipsis" style={{ fontSize: 13.5 }}>{m.reason}</span><span className="t-caption ellipsis">{m.detail}</span></span>
                    <button className="btn btn-sm btn-tinted" onClick={(e) => performAction(m, originOf(e))}>{m.nextAction}</button>
                  </div>
                ))}
                {[['Follow up with broker on showing activity', 'Manual'], ['Check Hubzu analytics (bidder activity)', 'Hubzu'], ['Update property photos (if needed)', 'Broker']].map(([t, s]) => (
                  <div key={t} className="list-row"><span className="stack" style={{ flex: 1 }}><span style={{ fontSize: 13.5 }}>{t}</span><span className="t-caption">{s} · due Nov 12</span></span><button className="btn btn-sm btn-gray">Open</button></div>
                ))}
              </motion.div>
              <motion.div className="card card-pad span-4 r-full stack gap-10" variants={fadeUp} style={{ background: 'linear-gradient(160deg, color-mix(in srgb, var(--blue) 9%, var(--elev)), var(--elev) 60%)' }}>
                <div className="hstack gap-8"><Sparkles size={18} style={{ color: 'var(--blue)' }} /><span className="t-title3">AI recommendation</span></div>
                {p.phase === 'on' ? (
                  <>
                    <span className="pill" data-tone="green" style={{ alignSelf: 'flex-start' }}>List price reduction · {rec.conf}% confidence</span>
                    <div className="hstack gap-16">
                      <div className="stack"><span className="t-caption">Recommended</span><span className="round" style={{ fontSize: 30, fontWeight: 750, letterSpacing: '-0.03em' }}>{money(rec.recommended)}</span></div>
                      <div className="stack"><span className="t-caption">Reduction</span><span className="t-headline" style={{ color: 'var(--red-text)' }}>{money(rec.current - rec.recommended)} ({(((rec.current - rec.recommended) / rec.current) * 100).toFixed(1)}%)</span></div>
                    </div>
                    <span className="t-sub">Market and property signals point to a reduction to rebuild buyer interest.</span>
                    <div className="hstack gap-8"><button className="btn btn-primary" onClick={() => navigate(`/rec/${id}`)}>Review recommendation</button><button className="btn btn-gray" onClick={() => setTab('Market')}>Market</button></div>
                  </>
                ) : (
                  <>
                    <span className="t-body">{ctx?.next ?? 'No open recommendation. The Pre-Marketing Monitor is watching this file.'}</span>
                    <ul className="t-sub" style={{ margin: 0, paddingLeft: 18 }}>{(ctx?.reasoning ?? []).map((r) => <li key={r}>{r}</li>)}</ul>
                  </>
                )}
              </motion.div>
              <motion.div className="card card-pad span-4 r-full" variants={fadeUp}>
                <div className="t-title3" style={{ marginBottom: 4 }}>System & vendor status</div>
                {SYSTEMS.map((s) => (
                  <div key={s.name} className="list-row" style={{ padding: '7px 0' }}>
                    <span className="status-dot" data-tone={s.status === 'ok' ? 'green' : 'orange'} />
                    <span className="strong" style={{ flex: 1, fontSize: 13 }}>{s.name}</span>
                    <span className="t-caption">{s.status === 'ok' ? 'Connected' : 'Delayed'} · {s.sync}</span>
                  </div>
                ))}
              </motion.div>
              <motion.div className="card card-pad span-4 r-full" variants={fadeUp}>
                <div className="t-title3" style={{ marginBottom: 4 }}>Recent communications</div>
                {COMMS(p.broker, p.investor).slice(0, 5).map((c) => (
                  <div key={c.s} className="list-row" style={{ padding: '8px 0' }}>
                    <span className="mini-ico" data-tone={c.type === 'call' ? 'green' : 'blue'}>{c.type === 'call' ? <Phone size={13} /> : <Mail size={13} />}</span>
                    <span className="stack" style={{ flex: 1, minWidth: 0 }}><span className="strong ellipsis" style={{ fontSize: 13 }}>{c.s}</span><span className="t-caption">{c.w} · {c.d}</span></span>
                  </div>
                ))}
              </motion.div>
              <motion.div className="card card-pad span-4 r-full" variants={fadeUp}>
                <div className="t-title3" style={{ marginBottom: 4 }}>Upcoming key dates</div>
                {[['NOV', 12, 'Broker follow-up', 'Showing activity and feedback'], ['NOV', 15, 'Market performance review', 'Review analytics, evaluate reduction'], ['NOV', 18, 'Investor status check', 'Follow up on pending approvals'], ['DEC', 1, 'Next marketing review (30 days)', 'Assess performance and next steps']].map(([m, d, t, s]) => (
                  <div key={t as string} className="list-row"><div className="date-tile"><div className="m">{m}</div><div className="d">{d}</div></div><div className="stack"><span className="strong" style={{ fontSize: 13.5 }}>{t}</span><span className="t-caption">{s}</span></div></div>
                ))}
              </motion.div>
            </motion.div>
          )}
          {tab === 'Communications' && (
            <div className="card card-pad">
              {COMMS(p.broker, p.investor).map((c) => (
                <div key={c.s} className="list-row">
                  <span className="mini-ico" data-tone={c.type === 'call' ? 'green' : 'blue'}>{c.type === 'call' ? <Phone size={13} /> : <Mail size={13} />}</span>
                  <span className="stack" style={{ flex: 1 }}><span className="strong" style={{ fontSize: 13.5 }}>{c.s}</span><span className="t-caption">{c.w}</span></span>
                  <span className="t-caption">{c.d}</span>
                </div>
              ))}
            </div>
          )}
          {tab === 'Audit trail' && (
            <div className="card card-pad">
              <div className="timeline">
                {[['Nov 3, 9:14 AM', 'Review Marketing Plan agent produced recommendation R-20481 (rule SPS-LPR-2.3)', 'blue'], ['Nov 3, 9:14 AM', 'Market snapshot stored (sample feed), Phoenix–Mesa MSA', 'gray'], ['Nov 2, 4:10 PM', 'Srini viewed property', 'gray'], ['Oct 21, 11:02 AM', 'Reduction request sent to investor (−5.5%)', 'orange'], ['Oct 5, 9:30 AM', 'List price $425,000 written to Equator by Srini', 'green']].map(([d, t, tone]) => (
                  <div key={d + t} className="tl-item" data-tone={tone}><span className="t-caption" style={{ display: 'inline-block', width: 120 }}>{d}</span>{t}</div>
                ))}
              </div>
            </div>
          )}
          {tab === 'Market' && <div className="grid g-12"><div className="span-6 r-full"><MarketPulseCard /></div></div>}
          {(tab === 'Tasks' || tab === 'Documents' || tab === 'Recommendations') && (
            <div className="card card-pad">
              {(tab === 'Documents'
                ? ['Listing agreement.pdf', 'BPO report (Oct 13).pdf', 'Occupancy inspection.pdf', 'Trash-out completion photos.zip', 'Marketing plan v2.pdf']
                : tab === 'Tasks' ? ['Review AI price reduction analysis', 'Follow up with broker on showing activity', 'Check Hubzu analytics', 'Investor follow-up on marketing plan amendment', 'Update property photos']
                  : ['List price reduction · 87% confidence']).map((t) => (
                <div key={t} className="list-row">
                  <span className="mini-ico" data-tone="gray"><FileText size={13} /></span>
                  <span style={{ flex: 1, fontSize: 13.5 }}>{t}</span>
                  <button className="btn btn-sm btn-gray" onClick={() => tab === 'Recommendations' && navigate(`/rec/${id}`)}>Open</button>
                </div>
              ))}
            </div>
          )}
        </motion.div>
      </AnimatePresence>
    </div>
  )
}

const COMMS = (broker: string, investor: string) => [
  { type: 'mail', w: broker, s: 'Re: Showing activity update', d: 'Nov 2, 9:15 AM' },
  { type: 'mail', w: `Investor (${investor})`, s: 'Marketing plan approval follow-up', d: 'Nov 1, 4:32 PM' },
  { type: 'call', w: broker, s: 'Discussed price feedback from recent showings', d: 'Oct 31, 11:20 AM' },
  { type: 'mail', w: 'Hubzu', s: 'Weekly analytics report', d: 'Oct 30, 3:14 PM' },
  { type: 'mail', w: 'Triple R', s: 'Trash-out completion confirmation', d: 'Oct 29, 2:10 PM' },
  { type: 'mail', w: 'ValuePoint BPO', s: 'BPO delivered', d: 'Oct 13, 8:02 AM' },
]
