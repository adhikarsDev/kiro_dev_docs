import { useMemo, useState } from 'react'
import { AnimatePresence, motion } from 'framer-motion'
import {
  ArrowRight, Ban, ChevronLeft, ChevronRight, ClipboardList, FileSignature, Gavel, Pencil, Route as RouteIcon, ShieldCheck, Sparkles, TrendingDown, TriangleAlert, Users,
} from 'lucide-react'
import { navigate } from '../lib/router'
import { useApp } from '../lib/store'
import { money, propertyById } from '../data/mock'
import { AM_AUTHORITY, INVESTOR_CAP, RULE_VERSION, pendingPrice, recFor, routeFor, tierFor, type Tier } from '../data/rec'
import { DECISIONS, geoLabel, resolveGeo, evidenceFor, type DecisionType, type GeoKey, type Period, type Segment } from '../data/market'
import { fadeUp, inView, spring, springSheet, springSnappy, stagger } from '../lib/motion'
import { AnimatedNumber, ConfidenceRing, PhasePill, Stepper } from '../components/ui'
import { originOf } from '../features/actions'
import { CustomerBrief, DataReadiness, Influences, MarketEvidence, VerdictBanner, briefText } from '../features/evidence'

const fmt$ = (n: number) => money(Math.round(n))
const ICON: Record<DecisionType, typeof TrendingDown> = { list: TrendingDown, reserve: Gavel, plan: ClipboardList, contract: FileSignature }

/** Type-specific proposal: what is being changed, and the deterministic numbers behind it. */
function proposalFor(type: DecisionType, p: ReturnType<typeof propertyById>) {
  const rec = recFor(p)
  const list = rec.current
  if (type === 'reserve') {
    const reserve = Math.round((list * 0.92) / 1000) * 1000
    return { priceType: true, base: reserve, recommended: Math.round((reserve * (1 - 0.055)) / 500) * 500, baseLabel: 'Current reserve', newLabel: 'Recommended reserve' }
  }
  if (type === 'list') return { priceType: true, base: list, recommended: rec.recommended, baseLabel: 'Current list price', newLabel: 'Recommended list price' }
  if (type === 'plan') return { priceType: false, base: list, recommended: rec.recommended, baseLabel: 'Current list price', newLabel: 'Amended list price' }
  const price = Math.round((list * 0.955) / 500) * 500
  return { priceType: false, base: list, recommended: price, baseLabel: 'List price', newLabel: 'Contract price' }
}

export default function Recommendation({ id, type = 'list' }: { id: string; type?: DecisionType }) {
  const t: DecisionType = (['list', 'reserve', 'plan', 'contract'] as const).includes(type) ? type : 'list'
  const p = propertyById(id)
  const D = DECISIONS[t]
  const Icon = ICON[t]
  const rec = useMemo(() => recFor(p), [p])
  const prop = useMemo(() => proposalFor(t, p), [t, p])
  const { items, openConfirm, recDecision, setRecDecision, toast } = useApp()

  // Evidence: most relevant geography with enough sample, disclosed and overridable.
  const auto = resolveGeo('all', '30d')
  const [geo, setGeo] = useState<GeoKey>(auto.geo)
  const [seg, setSeg] = useState<Segment>('all')
  const [period, setPeriod] = useState<Period>('30d')
  const ev = useMemo(() => evidenceFor(t, p, geo, seg, period), [t, p, geo, seg, period])

  const [price, setPrice] = useState(pendingPrice.get(id) ?? prop.recommended)
  const [modify, setModify] = useState(false)
  const [rejectOpen, setRejectOpen] = useState(false)
  const pct = (prop.base - price) / prop.base
  const valuation = p.valuation ?? rec.current
  const tier: Tier = t === 'plan' ? 'investor' : t === 'contract' ? (prop.recommended / valuation < 0.97 ? 'investor' : 'am') : tierFor(pct)
  const route = t === 'contract' && tier === 'investor'
    ? ['Asset Manager (you)', `Investor approval (${p.investor})`, 'Execute contract (DocuSign)', 'Open closing tasks']
    : routeFor(tier, p.investor)
  const decision = recDecision[id]

  const queue = items.filter((i) => i.signal === 'reduction' || i.actionKind === 'recommendation')
  const qi = queue.findIndex((i) => i.propertyId === id)
  const prev = qi > 0 ? queue[qi - 1] : null
  const next = qi >= 0 && qi < queue.length - 1 ? queue[qi + 1] : null

  const proposalText = t === 'list' ? `reduce the list price from ${money(prop.base)} to ${money(price)} (−${(pct * 100).toFixed(1)}%).`
    : t === 'reserve' ? `reduce the auction reserve from ${money(prop.base)} to ${money(price)} (−${(pct * 100).toFixed(1)}%) for the next Hubzu cycle.`
      : t === 'plan' ? `amend the marketing plan to a traditional listing at ${money(prop.recommended)} with a 3.0% selling commission.`
        : `approve the buyer contract at ${money(prop.recommended)} (${((prop.recommended / prop.base) * 100).toFixed(1)}% of list), conventional financing, closing in 30 days.`
  const brief = briefText(t, p, ev, geoLabel(geo, p), period, proposalText.charAt(0).toUpperCase() + proposalText.slice(1))

  const tierPill = tier === 'am'
    ? <span className="pill" data-tone="mint"><ShieldCheck size={12} />Within your delegated authority</span>
    : tier === 'investor'
      ? <span className="pill" data-tone="sand"><Users size={12} />Requires {p.investor} approval</span>
      : <span className="pill" data-tone="rose"><TriangleAlert size={12} />Exceeds the 8% / 28-day rule: management exception</span>

  const toApproval = () => { if (prop.priceType) pendingPrice.set(id, price); navigate(`/approval/${id}?type=${t}`) }
  const approve = (e: React.MouseEvent) => {
    if (prop.priceType && pct <= 0) return toast({ title: 'Holding price, no change written', body: 'Next marketing review scheduled in 14 days.', tone: 'info' })
    if (prop.priceType && tier === 'am') return openConfirm({ kind: 'write', propertyId: id, payload: { from: prop.base, to: price, pct: `${(pct * 100).toFixed(1)}%` }, origin: originOf(e) })
    toApproval()
  }

  const scenarios = t === 'list' || t === 'reserve' ? [
    { k: 'hold', label: t === 'list' ? 'Hold price' : 'Hold reserve', price: prop.base, note: t === 'list' ? 'Next review in 14 days; DOM keeps rising vs market' : 'Next cycle likely ends without a winning bid' },
    { k: 'am', label: 'Within your authority', price: Math.round((prop.base * (1 - AM_AUTHORITY)) / 500) * 500, note: 'AM approval only · writes today' },
    { k: 'rec', label: 'Recommended', price: prop.recommended, note: `${p.investor} approval · best fit to market signals` },
    { k: 'cap', label: 'Max per rule', price: Math.round((prop.base * (1 - INVESTOR_CAP)) / 500) * 500, note: '8% / 28-day cap · investor approval' },
  ] : null

  const diff: [string, string, string][] = t === 'plan'
    ? [['Listing type', 'Hubzu online auction', 'Traditional · local broker'], ['List price', money(prop.base), money(prop.recommended)], ['Selling-agent commission', '2.5%', '3.0%'], ['Review cadence', 'Every 14 days', 'Every 7 days']]
    : [['Buyer', '—', 'D. Okafor · pre-approved'], ['Contract price', money(prop.base), money(prop.recommended)], ['Financing', '—', 'Conventional · 20% down'], ['Seller concessions', '—', '$3,200'], ['Closing', '—', '30 days · Dec 5, 2026']]

  const calc: [string, string][] = t === 'contract'
    ? [['Contract price', money(prop.recommended)], ['Less commissions (5.5%)', `−${money(prop.recommended * 0.055)}`], ['Less seller concessions', '−$3,200'], ['Net to seller', money(prop.recommended * 0.945 - 3200)], ['vs current valuation', `${((prop.recommended / valuation) * 100).toFixed(1)}%`], ['vs market sale-to-list', `${ev.m.stlPct}%`]]
    : t === 'plan'
      ? [['Current list price', money(prop.base)], ['Market adjustment (sale-to-list)', `${(ev.m.stlPct - 100).toFixed(1)}%`], ['Property adjustment (activity)', '−2.3%'], ['Amended list price', money(prop.recommended)], ['Added selling commission', `+${money(prop.recommended * 0.005)}`]]
      : [[prop.baseLabel, money(prop.base)], ['Market adjustment (sale-to-list)', `${(ev.m.stlPct - 100).toFixed(1)}%`], ['Property adjustment (bids & DOM)', `${(-(pct * 100) - (ev.m.stlPct - 100)).toFixed(1)}%`], ['Recommended change', `−${(pct * 100).toFixed(1)}%`]]

  return (
    <div className="page" style={{ gap: 18 }}>
      <div className="hstack gap-8 wrap">
        <button className="btn btn-plain btn-sm" onClick={() => history.length > 1 ? history.back() : navigate('/recs')}><ChevronLeft size={15} />Back</button>
        <span className="t-sub">Recommendations › <a onClick={() => navigate(`/property/${id}`)} style={{ cursor: 'pointer' }}>{p.street}</a> › <b style={{ color: 'var(--label)' }}>{D.short}</b></span>
        <span className="spacer" />
        {t === 'list' && qi >= 0 && <>
          <span className="t-caption">{qi + 1} of {queue.length}</span>
          <button className="btn btn-gray btn-sm" disabled={!prev} onClick={() => prev && navigate(`/rec/${prev.propertyId}`)}><ChevronLeft size={14} />Previous</button>
          <button className="btn btn-gray btn-sm" disabled={!next} onClick={() => next && navigate(`/rec/${next.propertyId}`)}>Next<ChevronRight size={14} /></button>
        </>}
      </div>

      <motion.div className="card card-pad hstack gap-20 wrap" variants={fadeUp} initial="hidden" animate="show">
        <div className="stack gap-4" style={{ flex: '1 1 300px' }}>
          <div className="hstack gap-8"><span className="t-title2">{p.street}</span><PhasePill phase={p.phase} /></div>
          <div className="t-sub">{p.city}, {p.state} {p.zip} · Loan {p.loan} · {p.investor} · {p.occupancy} · {p.type} · {p.broker}{p.hubzuId ? ` · Hubzu ${p.hubzuId}` : ''}</div>
        </div>
        <div style={{ flex: '1 1 420px' }}><Stepper stage={t === 'contract' ? 3 : t === 'reserve' ? 2 : 1} steps={['Valuation', 'Marketing', 'Offers', 'Contract', 'Closing', 'Sold']} /></div>
      </motion.div>

      <motion.div className="hstack gap-12 wrap" variants={fadeUp} initial="hidden" animate="show">
        <div className="signal-ico" data-tone="sky" style={{ width: 46, height: 46, borderRadius: 14 }}><Icon size={22} /></div>
        <div className="stack" style={{ flex: 1 }}>
          <div className="hstack gap-10 wrap"><span className="t-title1">{D.title}</span><span className="pill" data-tone="sky"><Sparkles size={12} />AI generated</span><span className="pill" data-tone="lavender">Market-aware</span></div>
          <span className="t-sub">Market conditions, property performance and {p.investor} investor guidelines · {D.agent}</span>
        </div>
        <span className="t-caption">Generated Nov 3, 2026 9:14 AM · Rule {RULE_VERSION} · <a>View agent audit trail</a></span>
      </motion.div>

      <VerdictBanner ev={ev} type={t} p={p} />

      <AnimatePresence>
        {decision && (
          <motion.div className="callout hstack gap-10" data-tone={decision === 'rejected' ? 'gray' : 'mint'} initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: 'auto' }} exit={{ opacity: 0 }}>
            <ShieldCheck size={18} style={{ color: 'var(--tone-text)' }} />
            <span><b>{decision === 'written' ? 'Written to Equator.' : decision === 'routed' ? `Sent to ${p.investor} for approval.` : decision === 'rejected' ? 'Recommendation rejected.' : 'Submitted.'}</b> {decision === 'rejected' ? 'Your reason was captured for agent learning.' : 'Status is tracked in My Work.'}</span>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Row 1: proposal · confidence + route · alternatives */}
      <motion.div className="grid g-12" variants={stagger(0.06)} initial="hidden" whileInView="show" viewport={inView}>
        <motion.div className="card card-pad span-5 r-full stack gap-12" variants={fadeUp}>
          <div className="hstack"><span className="t-eyebrow">Recommendation</span><span className="spacer" />
            {prop.priceType && <button className={`btn btn-sm ${modify ? 'btn-primary' : 'btn-tinted'}`} onClick={() => setModify((m) => !m)}><Pencil size={13} />{modify ? 'Done' : 'Modify'}</button>}
          </div>
          {prop.priceType ? (
            <>
              <div className="inset stack gap-4" style={{ padding: '16px 18px', background: 'color-mix(in srgb, var(--blue) 7%, transparent)' }}>
                <span className="t-sub" style={{ color: 'var(--blue-text)', fontWeight: 600 }}>{price === prop.recommended ? prop.newLabel : 'Your proposed price'}</span>
                <span className="round" style={{ fontSize: 44, fontWeight: 750, letterSpacing: '-0.035em', lineHeight: 1.05 }}><AnimatedNumber value={price} format={fmt$} duration={0.45} /></span>
                <div className="hstack gap-16 wrap" style={{ marginTop: 6 }}>
                  <div className="stack"><span className="t-caption">{prop.baseLabel}</span><span className="t-headline">{money(prop.base)}</span></div>
                  <div className="stack"><span className="t-caption">Reduction</span><span className="t-headline" style={{ color: pct > 0 ? 'var(--rose-text)' : undefined }}>{money(prop.base - price)} ({(pct * 100).toFixed(1)}%)</span></div>
                  <div className="stack"><span className="t-caption">Valuation</span><span className="t-headline">{money(valuation)}</span></div>
                </div>
              </div>
              <AnimatePresence initial={false}>
                {modify && (
                  <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: 'auto', opacity: 1 }} exit={{ height: 0, opacity: 0 }} transition={spring} style={{ overflow: 'hidden' }}>
                    <div className="stack gap-8" style={{ paddingTop: 4 }}>
                      <input type="range" className="price-slider" min={Math.round(prop.base * 0.88)} max={prop.base} step={500} value={price} onChange={(e) => setPrice(+e.target.value)} aria-label="Proposed price" />
                      <div className="hstack t-caption"><span>{money(Math.round(prop.base * 0.88))} (−12%)</span><span className="spacer" /><span>{money(prop.base)} (hold)</span></div>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </>
          ) : (
            <div className="inset" style={{ padding: '4px 14px' }}>
              {diff.map(([k, a, b]) => (
                <div key={k} className="calc-row" style={{ alignItems: 'center', gap: 10 }}>
                  <span className="t-2" style={{ width: 150, flex: 'none' }}>{k}</span>
                  <span className="t-3" style={{ flex: 1, textAlign: 'right', textDecoration: a !== '—' ? 'line-through' : undefined }}>{a}</span>
                  <ArrowRight size={13} className="t-3" />
                  <span className="strong" style={{ flex: 1.3 }}>{b}</span>
                </div>
              ))}
            </div>
          )}
          <AnimatePresence mode="wait" initial={false}>
            <motion.div key={tier} initial={{ opacity: 0, y: 4 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -4 }} transition={{ duration: 0.16 }}>{tierPill}</motion.div>
          </AnimatePresence>
        </motion.div>

        <motion.div className="card card-pad span-3 r-full stack gap-14" variants={fadeUp}>
          <span className="t-eyebrow">Confidence</span>
          <div className="hstack gap-14">
            <ConfidenceRing value={rec.conf} size={96} tone={rec.conf >= 85 ? 'mint' : 'peach'} />
            <div className="stack"><span className="t-title3" style={{ color: 'var(--mint-text)' }}>{rec.conf >= 85 ? 'High' : 'Moderate'}</span><span className="t-caption">{ev.supportCount} of {ev.total} signals support · {seg === 'reo' ? 'REO' : 'all-listings'} comparison</span></div>
          </div>
          <span className="t-eyebrow" style={{ marginTop: 4 }}>Approval route</span>
          <div className="stack gap-8">
            <AnimatePresence initial={false}>
              {route.map((r, k) => (
                <motion.div key={r} layout className="hstack gap-10" initial={{ opacity: 0, x: -8 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: 8 }} transition={springSnappy}>
                  <span style={{ width: 22, height: 22, borderRadius: 11, display: 'grid', placeItems: 'center', fontSize: 11, fontWeight: 700, background: k === 0 ? 'var(--blue)' : 'var(--fill-2)', color: k === 0 ? '#fff' : 'var(--label-2)' }}>{k + 1}</span>
                  <span style={{ fontSize: 13.5, fontWeight: k === 0 ? 600 : 500 }}>{r}</span>
                </motion.div>
              ))}
            </AnimatePresence>
          </div>
        </motion.div>

        <motion.div className="card card-pad span-4 r-full stack gap-10" variants={fadeUp}>
          <span className="t-eyebrow">{scenarios ? 'Scenario comparison' : 'Alternatives considered'}</span>
          {scenarios ? scenarios.map((s) => {
            const on = price === s.price
            const sp = (prop.base - s.price) / prop.base
            return (
              <motion.button key={s.k} className="inset hstack gap-10" style={{ padding: '10px 12px', textAlign: 'left', boxShadow: on ? 'inset 0 0 0 1.5px var(--blue)' : undefined, background: on ? 'color-mix(in srgb, var(--blue) 7%, transparent)' : undefined }}
                whileTap={{ scale: 0.98 }} onClick={() => { setPrice(s.price); setModify(true) }}>
                <span className="stack min0" style={{ flex: 1 }}>
                  <span className="strong" style={{ fontSize: 13.5 }}>{s.label}{s.k === 'rec' && <span className="pill" data-tone="sky" style={{ marginLeft: 6, height: 18, fontSize: 10.5 }}>AI</span>}</span>
                  <span className="t-caption">{s.note}</span>
                </span>
                <span className="stack" style={{ alignItems: 'flex-end' }}><span className="strong num">{money(s.price)}</span><span className="t-caption num">{sp > 0 ? `−${(sp * 100).toFixed(1)}%` : '0%'}</span></span>
              </motion.button>
            )
          }) : (t === 'plan'
            ? [['Amend to traditional listing', 'Recommended · broker exposure + incentive', true], ['Keep auction, cut reserve 5%', 'Two cycles already ended below reserve', false], ['Relist next cycle unchanged', 'Market signals say demand will not improve', false]]
            : [['Approve contract', 'Recommended · in line with market sale-to-list', true], [`Counter at ${money(Math.round(prop.recommended * 1.02 / 500) * 500)}`, 'Fallout is rising; risks losing the buyer', false], ['Request highest & best', 'Only one qualified offer in 21 days', false]]
          ).map(([l, n, on]) => (
            <div key={l as string} className="inset hstack gap-10" style={{ padding: '10px 12px', boxShadow: on ? 'inset 0 0 0 1.5px var(--blue)' : undefined }}>
              <span className="stack" style={{ flex: 1 }}><span className="strong" style={{ fontSize: 13.5 }}>{l as string}</span><span className="t-caption">{n as string}</span></span>
              {on && <span className="pill" data-tone="sky">AI</span>}
            </div>
          ))}
          <span className="t-caption">Consequences follow configured rules. No sale-price forecasts are shown as fact.</span>
        </motion.div>
      </motion.div>

      {/* Row 2: market-aware evidence */}
      <MarketEvidence type={t} p={p} geo={geo} setGeo={setGeo} seg={seg} setSeg={setSeg} period={period} setPeriod={setPeriod} ev={ev} skipped={auto.skipped} />

      {/* Row 3: why · calculation · brief */}
      <motion.div className="grid g-12" variants={stagger(0.06)} initial="hidden" whileInView="show" viewport={inView}>
        <motion.div className="card card-pad span-7 r-full stack gap-12" variants={fadeUp}>
          <span className="t-title3">Why this recommendation</span>
          <Influences ev={ev} />
        </motion.div>
        <motion.div className="card card-pad span-5 r-full stack" variants={fadeUp}>
          <span className="t-title3" style={{ marginBottom: 2 }}>Deterministic calculation</span>
          <span className="t-caption" style={{ marginBottom: 8 }}>Rule-based, in code. The narrative can't override it.</span>
          {calc.map(([k, v], i) => (
            <div key={k} className={`calc-row ${i === calc.length - (t === 'contract' ? 3 : t === 'plan' ? 2 : 1) ? 'total' : ''}`}><span>{k}</span><b className="num">{v}</b></div>
          ))}
        </motion.div>
        <motion.div className="span-12" variants={fadeUp}>
          <CustomerBrief text={brief} onAdd={toApproval} />
        </motion.div>
      </motion.div>

      <motion.div variants={fadeUp} initial="hidden" whileInView="show" viewport={inView}><DataReadiness /></motion.div>

      <motion.div className="actionbar" initial={{ y: 40, opacity: 0 }} animate={{ y: 0, opacity: 1 }} transition={{ ...springSheet, delay: 0.3 }}>
        <Sparkles size={16} style={{ color: 'var(--blue)' }} />
        <span className="t-sub" style={{ flex: 1 }}>AI-generated and market-aware. Review the evidence before you decide. Every action is logged with rule {RULE_VERSION}.</span>
        <div style={{ position: 'relative' }}>
          <button className="btn btn-danger" onClick={() => setRejectOpen((v) => !v)}><Ban size={14} />Reject</button>
          <AnimatePresence>
            {rejectOpen && (
              <motion.div initial={{ opacity: 0, scale: 0.9, y: 8 }} animate={{ opacity: 1, scale: 1, y: 0 }} exit={{ opacity: 0, scale: 0.9, y: 8 }} transition={springSheet}
                style={{ position: 'absolute', bottom: 44, left: 0, width: 270, padding: 6, borderRadius: 14, background: 'var(--elev)', boxShadow: 'var(--shadow-3)', transformOrigin: 'bottom left' }}>
                <div className="t-eyebrow" style={{ padding: '6px 10px' }}>Reason (required)</div>
                {['Market evidence not convincing', 'Wait for updated valuation', 'Active offer expected', 'Broker feedback disagrees'].map((r) => (
                  <button key={r} className="pal-item" style={{ width: '100%', margin: 0 }} onClick={() => { setRecDecision(id, 'rejected'); setRejectOpen(false); toast({ title: 'Recommendation rejected', body: `Reason: ${r} · logged to audit trail`, tone: 'info' }) }}>{r}</button>
                ))}
              </motion.div>
            )}
          </AnimatePresence>
        </div>
        <button className="btn btn-gray" onClick={toApproval}><RouteIcon size={14} />Route for approval</button>
        <motion.button className="btn btn-primary btn-lg" whileTap={{ scale: 0.97 }} onClick={approve}>
          {prop.priceType && tier === 'am' ? 'Approve & write to Equator' : `Approve & send to ${p.investor}`}
        </motion.button>
      </motion.div>
    </div>
  )
}
