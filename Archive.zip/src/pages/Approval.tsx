import { useState } from 'react'
import { AnimatePresence, motion } from 'framer-motion'
import { Building, Calendar, Check as CheckIcon, ChevronLeft, FileBarChart, FileImage, FileSpreadsheet, FileText, Save, Send, Sparkles, X } from 'lucide-react'
import { navigate } from '../lib/router'
import { nowLabel, useApp } from '../lib/store'
import { MARKET, money, propertyById, type WorkItem } from '../data/mock'
import { RULE_VERSION, pendingPrice, recFor } from '../data/rec'
import { DECISIONS, evidenceFor, geoLabel, resolveGeo, type DecisionType } from '../data/market'
import { briefText } from '../features/evidence'
import { fadeUp, inView, spring, springSnappy, stagger } from '../lib/motion'
import { PhasePill } from '../components/ui'

const EVIDENCE = [
  { icon: FileBarChart, name: 'Market analysis report', meta: 'Phoenix MSA · Nov 2026', size: '1.2 MB', tone: 'red' },
  { icon: FileSpreadsheet, name: 'Comparable sales analysis', meta: '5 similar properties', size: '856 KB', tone: 'green' },
  { icon: FileText, name: 'Hubzu marketing analytics', meta: 'Views, bidders, activity', size: '742 KB', tone: 'blue' },
  { icon: FileImage, name: 'Property photos', meta: 'Exterior and interior (12)', size: '4.5 MB', tone: 'purple' },
  { icon: FileText, name: 'BPO / valuation summary', meta: 'Current BPO and prior value', size: '1.1 MB', tone: 'orange' },
]

export default function Approval({ id, type = 'list' }: { id: string; type?: DecisionType }) {
  const p = propertyById(id)
  const rec = recFor(p)
  const reserve = Math.round((rec.current * 0.92) / 1000) * 1000
  const price = pendingPrice.get(id) ?? (type === 'reserve' ? Math.round((reserve * 0.945) / 500) * 500 : type === 'contract' ? Math.round((rec.current * 0.955) / 500) * 500 : rec.recommended)
  const pct = ((((type === 'reserve' ? reserve : rec.current)) - price) / (type === 'reserve' ? reserve : rec.current)) * 100
  const D = DECISIONS[type] ?? DECISIONS.list
  const auto = resolveGeo('all', '30d')
  const ev = evidenceFor(type, p, auto.geo, 'all', '30d')
  const ask = type === 'list' ? `reduce the list price from ${money(rec.current)} to ${money(price)} (−${pct.toFixed(1)}%).`
    : type === 'reserve' ? `reduce the auction reserve from ${money(reserve)} to ${money(price)} for the next Hubzu cycle.`
      : type === 'plan' ? `amend the marketing plan to a traditional listing with a 3.0% selling commission.`
        : `approve the buyer contract at ${money(price)}.`
  const brief = briefText(type, p, ev, geoLabel(auto.geo, p), '30d', `We request approval to ${ask}`)
  const { items, moveItems, addItem, setRecDecision, toast } = useApp()
  const existing = items.find((i) => i.propertyId === id && i.queue === 'approvals')
  const [stage, setStage] = useState(existing ? 2 : 0) // 0 draft, 1 sending, 2 sent
  const [sentAt, setSentAt] = useState<string | null>(existing ? 'earlier' : null)

  const send = () => {
    setStage(1)
    window.setTimeout(() => {
      const at = nowLabel()
      setSentAt(at); setStage(2)
      const rel = items.filter((i) => i.propertyId === id && (i.queue === 'exceptions' || i.queue === 'actions'))
      const patch: Partial<WorkItem> = { status: 'Approval Pending', reason: `${D.short} · with ${p.investor}`, detail: `Sent ${at} · day-3 follow-up scheduled`, days: 0, slaDays: 3, risk: 'Low', actionKind: 'view', nextAction: 'View package' }
      let undo: (() => void) | undefined
      if (rel.length) undo = moveItems(rel.map((r) => r.id), 'approvals', patch)
      else addItem({ id: `W-ap-${id}`, propertyId: id, queue: 'approvals', counterparty: p.investor, ...(patch as Omit<WorkItem, 'id' | 'propertyId' | 'queue' | 'counterparty'>) })
      setRecDecision(id, 'routed')
      toast({ title: `Sent to ${p.investor} for approval`, body: `Tracked in Approvals Waiting · follow-up drafted for day 3`, undo })
    }, 900)
  }

  const timeline = [
    { t: 'Draft', s: 'Created by Srini · 9:40 AM' },
    { t: 'Sent', s: sentAt ? `${sentAt}` : 'Pending' },
    { t: 'Viewed', s: 'Pending' },
    { t: 'Approved', s: 'Pending' },
    { t: 'Written to Equator', s: 'Pending' },
  ]
  const cur = stage === 2 ? 1 : 0

  return (
    <div className="page" style={{ gap: 18 }}>
      <div className="hstack gap-8 wrap">
        <button className="btn btn-plain btn-sm" onClick={() => history.length > 1 ? history.back() : navigate('/work')}><ChevronLeft size={15} />Back</button>
        <span className="t-sub">My Work › {p.street} › List price reduction › <b style={{ color: 'var(--label)' }}>Investor approval package</b></span>
        <span className="spacer" />
        <button className="btn btn-gray btn-sm" onClick={() => navigate(`/property/${id}`)}>View property</button>
      </div>

      <motion.div className="card card-pad hstack gap-20 wrap" variants={fadeUp} initial="hidden" animate="show">
        <div className="stack gap-4" style={{ flex: '1 1 280px' }}>
          <div className="hstack gap-8"><span className="t-title2">{p.street}</span><PhasePill phase={p.phase} /></div>
          <div className="t-sub">{p.city}, {p.state} · Loan {p.loan} · {p.investor}</div>
        </div>
        {[['Days on market', `${p.dom}`], type === 'reserve' ? ['Current reserve', money(reserve)] : ['Current list price', money(rec.current)],
          type === 'contract' ? ['Contract price', money(price)] : type === 'plan' ? ['Amended list price', money(rec.recommended)] : [type === 'reserve' ? 'Requested reserve' : 'Requested list price', `${money(price)} (−${pct.toFixed(1)}%)`]].map(([k, v]) => (
          <div key={k} className="stack"><span className="t-caption">{k}</span><span className="t-title3 num">{v}</span></div>
        ))}
        <div className="callout hstack gap-10" data-tone="green" style={{ padding: '10px 14px' }}>
          <Sparkles size={16} style={{ color: 'var(--green-text)' }} />
          <div className="stack"><span className="strong" style={{ fontSize: 13 }}>AI supports reduction to {money(rec.recommended)}</span><span className="t-caption">Confidence {rec.conf}%</span></div>
        </div>
      </motion.div>

      <div className="stack gap-4">
        <span className="t-title1">Investor Approval Package · {D.short}</span>
        <span className="t-sub">Review and send the request to {p.investor}, with supporting data and AI-generated analysis attached.</span>
      </div>

      <div className="grid g-12" style={{ alignItems: 'start' }}>
        <motion.div className="span-8 r-full stack gap-16" variants={stagger(0.06)} initial="hidden" whileInView="show" viewport={inView}>
          <motion.div className="card card-pad grid" variants={fadeUp} style={{ gridTemplateColumns: '1.1fr 1fr 1fr', gap: 18 }}>
            <div className="stack gap-8">
              <span className="t-eyebrow">Recipients</span>
              <div className="inset hstack gap-10" style={{ padding: '10px 12px' }}>
                <span className="mini-ico" data-tone="blue"><Building size={14} /></span>
                <span className="stack"><span className="strong" style={{ fontSize: 13 }}>{p.investor} Investor Team</span><span className="t-caption">reo-approvals@{p.investor.split('/')[0].toLowerCase()}.example</span></span>
              </div>
              <span className="t-caption">CC</span>
              <div className="hstack gap-6 wrap">{['REO Client Manager', 'Asset Manager (you)'].map((c) => <span key={c} className="chip" style={{ height: 26 }}>{c}<X size={12} /></span>)}</div>
            </div>
            <div className="stack gap-8">
              <span className="t-eyebrow">Approval route</span>
              {[`${p.investor} investor review`, `${p.investor} asset management (notify)`, 'Listing update (Hubzu)', 'Write to Equator'].map((r, k) => (
                <div key={r} className="hstack gap-8" style={{ fontSize: 13 }}><span className="pill" data-tone="blue" style={{ width: 22, padding: 0, justifyContent: 'center' }}>{k + 1}</span>{r}</div>
              ))}
            </div>
            <div className="stack gap-8">
              <span className="t-eyebrow">Response & escalation</span>
              <div className="hstack gap-8"><Calendar size={16} style={{ color: 'var(--blue)' }} /><span className="strong">Target Nov 6, 2026</span><span className="t-caption">(3 days)</span></div>
              {[['Day 3', 'Send follow-up (template)'], ['Day 5', 'Escalate to client manager'], ['Day 7', 'Escalate to leadership']].map(([d, t]) => (
                <div key={d} className="hstack gap-8" style={{ fontSize: 13 }}><b style={{ width: 44 }}>{d}</b><span className="t-2">{t}</span></div>
              ))}
              <span className="t-caption">Rule version {RULE_VERSION} (Oct 15, 2026)</span>
            </div>
          </motion.div>

          <motion.div className="card" variants={fadeUp}>
            <div className="card-h"><span className="t-title3">Email draft</span><span className="pill" data-tone="blue">Template · Reduction request v2</span></div>
            <div className="card-pad stack gap-10">
              <div className="mail-meta"><span className="k">Subject</span><span className="strong editable" contentEditable suppressContentEditableWarning>Request for approval: {D.short.toLowerCase()} at {p.street}, {p.city}, {p.state}</span></div>
              <div className="mail-body editable" contentEditable suppressContentEditableWarning style={{ minHeight: 200 }}>
                <p style={{ marginTop: 0 }}>Dear {p.investor} Investor Team,</p>
                {brief.split('\n\n').map((para, i) => <p key={i}>{para}</p>)}
                <p>The supporting analysis is attached. Please let us know if you have any questions.</p>
                <p style={{ marginBottom: 0 }}>Thank you,<br />Srini<br /><span className="t-3">Asset Manager · Real Estate Asset Management</span></p>
              </div>
            </div>
          </motion.div>

          <motion.div className="card card-pad" variants={fadeUp}>
            <div className="hstack" style={{ marginBottom: 4 }}><span className="t-title3" style={{ flex: 1 }}>Evidence attached ({EVIDENCE.length})</span><button className="btn btn-plain btn-sm">Edit evidence</button></div>
            {EVIDENCE.map((e) => {
              const Icon = e.icon
              return (
                <div key={e.name} className="list-row">
                  <span className="mini-ico" data-tone={e.tone}><Icon size={15} /></span>
                  <span className="stack" style={{ flex: 1 }}><span className="strong" style={{ fontSize: 13.5 }}>{e.name}</span><span className="t-caption">{e.meta}</span></span>
                  <span className="t-caption">Nov 2, 2026 · {e.size}</span>
                </div>
              )
            })}
          </motion.div>
        </motion.div>

        <motion.div className="span-4 r-full card card-pad stack gap-14" style={{ position: 'sticky', top: 'calc(var(--toolbar-h) + 16px)' }} variants={fadeUp} initial="hidden" animate="show">
          <span className="t-title3">Approval timeline</span>
          <div className="stack" style={{ position: 'relative', paddingLeft: 4 }}>
            {timeline.map((s, k) => {
              const done = k < cur || (k === cur && stage === 2)
              const isCur = k === cur
              return (
                <div key={s.t} className="hstack gap-12" style={{ alignItems: 'flex-start', paddingBottom: k < timeline.length - 1 ? 18 : 0, position: 'relative' }}>
                  {k < timeline.length - 1 && <span style={{ position: 'absolute', left: 11, top: 26, bottom: 2, width: 2, borderRadius: 1, background: done ? 'var(--green)' : 'var(--separator-strong)', transition: 'background .4s' }} />}
                  <motion.span layout style={{ width: 24, height: 24, borderRadius: 12, display: 'grid', placeItems: 'center', flex: 'none', color: '#fff',
                    background: done ? 'var(--green)' : isCur ? 'var(--blue)' : 'var(--fill)', boxShadow: isCur && !done ? '0 0 0 5px color-mix(in srgb, var(--blue) 22%, transparent)' : 'none' }}
                    animate={{ scale: isCur ? [1, 1.08, 1] : 1 }} transition={{ duration: 0.6 }}>
                    {done ? <CheckIcon size={13} strokeWidth={3.2} /> : null}
                  </motion.span>
                  <div className="stack" style={{ flex: 1 }}>
                    <span className="strong" style={{ fontSize: 13.5, color: !done && !isCur ? 'var(--label-3)' : undefined }}>{s.t}</span>
                    <span className="t-caption">{s.s}</span>
                  </div>
                  {isCur && <span className="pill" data-tone={stage === 2 ? 'green' : 'blue'}>{stage === 2 ? 'Done' : 'Current'}</span>}
                </div>
              )
            })}
          </div>
          <div className="hairline" />
          <span className="t-headline">Activity log</span>
          <div className="timeline">
            <div className="tl-item" data-tone="blue"><span className="t-caption">9:40 AM</span> · Approval package created</div>
            <AnimatePresence>{stage === 2 && <motion.div className="tl-item" data-tone="green" initial={{ opacity: 0, x: -6 }} animate={{ opacity: 1, x: 0 }}><span className="t-caption">{sentAt}</span> · Sent to {p.investor}, day-3 follow-up scheduled</motion.div>}</AnimatePresence>
          </div>
        </motion.div>
      </div>

      <motion.div className="actionbar" initial={{ y: 40, opacity: 0 }} animate={{ y: 0, opacity: 1 }} transition={{ ...spring, delay: 0.25 }}>
        <span className="t-sub" style={{ flex: 1 }}>This communication is saved to the property record and tracked for audit.</span>
        <button className="btn btn-gray" onClick={() => history.back()}>Cancel</button>
        <button className="btn btn-gray" onClick={() => toast({ title: 'Draft saved', tone: 'info' })}><Save size={14} />Save draft</button>
        <motion.button className="btn btn-primary btn-lg" whileTap={{ scale: 0.97 }} onClick={stage === 2 ? () => navigate('/work') : send} disabled={stage === 1} transition={springSnappy}>
          {stage === 0 && <><Send size={15} />Send for approval</>}
          {stage === 1 && 'Sending…'}
          {stage === 2 && <><CheckIcon size={16} strokeWidth={3} />Sent · back to My Work</>}
        </motion.button>
      </motion.div>
    </div>
  )
}
