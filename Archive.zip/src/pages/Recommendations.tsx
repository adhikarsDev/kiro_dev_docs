import { useEffect, useMemo, useState } from 'react'
import { AnimatePresence, motion } from 'framer-motion'
import { ArrowRight, ClipboardList, Clock, FileSignature, Gauge, Gavel, Handshake, Sparkles, TrendingDown } from 'lucide-react'
import { navigate } from '../lib/router'
import { useApp } from '../lib/store'
import { MARKET, PROPERTIES, money, propertyById, type Property } from '../data/mock'
import { evidenceFor, geoLabel, resolveGeo, type DecisionType } from '../data/market'
import { recFor, routeFor, tierFor } from '../data/rec'
import { fadeUp, spring, springSnappy, stagger } from '../lib/motion'
import { AnimatedNumber, ConfidenceRing, PhasePill, Segmented, Sparkline, SpotlightCard } from '../components/ui'

type Kind = 'price' | 'reserve' | 'offer' | 'contract' | 'plan' | 'amend'
type Group = 'all' | 'pricing' | 'deals' | 'plans'
const GROUP: Record<Kind, Exclude<Group, 'all'>> = { price: 'pricing', reserve: 'pricing', offer: 'deals', contract: 'deals', plan: 'plans', amend: 'plans' }
const DTYPE: Partial<Record<Kind, DecisionType>> = { price: 'list', reserve: 'reserve', contract: 'contract', amend: 'plan' }
interface Rec { id: string; kind: Kind; pid: string; itemId: string; title: string; agent: string; conf: number; age: string }

const KIND: Record<Kind, { label: string; icon: typeof TrendingDown; tone: string; agent: string }> = {
  price: { label: 'Pricing', icon: TrendingDown, tone: 'sky', agent: 'Review Marketing Plan agent' },
  reserve: { label: 'Pricing', icon: Gavel, tone: 'sand', agent: 'Set Reserve Price agent' },
  offer: { label: 'Offers', icon: Handshake, tone: 'mint', agent: 'Offer Acceptance agent' },
  contract: { label: 'Contracts', icon: FileSignature, tone: 'mint', agent: 'Offer Acceptance agent' },
  plan: { label: 'Plans', icon: ClipboardList, tone: 'lavender', agent: 'Complete Marketing Plan agent' },
  amend: { label: 'Plans', icon: ClipboardList, tone: 'peach', agent: 'Review Marketing Plan agent' },
}

function useRecs(): Rec[] {
  const items = useApp((s) => s.items)
  return useMemo(() => {
    const out: Rec[] = []
    const seen = new Set<string>()
    items.forEach((i) => {
      const p = propertyById(i.propertyId)
      const n = parseInt(p.id.slice(1), 10)
      if (i.reason.includes('H&B')) out.push({ id: `o-${p.id}`, kind: 'offer', pid: p.id, itemId: i.id, title: 'Multiple-offer analysis', agent: KIND.offer.agent, conf: 81, age: '12 min ago' })
      else if (i.reason.startsWith('Marketing plan drafted')) out.push({ id: `m-${p.id}`, kind: 'plan', pid: p.id, itemId: i.id, title: 'Marketing plan draft', agent: KIND.plan.agent, conf: 84 + (n % 9), age: '38 min ago' })
      else if (((i.signal === 'reduction' && i.queue === 'exceptions') || (i.actionKind === 'recommendation' && i.queue === 'actions')) && !seen.has(p.id)) {
        seen.add(p.id)
        out.push({ id: `p-${p.id}`, kind: 'price', pid: p.id, itemId: i.id, title: 'List price reduction', agent: KIND.price.agent, conf: recFor(p).conf, age: `${(n % 50) + 4} min ago` })
      }
    })
    const used = new Set(out.map((r) => r.pid))
    const pick = (f: (p: (typeof PROPERTIES)[number]) => boolean) => { const x = PROPERTIES.find((p) => !used.has(p.id) && f(p)); if (x) used.add(x.id); return x }
    const res = pick((p) => p.phase === 'on' && !!p.hubzuId && p.bids >= 3)
    if (res) out.push({ id: `r-${res.id}`, kind: 'reserve', pid: res.id, itemId: '', title: 'Reserve price reduction', agent: KIND.reserve.agent, conf: 83, age: '9 min ago' })
    const am = pick((p) => p.phase === 'on' && (p.dom ?? 0) > 20)
    if (am) out.push({ id: `a-${am.id}`, kind: 'amend', pid: am.id, itemId: '', title: 'Marketing plan amendment', agent: KIND.amend.agent, conf: 79, age: '22 min ago' })
    const ct = pick((p) => p.phase === 'contract' && !!p.listPrice)
    if (ct) out.push({ id: `c-${ct.id}`, kind: 'contract', pid: ct.id, itemId: '', title: 'Buyer contract approval', agent: KIND.contract.agent, conf: 88, age: '3 min ago' })
    const order: Record<Kind, number> = { offer: 0, contract: 1, price: 2, reserve: 3, amend: 4, plan: 5 }
    return out.sort((a, b) => order[a.kind] - order[b.kind] || b.conf - a.conf)
  }, [items])
}

export default function Recommendations() {
  const recs = useRecs()
  const recDecision = useApp((s) => s.recDecision)
  const [filter, setFilter] = useState<Group>('all')
  const shown = recs.filter((r) => filter === 'all' || GROUP[r.kind] === filter)
  const [selId, setSelId] = useState<string | null>(null)
  const sel = shown.find((r) => r.id === selId) ?? shown[0]
  const idx = sel ? shown.indexOf(sel) : -1
  const [dir, setDir] = useState(1)

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const t = e.target as HTMLElement
      if (['INPUT', 'TEXTAREA'].includes(t?.tagName) || useApp.getState().paletteOpen) return
      if (e.key === 'ArrowDown' && shown[idx + 1]) { e.preventDefault(); setDir(1); setSelId(shown[idx + 1].id) }
      if (e.key === 'ArrowUp' && shown[idx - 1]) { e.preventDefault(); setDir(-1); setSelId(shown[idx - 1].id) }
    }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [shown, idx])

  const avg = recs.length ? Math.round(recs.reduce((a, r) => a + r.conf, 0) / recs.length) : 0
  const advancing = recs.filter((r) => r.kind !== 'plan' && r.kind !== 'amend').length

  return (
    <div className="page">
      <div className="hstack gap-12 wrap" style={{ alignItems: 'flex-end' }}>
        <div className="stack gap-4" style={{ flex: 1 }}>
          <span className="t-large">Recommendations</span>
          <span className="t-sub" style={{ fontSize: 14.5 }}>Agents prepared these for your review. Pick one to see the evidence, then decide.</span>
        </div>
        <Segmented layoutId="rec-filter" value={filter} onChange={(k) => { setFilter(k); setSelId(null) }}
          items={[{ key: 'all' as Group, label: 'All', count: recs.length }, ...([['pricing', 'Pricing'], ['deals', 'Offers & contracts'], ['plans', 'Plans']] as [Group, string][]).map(([g, l]) => ({ key: g, label: l, count: recs.filter((r) => GROUP[r.kind] === g).length }))]} />
      </div>

      <motion.div className="rec-stats" variants={stagger(0.06)} initial="hidden" animate="show">
        {[
          { icon: Sparkles, tone: 'sky', v: recs.length, l: 'Waiting for you', s: '' },
          { icon: Gauge, tone: 'mint', v: avg, l: 'Average confidence', s: '%' },
          { icon: Clock, tone: 'lavender', v: advancing, l: 'Move a property forward', s: '' },
        ].map((x) => (
          <motion.div key={x.l} className="rec-stat" variants={fadeUp}>
            <span className="rec-ico" data-tone={x.tone}><x.icon size={18} /></span>
            <div className="stack"><span className="v"><AnimatedNumber value={x.v} />{x.s}</span><span className="t-caption">{x.l}</span></div>
          </motion.div>
        ))}
      </motion.div>

      <div className="grid g-12" style={{ alignItems: 'start' }}>
        <motion.div className="card span-5 r-full" variants={fadeUp} initial="hidden" animate="show">
          <motion.div className="rec-list" variants={stagger(0.04)} initial="hidden" animate="show" key={filter}>
            {shown.map((r) => <RecRow key={r.id} r={r} on={r.id === sel?.id} decided={recDecision[r.pid]} onClick={() => { setDir(shown.indexOf(r) > idx ? 1 : -1); setSelId(r.id) }} />)}
            {!shown.length && <div className="empty">Nothing waiting here. Agents will add new recommendations as they finish.</div>}
          </motion.div>
        </motion.div>
        <div className="span-7 r-full" style={{ position: 'sticky', top: 'calc(var(--toolbar-h) + 16px)', perspective: 1400 }}>
          <AnimatePresence mode="wait" custom={dir}>
            {sel && (
              <motion.div key={sel.id} initial={{ opacity: 0, y: dir * 26, filter: 'blur(8px)' }} animate={{ opacity: 1, y: 0, filter: 'blur(0px)' }}
                exit={{ opacity: 0, y: dir * -18, filter: 'blur(6px)' }} transition={{ ...spring, duration: 0.42 }}>
                <Preview r={sel} />
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>
    </div>
  )
}

function RecRow({ r, on, decided, onClick }: { r: Rec; on: boolean; decided?: string; onClick: () => void }) {
  const p = propertyById(r.pid)
  const K = KIND[r.kind]
  const rec = recFor(p)
  const meta = r.kind === 'price'
    ? <><span className="num">{money(rec.current, { compact: true })}</span> <ArrowRight size={11} style={{ verticalAlign: -1 }} /> <b className="num" style={{ color: 'var(--sky-text)' }}>{money(rec.recommended, { compact: true })}</b></>
    : r.kind === 'reserve' ? <>Reserve <span className="num">{money(Math.round(rec.current * 0.92 / 1000) * 1000, { compact: true })}</span> <ArrowRight size={11} style={{ verticalAlign: -1 }} /> <b className="num" style={{ color: 'var(--sand-text)' }}>{money(Math.round(rec.current * 0.92 * 0.945 / 500) * 500, { compact: true })}</b></>
    : r.kind === 'contract' ? <>Contract <b className="num" style={{ color: 'var(--mint-text)' }}>{money(Math.round(rec.current * 0.955 / 500) * 500, { compact: true })}</b> · {((0.955) * 100).toFixed(1)}% of list</>
    : r.kind === 'amend' ? <>Auction → traditional · <b className="num" style={{ color: 'var(--peach-text)' }}>{money(rec.recommended, { compact: true })}</b></>
    : r.kind === 'offer' ? <>4 offers · top <b className="num" style={{ color: 'var(--mint-text)' }}>{money(331000, { compact: true })}</b></>
      : <>List <b className="num" style={{ color: 'var(--lavender-text)' }}>{money(p.valuation ?? 245000, { compact: true })}</b> · Traditional</>
  return (
    <motion.button className="rec-item" variants={fadeUp} onClick={onClick} whileTap={{ scale: 0.985 }} aria-pressed={on}>
      <span className="rec-hover" />
      {on && <motion.span layoutId="rec-sel" className="rec-sel" transition={springSnappy} />}
      <span className="rec-ico" data-tone={K.tone}><K.icon size={19} /></span>
      <span className="stack min0">
        <span className="hstack gap-6"><span className="strong ellipsis" style={{ fontSize: 14 }}>{r.title}</span>{decided && <span className="pill" data-tone="mint" style={{ height: 18, fontSize: 10.5 }}>{decided}</span>}</span>
        <span className="t-caption ellipsis">{p.street}, {p.city} {p.state}</span>
        <span className="t-sub" style={{ fontSize: 12.5, marginTop: 2 }}>{meta}</span>
      </span>
      <span className="stack" style={{ alignItems: 'flex-end', gap: 4 }}>
        <ConfidenceRing value={r.conf} size={40} stroke={4.5} tone={r.conf >= 85 ? 'mint' : 'peach'} />
        <span className="t-caption" style={{ fontSize: 10.5 }}>{r.age}</span>
      </span>
    </motion.button>
  )
}

function Preview({ r }: { r: Rec }) {
  const p = propertyById(r.pid)
  const K = KIND[r.kind]
  const { items, openConfirm } = useApp()
  const item = items.find((i) => i.id === r.itemId)
  const dt = DTYPE[r.kind]
  const open = () => navigate(dt ? `/rec/${p.id}?type=${dt}` : `/property/${p.id}`)
  const g = resolveGeo('all', '30d').geo
  const ev = evidenceFor(dt ?? (r.kind === 'offer' ? 'contract' : 'list'), p, g, 'all', '30d')
  return (
    <SpotlightCard className="rec-preview stack gap-18" tilt={2.5} tone={K.tone} style={{ gap: 18 }}>
      <div className="hstack gap-12">
        <span className="rec-ico" data-tone={K.tone} style={{ width: 46, height: 46, borderRadius: 14 }}><K.icon size={22} /></span>
        <div className="stack min0" style={{ flex: 1 }}>
          <span className="t-eyebrow" style={{ color: 'var(--tone-text)' }}>{K.label} · {r.agent}</span>
          <span className="t-title2">{r.title}</span>
          <span className="t-sub">{p.street}, {p.city} {p.state} · {p.investor} · {p.dom != null ? `${p.dom} DOM` : `${p.daysInInventory} days in inventory`}</span>
        </div>
        <ConfidenceRing value={r.conf} size={78} stroke={8} tone={r.conf >= 85 ? 'mint' : 'peach'} />
      </div>

      <div className="verdict" data-tone={ev.verdict === 'supported' ? 'mint' : 'sand'} style={{ padding: '12px 14px', flexDirection: 'column', alignItems: 'flex-start', gap: 8 }}>
        <span className="stack">
          <span className="strong t-tone" style={{ fontSize: 13.5 }}>{ev.verdict === 'supported' ? 'Supported by current market conditions' : 'Partially supported'}</span>
          <span className="t-caption">{ev.supportCount} of {ev.total} market & property signals support · {geoLabel(g, p)} · last 30 days</span>
        </span>
        <span className="hstack gap-6 wrap">
          {ev.ranked.filter((x) => x.read === 'supports').slice(0, 2).map((x) => <span key={x.key} className="pill" data-tone="mint">{x.label}</span>)}
          {ev.ranked.filter((x) => x.read === 'contrary').slice(0, 1).map((x) => <span key={x.key} className="pill" data-tone="peach">{x.label}</span>)}
        </span>
      </div>
      {(r.kind === 'price' || r.kind === 'reserve' || r.kind === 'amend' || r.kind === 'contract') && <PricePreview p={p} kind={r.kind} />}
      {r.kind === 'offer' && <OfferPreview />}
      {r.kind === 'plan' && <PlanPreview p={p} />}

      <div className="hstack gap-8 wrap" style={{ paddingTop: 4 }}>
        <PhasePill phase={p.phase} />
        <span className="t-caption">Generated {r.age} · every decision is logged to the audit trail</span>
        <span className="spacer" />
        <button className="btn btn-gray" onClick={() => navigate(`/property/${p.id}`)}>Open property</button>
        {r.kind !== 'price' && item && (
          <button className="btn btn-tinted" onClick={(e) => openConfirm({ kind: 'approve', itemId: item.id, origin: { x: e.clientX, y: e.clientY } })}>Approve as drafted</button>
        )}
        <motion.button className="btn btn-primary btn-lg" whileTap={{ scale: 0.97 }} onClick={open}>Review & decide <ArrowRight size={15} /></motion.button>
      </div>
    </SpotlightCard>
  )
}

/* -------- price ladder: where the recommendation sits against the evidence -------- */
function PricePreview({ p, kind = 'price' }: { p: Property; kind?: Kind }) {
  const base = recFor(p)
  const reserve = Math.round((base.current * 0.92) / 1000) * 1000
  const rec = kind === 'reserve' ? { ...base, current: reserve, recommended: Math.round((reserve * 0.945) / 500) * 500 }
    : kind === 'contract' ? { ...base, recommended: Math.round((base.current * 0.955) / 500) * 500 } : base
  const pct = (rec.current - rec.recommended) / rec.current
  const route = routeFor(tierFor(pct), p.investor)
  const marks = kind === 'reserve' ? [
    { v: Math.round((rec.current * 0.925) / 500) * 500, l: 'Highest bid', tone: 'gray' },
    { v: rec.current, l: 'Current reserve', tone: 'rose' },
    { v: base.current, l: 'List price', tone: 'lavender' },
  ] : [
    { v: p.prevHighOffer ?? rec.msaMedian * 0.99, l: 'Prev. highest offer', tone: 'gray' },
    { v: rec.msaMedian, l: 'MSA median (comp)', tone: 'lavender' },
    { v: p.valuation ?? rec.current * 0.95, l: 'Valuation', tone: 'mint' },
    { v: rec.current, l: 'Current list', tone: 'rose' },
  ]
  marks.sort((a, b) => a.v - b.v)
  const lo = Math.min(...marks.map((m) => m.v), rec.recommended) * 0.985
  const hi = Math.max(...marks.map((m) => m.v), rec.recommended) * 1.012
  const x = (v: number) => `${((v - lo) / (hi - lo)) * 100}%`
  return (
    <>
      <div className="inset" style={{ padding: '14px 18px 8px' }}>
        <div className="hstack" style={{ marginBottom: 2 }}>
          <span className="t-headline" style={{ flex: 1 }}>{kind === 'contract' ? 'Where the contract price sits' : kind === 'reserve' ? 'Where the new reserve sits' : 'Where the new price sits'}</span>
          <span className="t-sub"><b className="num" style={{ color: 'var(--label)' }}>{money(rec.current)}</b> → <b className="num" style={{ color: 'var(--blue-text)' }}><AnimatedNumber value={rec.recommended} format={(n) => money(Math.round(n))} /></b> <span style={{ color: 'var(--rose-text)' }}>(−{(pct * 100).toFixed(1)}%)</span></span>
        </div>
        <div className="ladder" style={{ height: 104 }}>
          <div className="ladder-track" />
          <motion.div className="ladder-range" style={{ left: x(rec.recommended) }} initial={{ width: 0 }} animate={{ width: `calc(${x(rec.current)} - ${x(rec.recommended)})` }} transition={{ ...spring, duration: 0.9, delay: 0.15 }} />
          {marks.map((m, i) => (
            <div key={m.l}>
              <motion.span className="ladder-mark" data-tone={m.tone} style={{ left: x(m.v) }} initial={{ scale: 0 }} animate={{ scale: 1 }} transition={{ ...spring, delay: 0.2 + i * 0.07 }} />
              <motion.span className="ladder-lbl" style={{ left: x(m.v), top: i % 2 ? 62 : 0 }} initial={{ opacity: 0, y: i % 2 ? -6 : 6 }} animate={{ opacity: 1, y: 0 }} transition={{ ...spring, delay: 0.25 + i * 0.07 }}>
                {i % 2 ? <><b>{money(m.v, { compact: true })}</b>{m.l}</> : <>{m.l}<b>{money(m.v, { compact: true })}</b></>}
              </motion.span>
            </div>
          ))}
          <motion.span className="ladder-lbl" style={{ left: x(rec.recommended), top: 62, color: 'var(--blue-text)', fontWeight: 600 }}
            initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.9 }}>
            <b style={{ color: 'var(--blue-text)' }}>{money(rec.recommended, { compact: true })}</b>{kind === 'contract' ? 'Contract' : 'Recommended'}
          </motion.span>
          <motion.span className="ladder-mark big" style={{ left: x(rec.recommended) }} initial={{ left: x(rec.current), scale: 0.6 }} animate={{ left: x(rec.recommended), scale: 1 }} transition={{ type: 'spring', bounce: 0.25, duration: 0.9, delay: 0.3 }} />
        </div>
      </div>
      <div className="grid" style={{ gridTemplateColumns: 'repeat(3, minmax(0, 1fr))', gap: 10 }}>
        {MARKET.metrics.slice(0, 3).map((m) => (
          <div key={m.key} className="inset stack gap-4" style={{ padding: '12px 14px' }}>
            <span className="t-caption">{m.label}</span>
            <div className="hstack gap-8"><span className="t-title3 num" style={{ flex: 1 }}>{m.value}</span><Sparkline values={m.spark} tone="rose" w={56} h={22} /></div>
            <span className="t-caption" style={{ color: 'var(--rose-text)' }}>{m.delta} vs prior month</span>
          </div>
        ))}
      </div>
      <div className="hstack gap-6 wrap">
        <span className="t-caption" style={{ marginRight: 4 }}>Approval route</span>
        {route.map((s, i) => (
          <span key={s} className="hstack gap-6">
            <span className="pill" data-tone={i === 0 ? 'blue' : 'gray'}>{s}</span>
            {i < route.length - 1 && <ArrowRight size={12} className="t-3" />}
          </span>
        ))}
      </div>
    </>
  )
}

/* -------- offer comparison: net to seller, not just gross -------- */
const OFFERS = [
  { buyer: 'Harbor Homes LLC', fin: 'Cash', gross: 331000, credits: 0, close: '14 days' },
  { buyer: 'D. Okafor', fin: 'Conventional', gross: 326500, credits: 4000, close: '30 days' },
  { buyer: 'S. Lindqvist', fin: 'FHA', gross: 318000, credits: 6500, close: '45 days' },
  { buyer: 'Brightline Capital', fin: 'Cash', gross: 309900, credits: 0, close: '10 days' },
]
function OfferPreview() {
  const rows = OFFERS.map((o) => ({ ...o, net: Math.round(o.gross * 0.945 - o.credits) }))
  const max = Math.max(...rows.map((r) => r.net))
  const reserve = 300000
  return (
    <>
      <div className="inset stack gap-8" style={{ padding: '14px 16px' }}>
        <div className="hstack"><span className="t-headline" style={{ flex: 1 }}>Net to seller</span><span className="t-caption">after 5.5% commissions and seller credits · reserve {money(reserve, { compact: true })}</span></div>
        {rows.map((r, i) => (
          <div key={r.buyer} className="hstack gap-10">
            <span className="stack" style={{ width: 150 }}><span className="strong ellipsis" style={{ fontSize: 13 }}>{r.buyer}</span><span className="t-caption">{r.fin} · close {r.close}</span></span>
            <div className="offer-bar" style={{ flex: 1 }} data-tone={i === 0 ? 'mint' : 'sky'}>
              <motion.div className="offer-fill" initial={{ width: 0 }} animate={{ width: `${(r.net / max) * 100}%` }} transition={{ ...spring, duration: 0.9, delay: 0.1 + i * 0.08 }} />
              <span><b className="num">{money(r.net)}</b><span className="t-caption">gross {money(r.gross, { compact: true })}{r.credits ? ` · credits ${money(r.credits, { compact: true })}` : ''}</span></span>
            </div>
            {i === 0 && <span className="pill" data-tone="mint">Best net</span>}
          </div>
        ))}
      </div>
      <div className="callout" data-tone="mint" style={{ fontSize: 13.5 }}>
        <b>Recommended:</b> ask all four for highest &amp; best by tomorrow 5 PM, then accept the best net. Harbor Homes leads today: cash, no credits, 14-day close.
      </div>
    </>
  )
}

/* -------- marketing plan: valuation reconciliation + plan terms -------- */
function PlanPreview({ p }: { p: Property }) {
  const a = p.valuation ?? 245000
  const b = Math.round((a * 1.043) / 1000) * 1000
  const diff = ((b - a) / a) * 100
  const fields = [['List price', money(a)], ['Listing type', 'Traditional (local broker)'], ['Commission', '2.5% listing · 2.5% selling'], ['Review cadence', 'Every 14 days']]
  return (
    <>
      <div className="inset stack gap-10" style={{ padding: '14px 16px' }}>
        <div className="hstack"><span className="t-headline" style={{ flex: 1 }}>Valuation reconciliation</span><span className="pill" data-tone={diff >= 5 ? 'peach' : 'mint'}>{diff.toFixed(1)}% apart {diff >= 5 ? '· needs your judgment' : '· within 5%'}</span></div>
        {[['BPO (ValuePoint)', a], ['Broker opinion', b]].map(([l, v], i) => (
          <div key={l as string} className="hstack gap-10">
            <span className="t-sub" style={{ width: 130 }}>{l}</span>
            <div className="offer-bar" style={{ flex: 1 }} data-tone="lavender">
              <motion.div className="offer-fill" initial={{ width: 0 }} animate={{ width: `${((v as number) / b) * 100}%` }} transition={{ ...spring, duration: 0.9, delay: 0.1 + i * 0.1 }} />
              <span><b className="num">{money(v as number)}</b></span>
            </div>
          </div>
        ))}
      </div>
      <div className="grid" style={{ gridTemplateColumns: 'repeat(2, minmax(0, 1fr))', gap: 10 }}>
        {fields.map(([k, v]) => (
          <div key={k} className="inset" style={{ padding: '10px 14px' }}><div className="t-caption">{k}</div><div className="t-headline">{v}</div></div>
        ))}
      </div>
    </>
  )
}
