// Deterministic mock portfolio for one Asset Manager (~236 files, per the transcript's
// "a couple hundred files, 20–40 exceptions on any given day").

export type Phase = 'pre' | 'on' | 'contract' | 'closing' | 'sold'
export type Queue = 'exceptions' | 'actions' | 'approvals' | 'watch'
export type SignalKey = 'trashout' | 'novalue' | 'investor' | 'reduction' | 'eviction' | 'closing'
export type Risk = 'High' | 'Medium' | 'Low'
export type ActionKind =
  | 'vendor' | 'investor' | 'recommendation' | 'eviction' | 'contract'
  | 'approve' | 'review' | 'closing' | 'view'

export const PHASES: { key: Phase; label: string; short: string }[] = [
  { key: 'pre', label: 'Pre-Marketing', short: 'Pre-Mkt' },
  { key: 'on', label: 'On-Market', short: 'On-Mkt' },
  { key: 'contract', label: 'Under Contract', short: 'Contract' },
  { key: 'closing', label: 'Closing', short: 'Closing' },
  { key: 'sold', label: 'Sold · 30d', short: 'Sold' },
]
export const phaseLabel = (p: Phase) => PHASES.find((x) => x.key === p)!.label

export const LIFECYCLE = [
  'Foreclosure', 'Boarding', 'Occupancy', 'Initial Services', 'Valuation',
  'Marketing', 'Offers', 'Contract', 'Closing', 'Sold',
]

export interface Property {
  id: string
  loan: string
  street: string
  city: string
  state: string
  zip: string
  msa: string
  investor: string
  phase: Phase
  stage: number // index in LIFECYCLE
  daysInInventory: number
  daysInPhase: number
  dom: number | null
  listPrice: number | null
  valuation: number | null
  prevHighOffer: number | null
  bids: number
  bidders: number
  broker: string
  occupancy: 'Vacant' | 'Occupied' | 'Unknown'
  type: 'Single Family' | 'Townhome' | 'Condo' | 'Multi-Family'
  beds: number
  baths: number
  sqft: number
  titleTrack: boolean
  hubzuId: string | null
}

export interface WorkItem {
  id: string
  propertyId: string
  queue: Queue
  signal?: SignalKey
  approaching?: boolean
  reason: string
  detail: string
  days: number
  slaDays: number
  risk: Risk
  nextAction: string
  actionKind: ActionKind
  counterparty: string
  actToday?: boolean
  approvedAgo?: string
  offer?: { amount: number; financing: string; buyer: string; type: 'accept' | 'counter' }
  status: 'Review Required' | 'Ready' | 'Blocked' | 'Waiting External' | 'Approval Pending' | 'Completed'
  note?: string
}

// ---------- seeded RNG ----------
function mulberry32(a: number) {
  return function () {
    a |= 0; a = (a + 0x6d2b79f5) | 0
    let t = Math.imul(a ^ (a >>> 15), 1 | a)
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296
  }
}
const rnd = mulberry32(20261103)
const pick = <T,>(arr: T[]) => arr[Math.floor(rnd() * arr.length)]
const int = (a: number, b: number) => a + Math.floor(rnd() * (b - a + 1))

const CITIES: [string, string, string, string][] = [
  ['Phoenix', 'AZ', '850', 'Phoenix–Mesa'], ['Mesa', 'AZ', '852', 'Phoenix–Mesa'],
  ['Dallas', 'TX', '752', 'Dallas–Fort Worth'], ['Houston', 'TX', '770', 'Houston'],
  ['Austin', 'TX', '787', 'Austin'], ['Atlanta', 'GA', '303', 'Atlanta'],
  ['Orlando', 'FL', '328', 'Orlando'], ['Tampa', 'FL', '336', 'Tampa Bay'],
  ['Jacksonville', 'FL', '322', 'Jacksonville'], ['Miami', 'FL', '331', 'Miami'],
  ['Charlotte', 'NC', '282', 'Charlotte'], ['Raleigh', 'NC', '276', 'Raleigh'],
  ['Las Vegas', 'NV', '891', 'Las Vegas'], ['Denver', 'CO', '802', 'Denver'],
  ['Columbus', 'OH', '432', 'Columbus'], ['Memphis', 'TN', '381', 'Memphis'],
  ['Indianapolis', 'IN', '462', 'Indianapolis'], ['Birmingham', 'AL', '352', 'Birmingham'],
  ['Baltimore', 'MD', '212', 'Baltimore'], ['Manassas', 'VA', '201', 'Washington'],
]
const STREETS = [
  'Maple Grove Dr', 'Oak Ave', 'Pine Rd', 'Cedar Ln', 'Birch Ct', 'Spruce Dr', 'Palm Way', 'Elm St',
  'Lakeview Rd', 'Willow Ct', 'Ash St', 'Westland Pl', 'Hope St', 'Jeddo Rd', 'Commodore Ave',
  'Sunset Blvd', 'River Rd', 'Juniper Way', 'Magnolia Dr', 'Aspen Ct', 'Hawthorne St', 'Sycamore Ln',
  'Bluebonnet Dr', 'Cypress Pt', 'Mesquite Trl', 'Peachtree Ct', 'Sagebrush Rd', 'Harbor View Dr',
  'Granite Ridge', 'Meadowlark Ln', 'Chestnut St', 'Briarwood Dr', 'Foxglove Ct', 'Redbud Ln',
  'Silver Creek Rd', 'Canyon Vista Dr',
]
const BROKERS: Record<string, string> = {
  AZ: 'AZ Prime Realty', TX: 'Lone Star REO Group', GA: 'Peachtree Asset Realty', FL: 'Suncoast REO Partners',
  NC: 'Carolina Crest Realty', NV: 'Desert Peak Brokers', CO: 'Front Range REO', OH: 'Buckeye Realty Group',
  TN: 'River City Brokers', IN: 'Hoosier Home Realty', AL: 'Magnolia REO', MD: 'Chesapeake Realty', VA: 'Old Dominion REO',
}
const INVESTORS = ['SPS', 'SPS', 'SPS', 'SPS', 'SPS', 'Onity/PHH', 'Onity/PHH', 'Calibr', 'Calibr', 'NRZ/Newrez']
const TYPES: Property['type'][] = ['Single Family', 'Single Family', 'Single Family', 'Townhome', 'Condo', 'Multi-Family']

// Hand-seeded files that mirror the wireframes, so reviewers recognise them.
const SEEDED: Partial<Property>[] = [
  { street: '1234 Maple Grove Dr', city: 'Phoenix', state: 'AZ', zip: '85032', phase: 'on', investor: 'SPS' },
  { street: '5678 Oak Ave', city: 'Dallas', state: 'TX', zip: '75201', phase: 'pre', investor: 'SPS' },
  { street: '9101 Pine Rd', city: 'Atlanta', state: 'GA', zip: '30309', phase: 'on', investor: 'SPS' },
  { street: '2222 Cedar Ln', city: 'Orlando', state: 'FL', zip: '32801', phase: 'on', investor: 'SPS' },
  { street: '3456 Birch Ct', city: 'Charlotte', state: 'NC', zip: '28202', phase: 'on', investor: 'Calibr' },
  { street: '7890 Spruce Dr', city: 'Tampa', state: 'FL', zip: '33607', phase: 'on', investor: 'SPS' },
  { street: '1500 Palm Way', city: 'Las Vegas', state: 'NV', zip: '89144', phase: 'closing', investor: 'Onity/PHH' },
  { street: '4321 Elm St', city: 'Houston', state: 'TX', zip: '77002', phase: 'pre', investor: 'SPS' },
]

const PHASE_COUNTS: Record<Phase, number> = { pre: 88, on: 79, contract: 31, closing: 17, sold: 21 }

function makeProperty(i: number, phase: Phase, seed?: Partial<Property>): Property {
  const c = seed?.city ? CITIES.find((x) => x[0] === seed.city)! : pick(CITIES)
  const [city, state, zp, msa] = c
  const street = seed?.street ?? `${int(100, 9899)} ${pick(STREETS)}`
  const listBase = state === 'CA' ? 600000 : int(9, 52) * 10000 + int(0, 9) * 1000
  const stage =
    phase === 'pre' ? pick([2, 3, 3, 4, 4]) : phase === 'on' ? pick([5, 5, 6]) : phase === 'contract' ? 7 : phase === 'closing' ? 8 : 9
  const daysInInventory =
    phase === 'pre' ? int(3, 45) : phase === 'on' ? int(40, 140) : phase === 'contract' ? int(70, 170) : phase === 'closing' ? int(90, 190) : int(110, 220)
  const dom = phase === 'pre' ? null : phase === 'on' ? int(3, 28) : int(18, 80)
  const listed = phase !== 'pre'
  const bids = listed ? int(0, 7) : 0
  return {
    id: `P${String(i + 1).padStart(3, '0')}`,
    loan: `${pick(['0021', '0032', '7143', 'SPS1', 'LN00'])}${String(int(100000, 999999))}`,
    street,
    city,
    state,
    zip: seed?.zip ?? `${zp}${int(10, 99)}`,
    msa,
    investor: seed?.investor ?? pick(INVESTORS),
    phase,
    stage,
    daysInInventory,
    daysInPhase: Math.max(1, Math.round(daysInInventory * (phase === 'pre' ? 0.9 : 0.4))),
    dom,
    listPrice: listed ? listBase : null,
    valuation: stage >= 4 ? Math.round((listBase * (1 + (rnd() - 0.45) * 0.08)) / 1000) * 1000 : null,
    prevHighOffer: bids > 0 ? Math.round((listBase * (0.82 + rnd() * 0.12)) / 500) * 500 : null,
    bids,
    bidders: Math.max(0, bids - int(0, 2)),
    broker: BROKERS[state] ?? 'Keystone REO Brokers',
    occupancy: phase === 'pre' ? pick(['Vacant', 'Vacant', 'Vacant', 'Vacant', 'Occupied', 'Unknown']) : 'Vacant',
    type: pick(TYPES),
    beds: int(2, 5),
    baths: int(1, 3),
    sqft: int(9, 32) * 100,
    titleTrack: false,
    hubzuId: listed ? `H${int(2100000, 2199999)}` : null,
  }
}

function buildProperties(): Property[] {
  const out: Property[] = []
  SEEDED.forEach((s) => out.push(makeProperty(out.length, s.phase as Phase, s)))
  ;(Object.keys(PHASE_COUNTS) as Phase[]).forEach((ph) => {
    const already = out.filter((p) => p.phase === ph).length
    for (let k = already; k < PHASE_COUNTS[ph]; k++) out.push(makeProperty(out.length, ph))
  })
  // Title runs as a parallel track: all closings + 7 contracts.
  let contractTitle = 0
  out.forEach((p) => {
    if (p.phase === 'closing') p.titleTrack = true
    if (p.phase === 'contract' && contractTitle < 7) { p.titleTrack = true; contractTitle++ }
  })
  // Pin seeded facts that the wireframes show.
  const maple = out[0]
  Object.assign(maple, {
    loan: 'SPS1234567', stage: 5, daysInInventory: 72, daysInPhase: 40, dom: 42, listPrice: 425000,
    valuation: 404000, prevHighOffer: 380000, bids: 5, bidders: 3, type: 'Single Family', beds: 4,
    baths: 2, sqft: 2140, occupancy: 'Vacant', hubzuId: 'H2123456', msa: 'Phoenix–Mesa',
  })
  Object.assign(out[1], { loan: 'LN005678', stage: 3, daysInInventory: 22, occupancy: 'Vacant' })
  Object.assign(out[2], { loan: 'LN009101', stage: 5, dom: 32, listPrice: 289000, bids: 1, bidders: 1 })
  Object.assign(out[3], { loan: 'LN002222', stage: 5, dom: 47, listPrice: 254900 })
  Object.assign(out[4], { loan: 'LN003456', stage: 6, dom: 19, listPrice: 336000, bids: 4, bidders: 4, prevHighOffer: 331000 })
  Object.assign(out[5], { loan: 'LN007890', stage: 6, dom: 24, listPrice: 219900, bids: 3, bidders: 2, prevHighOffer: 214000 })
  Object.assign(out[6], { loan: 'LN001500', stage: 8, listPrice: 389000, titleTrack: true })
  Object.assign(out[7], { loan: 'LN004321', stage: 2, daysInInventory: 9, occupancy: 'Occupied' })
  // Keep valuations and best offers consistent with the overridden list prices.
  ;[2, 3, 6].forEach((i) => { const l = out[i].listPrice!; out[i].valuation = Math.round((l * 1.015) / 1000) * 1000; out[i].prevHighOffer = out[i].bids ? Math.round((l * 0.9) / 500) * 500 : null })
  ;[4, 5].forEach((i) => { out[i].valuation = Math.round((out[i].listPrice! * 1.02) / 1000) * 1000 })
  return out
}

export const PROPERTIES: Property[] = buildProperties()
export const propertyById = (id: string) => PROPERTIES.find((p) => p.id === id)!

// ---------- work items ----------
let wid = 0
const W = (p: Property, w: Omit<WorkItem, 'id' | 'propertyId'>): WorkItem => ({ id: `W${++wid}`, propertyId: p.id, ...w })

function take(phase: Phase, n: number, used: Set<string>, filter: (p: Property) => boolean = () => true) {
  const res: Property[] = []
  for (const p of PROPERTIES) {
    if (res.length >= n) break
    if (p.phase === phase && !used.has(p.id) && filter(p)) { res.push(p); used.add(p.id) }
  }
  return res
}

function buildItems(): WorkItem[] {
  const used = new Set<string>()
  const items: WorkItem[] = []
  const P = PROPERTIES
  const mark = (p: Property) => used.add(p.id)
  // Reserve the hand-seeded files so generic picks never double-assign them.
  P.slice(0, SEEDED.length).forEach(mark)

  // --- Exceptions (39) ---
  // Trash-out not complete, 15+ days (10)
  mark(P[1])
  const trash = [P[1], ...take('pre', 9, used, (p) => p.occupancy === 'Vacant')]
  trash.forEach((p, i) => {
    const d = i === 0 ? 22 : [15, 16, 17, 18, 19, 21, 24, 26, 28][i - 1]
    p.daysInInventory = d; p.stage = 3; p.occupancy = 'Vacant'
    items.push(W(p, {
      queue: 'exceptions', signal: 'trashout', reason: 'Trash-out not complete',
      detail: `Ordered with Triple R ${Math.max(3, d - 9)}d ago · no completion photos`, days: d, slaDays: 15,
      risk: d >= 20 ? 'High' : 'Medium', nextAction: 'Follow up with Triple R', actionKind: 'vendor',
      counterparty: 'Triple R', status: 'Waiting External',
    }))
  })
  // No valuation, 10+ days (7)
  take('pre', 7, used).forEach((p, i) => {
    const d = [10, 11, 12, 13, 14, 16, 19][i]
    p.daysInInventory = d; p.stage = 4; p.valuation = null
    items.push(W(p, {
      queue: 'exceptions', signal: 'novalue', reason: 'No valuation received',
      detail: `BPO ordered ${d - 2}d ago · ValuePoint BPO`, days: d, slaDays: 10,
      risk: d >= 12 ? 'High' : 'Medium', nextAction: 'Request BPO status', actionKind: 'vendor',
      counterparty: 'BPO vendor', status: 'Waiting External',
    }))
  })
  // Eviction (4)
  mark(P[7])
  const evic = [P[7], ...take('pre', 3, used)]
  evic.forEach((p, i) => {
    p.occupancy = 'Occupied'; p.stage = 2
    const routed = i >= 2
    const d = [7, 12, 9, 16][i]
    p.daysInInventory = Math.max(p.daysInInventory, d + 2)
    items.push(W(p, {
      queue: 'exceptions', signal: 'eviction',
      reason: routed ? 'Eviction check-in overdue' : 'Occupied — eviction not routed',
      detail: routed ? `Last ESD update ${d}d ago · attorney status unknown` : 'Occupancy confirmed occupied · ESD not engaged',
      days: d, slaDays: routed ? 7 : 1, risk: 'High',
      nextAction: routed ? 'Request ESD status' : 'Route to ESD (Pam’s team)', actionKind: 'eviction',
      counterparty: 'ESD · Pam’s team', status: routed ? 'Waiting External' : 'Review Required',
    }))
  })
  // Investor response overdue (9): 3 initial listing (pre) + 6 reduction (on)
  take('pre', 3, used).forEach((p, i) => {
    const d = [3, 5, 9][i]
    p.stage = 4
    items.push(W(p, {
      queue: 'exceptions', signal: 'investor', reason: 'Initial listing approval pending',
      detail: `Sent to ${p.investor} ${d}d ago · no response`, days: d, slaDays: 3,
      risk: d >= 5 ? 'High' : 'Medium', nextAction: 'Send investor follow-up', actionKind: 'investor',
      counterparty: p.investor, status: 'Approval Pending',
    }))
  })
  mark(P[3])
  const invOn = [P[3], ...take('on', 5, used)]
  invOn.forEach((p, i) => {
    const d = [16, 4, 6, 8, 11, 20][i]
    items.push(W(p, {
      queue: 'exceptions', signal: 'investor', reason: 'Reduction request pending',
      detail: `Requested −${(4 + (i % 3) * 0.75).toFixed(1)}% · sent ${d}d ago`, days: d, slaDays: 3,
      risk: d >= 8 ? 'High' : 'Medium', nextAction: 'Send investor follow-up', actionKind: 'investor',
      counterparty: p.investor, status: 'Approval Pending',
    }))
  })
  // Price reduction due: 30+ DOM, no accepted offer (6)
  mark(P[0]); mark(P[2])
  const red = [P[0], P[2], ...take('on', 4, used)]
  red.forEach((p, i) => {
    if (i >= 2) { p.dom = [31, 36, 44, 58][i - 2]; p.stage = 5 }
    const d = p.dom!
    items.push(W(p, {
      queue: 'exceptions', signal: 'reduction', reason: '30+ days on market, no accepted offer',
      detail: `${p.bids} bids · ${p.bidders} bidders · ${i === 0 ? 'AI analysis ready' : 'review cadence due'}`,
      days: d, slaDays: 30, risk: d >= 40 ? 'High' : 'Medium', nextAction: 'Build reduction case',
      actionKind: 'recommendation', counterparty: p.investor, status: 'Review Required',
    }))
  })
  // Closing at risk (3)
  mark(P[6])
  const clo = [P[6], ...take('closing', 2, used)]
  const cloReasons = [
    ['Closing delayed — buyer not responding', 'Target close Oct 29 · per diem $85/day', 5],
    ['Title condition open — HOA lien', 'ResWare: lien payoff letter outstanding', 3],
    ['Closing date passed — amended date needed', 'Lender CD not issued · buyer financing', 2],
  ] as const
  clo.forEach((p, i) => {
    items.push(W(p, {
      queue: 'exceptions', signal: 'closing', reason: cloReasons[i][0], detail: cloReasons[i][1],
      days: cloReasons[i][2], slaDays: 0, risk: i === 0 ? 'High' : 'Medium',
      nextAction: 'Follow up with buyer / title', actionKind: 'closing', counterparty: 'Title · ResWare',
      status: 'Blocked',
    }))
  })

  // --- Actions Ready (12) ---
  mark(P[5])
  const offerProps = [P[5], ...take('on', 2, used)]
  const offers = [
    { amount: 214000, financing: 'Conventional', buyer: 'A. Peterson', type: 'accept' as const, ago: '2 h ago' },
    { amount: 312500, financing: 'Cash', buyer: 'Harbor Homes LLC', type: 'counter' as const, ago: '47 min ago' },
    { amount: 189900, financing: 'FHA', buyer: 'J. Ramirez', type: 'accept' as const, ago: '3 h ago' },
  ]
  offerProps.forEach((p, i) => {
    const o = offers[i]
    p.stage = 6
    if (i > 0) { p.listPrice = Math.round((o.amount * 1.04) / 1000) * 1000; p.prevHighOffer = o.amount; p.bids = Math.max(p.bids, 2) }
    items.push(W(p, {
      queue: 'actions', actToday: true, approvedAgo: o.ago,
      reason: o.type === 'accept' ? `${p.investor} approved acceptance — contract not sent` : `${p.investor} approved counter at ${money(o.amount)}`,
      detail: `${o.buyer} · ${o.financing} · ${money(o.amount)}`, days: 0, slaDays: 1, risk: 'High',
      nextAction: o.type === 'accept' ? 'Accept & send contract' : 'Send counter', actionKind: 'contract',
      counterparty: o.buyer, offer: { amount: o.amount, financing: o.financing, buyer: o.buyer, type: o.type },
      status: 'Ready',
    }))
  })
  take('pre', 2, used).forEach((p, i) => {
    items.push(W(p, {
      queue: 'actions', reason: 'Triple R trash-out bid ready', detail: `Bid ${money([1850, 2340][i])} · 22 cu yd · photos attached`,
      days: 1, slaDays: 2, risk: 'Medium', nextAction: 'Approve bid', actionKind: 'approve', counterparty: 'Triple R', status: 'Ready',
    }))
  })
  take('pre', 2, used).forEach((p) => {
    p.stage = 4
    items.push(W(p, {
      queue: 'actions', reason: 'Marketing plan drafted by CMP agent', detail: 'List price, commissions and listing type prepared',
      days: 0, slaDays: 2, risk: 'Medium', nextAction: 'Review plan', actionKind: 'review', counterparty: 'CMP agent', status: 'Ready',
    }))
  })
  take('on', 2, used).forEach((p) => {
    items.push(W(p, {
      queue: 'actions', reason: 'Price reduction analysis ready', detail: 'Review Marketing Plan agent · 82% confidence',
      days: 0, slaDays: 2, risk: 'Medium', nextAction: 'Review recommendation', actionKind: 'recommendation', counterparty: p.investor, status: 'Ready',
    }))
  })
  mark(P[4])
  items.push(W(P[4], {
    queue: 'actions', reason: '4 offers received — H&B analysis ready', detail: 'Highest $331,000 cash · 2 above reserve',
    days: 1, slaDays: 1, risk: 'High', nextAction: 'Review offers', actionKind: 'review', counterparty: 'Offer Acceptance agent', status: 'Ready',
  }))
  take('pre', 1, used).forEach((p) => items.push(W(p, {
    queue: 'actions', reason: 'Listing agreement received from broker', detail: 'Signed by broker · ready for Hubzu',
    days: 1, slaDays: 2, risk: 'Low', nextAction: 'Approve & send to Hubzu', actionKind: 'approve', counterparty: p.broker, status: 'Ready',
  })))
  take('closing', 1, used).forEach((p) => items.push(W(p, {
    queue: 'actions', reason: 'Final HUD ready for review', detail: 'Seller credits $3,200 · per diem none',
    days: 0, slaDays: 1, risk: 'Medium', nextAction: 'Review settlement', actionKind: 'review', counterparty: 'Title · ResWare', status: 'Ready',
  })))

  // --- Approvals Waiting (7) ---
  const appr: [Phase, string, number][] = [
    ['on', 'Reduction request', 1], ['on', 'Reduction request', 2], ['pre', 'Initial listing approval', 1],
    ['pre', 'Marketing plan approval', 0], ['on', 'Offer acceptance request', 0], ['on', 'Counter approval', 1], ['pre', 'Initial listing approval', 2],
  ]
  appr.forEach(([ph, what, d]) => take(ph, 1, used).forEach((p) => items.push(W(p, {
    queue: 'approvals', reason: `${what} · with ${p.investor}`, detail: d === 0 ? 'Sent today · Day 3 follow-up scheduled' : `Sent ${d}d ago · follow-up on day 3`,
    days: d, slaDays: 3, risk: 'Low', nextAction: 'View package', actionKind: 'view', counterparty: p.investor, status: 'Approval Pending',
  }))))

  // --- Watchlist (14) ---
  take('pre', 4, used).forEach((p, i) => {
    const d = [5, 6, 8, 9][i]
    p.daysInInventory = d; p.stage = 4; p.valuation = null
    items.push(W(p, {
      queue: 'watch', signal: 'novalue', approaching: true, reason: 'Valuation pending — nearing 10-day limit',
      detail: `BPO ordered ${d - 1}d ago`, days: d, slaDays: 10, risk: 'Low', nextAction: 'Request BPO status', actionKind: 'vendor',
      counterparty: 'BPO vendor', status: 'Waiting External',
    }))
  })
  take('pre', 4, used).forEach((p, i) => {
    p.occupancy = 'Occupied'; p.stage = 2
    items.push(W(p, {
      queue: 'watch', reason: 'Eviction in progress', detail: `Hearing ${['Nov 12', 'Nov 18', 'Dec 2', 'Nov 21'][i]} · ESD weekly check-in on track`,
      days: [3, 5, 2, 6][i], slaDays: 7, risk: 'Low', nextAction: 'View', actionKind: 'view', counterparty: 'ESD · Pam’s team', status: 'Waiting External',
    }))
  })
  take('pre', 3, used).forEach((p, i) => items.push(W(p, {
    queue: 'watch', reason: 'Initial services in progress', detail: `Triple R confirmed · re-check in ${[18, 41, 66][i]} h`,
    days: [2, 1, 1][i], slaDays: 3, risk: 'Low', nextAction: 'View', actionKind: 'view', counterparty: 'Triple R', status: 'Waiting External',
  })))
  take('contract', 3, used, (p) => p.titleTrack).forEach((p, i) => items.push(W(p, {
    queue: 'watch', reason: 'Title search in progress', detail: `ResWare · commitment expected ${['Nov 5', 'Nov 6', 'Nov 8'][i]}`,
    days: [4, 3, 1][i], slaDays: 10, risk: 'Low', nextAction: 'View', actionKind: 'view', counterparty: 'Title · ResWare', status: 'Waiting External',
  })))

  return items
}

export function money(n: number | null | undefined, opts: { compact?: boolean } = {}) {
  if (n == null) return '—'
  if (opts.compact && Math.abs(n) >= 1000) return `${n < 0 ? '−' : ''}$${(Math.abs(n) / 1000).toFixed(n % 1000 === 0 ? 0 : 1)}k`
  return n.toLocaleString('en-US', { style: 'currency', currency: 'USD', maximumFractionDigits: 0 })
}

export const INITIAL_ITEMS: WorkItem[] = buildItems()

// ---------- Signals (the transcript's "big, bold signals") ----------
export interface SignalDef {
  key: SignalKey
  title: string
  threshold: string
  owner: string
  cta: (n: number) => string
  sentLabel: (n: number) => string
  severity: 'critical' | 'serious'
  recheck: string
  phase: Phase
  template: {
    name: string
    to: string
    toEmail: string
    cc: string
    subject: (n: number) => string
    intro: string
    ask: string
  }
}

export const SIGNALS: SignalDef[] = [
  {
    key: 'trashout', title: 'Trash-outs not complete', threshold: '15+ days in portfolio', owner: 'Triple R',
    cta: (n) => `Review & send ${n} follow-up${n === 1 ? '' : 's'}`, sentLabel: (n) => `${n} follow-ups sent to Triple R`,
    severity: 'critical', recheck: '72 h', phase: 'pre',
    template: {
      name: 'Trash-out status v3', to: 'Triple R Operations', toEmail: 'dispatch@triple-r.example', cc: 'Srini',
      subject: (n) => `Status request — trash-out for ${n} properties (15+ days)`,
      intro: 'The properties below have been in our portfolio for 15 days or more without a completed trash-out.',
      ask: 'Please confirm for each: has the debris been removed, has lawn service been done, and is the property safe to bring to market? Reply with an expected completion date where work is still open.',
    },
  },
  {
    key: 'novalue', title: 'No valuation received', threshold: '10+ days · warns at 5', owner: 'BPO vendor · Triple R',
    cta: (n) => `Request ${n} valuation${n === 1 ? '' : 's'}`, sentLabel: (n) => `${n} valuation requests sent`,
    severity: 'critical', recheck: '72 h', phase: 'pre',
    template: {
      name: 'Valuation outstanding v2', to: 'ValuePoint BPO', toEmail: 'orders@valuepoint.example', cc: 'Triple R Operations',
      subject: (n) => `Outstanding BPO — ${n} properties past 10 days`,
      intro: 'We have not yet received valuations for the properties below, which are now past our 10-day target.',
      ask: 'Please provide the status and an expected delivery date for each report today.',
    },
  },
  {
    key: 'investor', title: 'Investor response overdue', threshold: 'Pending 3+ days · daily follow-up', owner: 'Investors + management',
    cta: (n) => `Send ${n} investor reminder${n === 1 ? '' : 's'}`, sentLabel: (n) => `${n} investor reminders sent`,
    severity: 'critical', recheck: '24 h', phase: 'on',
    template: {
      name: 'Investor decision reminder v4', to: 'SPS Investor Team', toEmail: 'reo-approvals@sps.example', cc: 'REO Client Manager',
      subject: (n) => `Decision needed — ${n} outstanding requests`,
      intro: 'The requests below remain outstanding. Each package was complete at submission and includes current market analysis.',
      ask: 'Please review and respond today. Extended delays are increasing days on market and putting active buyer interest at risk.',
    },
  },
  {
    key: 'reduction', title: 'Price reduction due', threshold: '30+ days on market, no accepted offer', owner: 'Recommendation agent',
    cta: (n) => `Build ${n} reduction case${n === 1 ? '' : 's'}`, sentLabel: (n) => `${n} reduction requests prepared`,
    severity: 'serious', recheck: '14 d', phase: 'on',
    template: {
      name: 'List price reduction request v2', to: 'Investor approvers', toEmail: 'reo-approvals@sps.example', cc: 'REO Client Manager',
      subject: (n) => `Request for approval — list price reductions (${n} properties)`,
      intro: 'Based on current MSA conditions, property performance and investor guidelines, we recommend the reductions below.',
      ask: 'Supporting market analysis, Hubzu activity and comparable sales are attached for each property.',
    },
  },
  {
    key: 'eviction', title: 'Occupied — eviction follow-up', threshold: 'Not routed, or weekly check-in missed', owner: 'ESD · Pam’s team',
    cta: (n) => `Route ${n} file${n === 1 ? '' : 's'} to ESD`, sentLabel: (n) => `${n} files routed to ESD`,
    severity: 'critical', recheck: '7 d', phase: 'pre',
    template: {
      name: 'Eviction routing & check-in v1', to: 'ESD — Pam’s team', toEmail: 'esd-evictions@reo.example', cc: 'Srini',
      subject: (n) => `Eviction routing / status — ${n} occupied properties`,
      intro: 'The properties below are confirmed occupied and either have not been routed to eviction or are past their weekly check-in.',
      ask: 'Please confirm attorney engagement, latest inspection, and whether an updated value is needed for prolonged evictions.',
    },
  },
  {
    key: 'closing', title: 'Closings at risk', threshold: 'Past target date or title condition open', owner: 'Buyer agent · Title',
    cta: (n) => `Follow up on ${n} closing${n === 1 ? '' : 's'}`, sentLabel: (n) => `${n} closing follow-ups sent`,
    severity: 'serious', recheck: '24 h', phase: 'closing',
    template: {
      name: 'Closing delay follow-up v1', to: 'Title & buyer agents', toEmail: 'closings@title.example', cc: 'Closing team',
      subject: (n) => `Closing status needed — ${n} files past target`,
      intro: 'The closings below are delayed or blocked by an open condition.',
      ask: 'Please confirm the amended closing date, outstanding conditions and any per diem owed by the buyer.',
    },
  },
]
export const signalDef = (k: SignalKey) => SIGNALS.find((s) => s.key === k)!

// ---------- Market (MSA) ----------
export const MARKET = {
  msa: 'Phoenix–Mesa MSA',
  source: 'Sample market feed (provider not yet selected)',
  asOf: 'Nov 3, 5:00 AM',
  metrics: [
    { key: 'inv', label: 'For-sale inventory', value: '8,421', delta: '+12%', dir: 'up', bad: true, spark: [6.9, 7.0, 7.1, 7.0, 7.3, 7.4, 7.6, 7.5, 7.8, 8.0, 8.2, 8.42] },
    { key: 'fall', label: 'Contract fallout rate', value: '18%', delta: '+4 pts', dir: 'up', bad: true, spark: [13, 14, 13, 14, 15, 15, 14, 16, 16, 17, 17, 18] },
    { key: 'red', label: 'Listings with reductions', value: '37%', delta: '+9 pts', dir: 'up', bad: true, spark: [26, 27, 28, 28, 29, 31, 31, 32, 33, 34, 36, 37] },
    { key: 'dom', label: 'Median days on market', value: '58', delta: '+14 d', dir: 'up', bad: true, spark: [41, 42, 44, 43, 46, 48, 49, 51, 52, 55, 56, 58] },
    { key: 'stl', label: 'Sale-to-list ratio', value: '96.2%', delta: '−2.1 pts', dir: 'down', bad: true, spark: [98.4, 98.3, 98.1, 98.0, 97.8, 97.6, 97.3, 97.1, 96.9, 96.6, 96.4, 96.2] },
  ],
}

// ---------- Systems ----------
export const SYSTEMS = [
  { name: 'Equator', role: 'Tasks, property, investor data', status: 'ok', sync: '9:38 AM' },
  { name: 'Hubzu', role: 'Listings, bids, offers, analytics', status: 'ok', sync: '9:37 AM' },
  { name: 'Palladium / AFS', role: 'Preservation, re-secure status', status: 'ok', sync: '9:36 AM' },
  { name: 'Triple R report', role: 'Occupancy, trash-out milestones', status: 'warn', sync: '6:00 AM' },
  { name: 'ResWare', role: 'Title & closing (read-only)', status: 'ok', sync: '9:31 AM' },
  { name: 'SAMS', role: 'Valuations', status: 'ok', sync: '9:30 AM' },
  { name: 'DocuSign', role: 'Listing agreements, contracts', status: 'ok', sync: '9:33 AM' },
] as const

export const KEY_DATES = [
  { mon: 'NOV', day: 3, title: 'Investor decision expected', who: '2222 Cedar Ln, Orlando', tag: 'Follow up', tone: 'orange' },
  { mon: 'NOV', day: 5, title: 'Contract expiration', who: '7890 Spruce Dr, Tampa', tag: 'At risk', tone: 'red' },
  { mon: 'NOV', day: 7, title: 'Closing date', who: '1500 Palm Way, Las Vegas', tag: 'Track', tone: 'blue' },
  { mon: 'NOV', day: 10, title: 'Price review (30 DOM)', who: '9101 Pine Rd, Atlanta', tag: 'Prepare', tone: 'yellow' },
] as const

// ---------- Agents ----------
export const AGENTS = [
  { key: 'pre', name: 'Pre-Marketing Monitor', desc: 'Watches occupancy, initial services, trash-out and securing progress. Flags delays and drafts vendor follow-ups.', mode: 'Shadow', impact: 'Advances property', eligible: 48, exceptions: 12, blockers: 3, last: '8:15 AM', phase: 'pre' },
  { key: 'cmp', name: 'Complete Marketing Plan', desc: 'Drafts the marketing plan with list price, commissions and listing type from valuations and investor rules.', mode: 'Supervised', impact: 'Saves admin time', eligible: 72, exceptions: 8, blockers: 5, last: '7:48 AM', phase: 'pre' },
  { key: 'reserve', name: 'Set Reserve Price', desc: 'Recommends auction reserve from valuations, market data and investor rules, then prepares the approval package.', mode: 'Shadow', impact: 'Saves admin time', eligible: 64, exceptions: 6, blockers: 4, last: '6:32 AM', phase: 'on' },
  { key: 'rmp', name: 'Review Marketing Plan', desc: 'Runs the 2-week review cadence. Recommends price reductions or amendments using MSA and Hubzu analytics.', mode: 'Supervised', impact: 'Advances property', eligible: 58, exceptions: 14, blockers: 7, last: '9:02 AM', phase: 'on' },
  { key: 'offer', name: 'Offer Acceptance', desc: 'Compares offers on net-to-seller, financing and history. Drafts the acceptance or counter request for the investor.', mode: 'Supervised', impact: 'Advances property', eligible: 36, exceptions: 9, blockers: 3, last: '7:21 AM', phase: 'on' },
  { key: 'investor', name: 'Investor Approval', desc: 'Tracks investor submissions, drafts day-3 and daily follow-ups, and monitors response times.', mode: 'Shadow', impact: 'Advances property', eligible: 52, exceptions: 18, blockers: 12, last: '8:45 AM', phase: 'on' },
  { key: 'closing', name: 'Closing Monitor', desc: 'Tracks contract-to-close milestones, title conditions, documents and per diem. Highlights required actions.', mode: 'Supervised', impact: 'Advances property', eligible: 28, exceptions: 7, blockers: 6, last: '9:02 AM', phase: 'closing' },
] as const

export const AI_RECS = [
  { id: 'R1', propertyId: 'P001', title: 'List price reduction ready', conf: 87, kind: 'price' },
  { id: 'R2', propertyId: 'P005', title: 'Multiple-offer analysis (H&B)', conf: 81, kind: 'offer' },
  { id: 'R3', propertyId: 'P004', title: 'Investor follow-up drafted', conf: 94, kind: 'mail' },
  { id: 'R4', propertyId: 'P003', title: 'Reduction case started', conf: 76, kind: 'price' },
  { id: 'R5', propertyId: 'P002', title: 'Pre-marketing checklist gaps', conf: 90, kind: 'check' },
] as const

// Portfolio-wide scope (all AMs) for the scope switch
export const ALL_SCOPE = { total: 2759, exceptions: 412, actions: 168, approvals: 121, avgDom: 63, closed: 1, ams: 14 }

// Aging buckets per phase for the Portfolio skyline
export const AGING_BUCKETS = ['0–15 d', '16–30 d', '31–60 d', '61–90 d', '90+ d']
export const AGING: Record<Exclude<Phase, 'sold'>, number[]> = {
  pre: [31, 27, 18, 8, 4],
  on: [12, 19, 26, 14, 8],
  contract: [9, 11, 7, 3, 1],
  closing: [5, 6, 4, 1, 1],
}
