import type { Property } from './mock'

export const AM_AUTHORITY = 0.05 // AM may approve reductions up to 5.0%
export const INVESTOR_CAP = 0.08 // SPS example rule: max 8% per 28 days
export const RULE_VERSION = 'SPS-LPR-2.3'

/** Price chosen on the Recommendation screen, handed to the Approval Package. */
export const pendingPrice = new Map<string, number>()

export function recFor(p: Property) {
  const n = parseInt(p.id.slice(1), 10)
  const current = p.listPrice ?? 300000
  const pct = p.id === 'P001' ? 0.0612 : 0.042 + ((n * 37) % 36) / 1000
  const recommended = Math.round((current * (1 - pct)) / 1000) * 1000
  return {
    current,
    recommended,
    conf: p.id === 'P001' ? 87 : 72 + ((n * 13) % 20),
    msaMedian: Math.round((current * 0.894) / 1000) * 1000,
    firstList: (() => {
      const d = new Date(2026, 10, 3)
      d.setDate(d.getDate() - (p.dom ?? 30))
      return d.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })
    })(),
  }
}

export type Tier = 'am' | 'investor' | 'exception'
export function tierFor(pct: number): Tier {
  if (pct <= AM_AUTHORITY + 1e-9) return 'am'
  if (pct <= INVESTOR_CAP + 1e-9) return 'investor'
  return 'exception'
}

export function routeFor(t: Tier, investor: string) {
  const base = ['Asset Manager (you)']
  if (t === 'am') return [...base, 'Write to Equator', 'Hubzu listing update']
  if (t === 'investor') return [...base, `Investor approval (${investor})`, 'Write to Equator', 'Hubzu listing update']
  return [...base, 'Management exception', `Investor approval (${investor})`, 'Write to Equator', 'Hubzu listing update']
}
