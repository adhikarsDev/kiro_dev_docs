// Market-aware evidence for Recommendation Agents.
// All market values below are SAMPLE data: the market/MSA provider is not yet selected (see DATA_INPUTS).
import type { Property } from './mock'
import { money } from './mock'
import { recFor } from './rec'

export type GeoKey = 'zip' | 'msa' | 'state'
export type Segment = 'all' | 'reo'
export type Period = '30d' | '90d'
export type Read = 'supports' | 'contrary' | 'neutral'
export type Availability = 'available' | 'partial' | 'sourcing'
export type DecisionType = 'list' | 'reserve' | 'plan' | 'contract'

export const DECISIONS: Record<DecisionType, { title: string; short: string; agent: string; action: string }> = {
  list: { title: 'List Price Reduction', short: 'List price reduction', agent: 'Review Marketing Plan agent', action: 'reduce the list price' },
  reserve: { title: 'Reserve Price Reduction', short: 'Reserve price reduction', agent: 'Set Reserve Price agent', action: 'reduce the auction reserve' },
  plan: { title: 'Marketing Plan Amendment', short: 'Marketing plan amendment', agent: 'Review Marketing Plan agent', action: 'amend the marketing plan' },
  contract: { title: 'Buyer Contract Approval', short: 'Buyer contract approval', agent: 'Offer Acceptance agent', action: 'approve the buyer contract' },
}

export interface MarketRow { inventory: number; invDelta: number; fallout: number; falloutDelta: number; redCount: number; redPct: number; redDelta: number; stlPct: number; stlUsd: number; stlDelta: number; dom: number; domDelta: number; n: number }

// Per geography × segment × period. n = closed sales in the comparison window.
const M: Record<GeoKey, Record<Segment, Record<Period, MarketRow>>> = {
  zip: {
    all: { '30d': { inventory: 64, invDelta: 18, fallout: 21, falloutDelta: 6, redCount: 27, redPct: 42, redDelta: 11, stlPct: 95.4, stlUsd: -18200, stlDelta: -2.6, dom: 61, domDelta: 16, n: 9 },
           '90d': { inventory: 61, invDelta: 11, fallout: 19, falloutDelta: 4, redCount: 70, redPct: 39, redDelta: 8, stlPct: 95.9, stlUsd: -16100, stlDelta: -1.9, dom: 57, domDelta: 12, n: 26 } },
    reo: { '30d': { inventory: 5, invDelta: 25, fallout: 25, falloutDelta: 8, redCount: 3, redPct: 60, redDelta: 15, stlPct: 93.1, stlUsd: -21400, stlDelta: -3.0, dom: 70, domDelta: 18, n: 2 },
           '90d': { inventory: 5, invDelta: 20, fallout: 24, falloutDelta: 7, redCount: 7, redPct: 55, redDelta: 12, stlPct: 93.8, stlUsd: -19900, stlDelta: -2.4, dom: 66, domDelta: 14, n: 5 } },
  },
  msa: {
    all: { '30d': { inventory: 8421, invDelta: 12, fallout: 18, falloutDelta: 4, redCount: 3116, redPct: 37, redDelta: 9, stlPct: 96.2, stlUsd: -14600, stlDelta: -2.1, dom: 58, domDelta: 14, n: 1240 },
           '90d': { inventory: 8105, invDelta: 9, fallout: 17, falloutDelta: 3, redCount: 8930, redPct: 35, redDelta: 7, stlPct: 96.6, stlUsd: -13100, stlDelta: -1.6, dom: 54, domDelta: 10, n: 3610 } },
    reo: { '30d': { inventory: 412, invDelta: 9, fallout: 22, falloutDelta: 5, redCount: 171, redPct: 41, redDelta: 7, stlPct: 94.8, stlUsd: -16900, stlDelta: -2.4, dom: 66, domDelta: 11, n: 38 },
           '90d': { inventory: 398, invDelta: 7, fallout: 21, falloutDelta: 4, redCount: 470, redPct: 39, redDelta: 6, stlPct: 95.2, stlUsd: -15800, stlDelta: -1.9, dom: 63, domDelta: 9, n: 112 } },
  },
  state: {
    all: { '30d': { inventory: 21950, invDelta: 8, fallout: 16, falloutDelta: 3, redCount: 7463, redPct: 34, redDelta: 6, stlPct: 96.9, stlUsd: -11200, stlDelta: -1.4, dom: 51, domDelta: 9, n: 4020 },
           '90d': { inventory: 21480, invDelta: 6, fallout: 15, falloutDelta: 2, redCount: 21100, redPct: 33, redDelta: 5, stlPct: 97.1, stlUsd: -10400, stlDelta: -1.1, dom: 49, domDelta: 7, n: 11870 } },
    reo: { '30d': { inventory: 1105, invDelta: 7, fallout: 20, falloutDelta: 4, redCount: 431, redPct: 39, redDelta: 6, stlPct: 95.3, stlUsd: -14800, stlDelta: -1.9, dom: 61, domDelta: 8, n: 141 },
           '90d': { inventory: 1080, invDelta: 5, fallout: 19, falloutDelta: 3, redCount: 1210, redPct: 37, redDelta: 5, stlPct: 95.7, stlUsd: -14100, stlDelta: -1.5, dom: 59, domDelta: 6, n: 402 } },
  },
}

export const MIN_SAMPLE = 30 // below this, the agent falls back to the next-wider geography

export function geoLabel(g: GeoKey, p: Property) {
  return g === 'zip' ? `ZIP ${p.zip}` : g === 'msa' ? `${p.msa} MSA` : p.state === 'AZ' ? 'Arizona' : p.state
}

/** Most relevant geography with enough sample, ZIP → MSA → State, disclosed to the user. */
export function resolveGeo(seg: Segment, period: Period): { geo: GeoKey; skipped: { geo: GeoKey; n: number }[] } {
  const order: GeoKey[] = ['zip', 'msa', 'state']
  const skipped: { geo: GeoKey; n: number }[] = []
  for (const g of order) {
    const n = M[g][seg][period].n
    if (n >= MIN_SAMPLE) return { geo: g, skipped }
    skipped.push({ geo: g, n })
  }
  return { geo: 'state', skipped }
}

export const marketRow = (g: GeoKey, seg: Segment, period: Period) => M[g][seg][period]

export interface Signal {
  key: string
  label: string
  value: string
  detail: string
  read: Read
  weight: number // 0..1 influence on the conclusion
  why: string
  availability: Availability
}

const k = (n: number) => n.toLocaleString('en-US')
const pts = (n: number) => `${n > 0 ? '+' : ''}${n} pts`

/** Market + property signals for a decision, each tagged with how it reads for THIS action. */
export function evidenceFor(type: DecisionType, p: Property, g: GeoKey, seg: Segment, period: Period) {
  const m = marketRow(g, seg, period)
  const rec = recFor(p)
  const dom = p.dom ?? 42
  const similarDom = Math.round(m.dom * 0.52) // similar listings: same geography, price band ±15%
  const similarBidders = 5
  const list = p.listPrice ?? rec.current
  const offerGap = p.prevHighOffer ? (list - p.prevHighOffer) / list : 0.1
  const lower = type !== 'contract' // reductions/amendments argue for meeting the market; a contract approval argues for locking a deal
  const per = period === '30d' ? 'vs prior 30 days' : 'vs prior 90 days'

  const market: Signal[] = [
    { key: 'inv', label: 'For-sale inventory', value: k(m.inventory), detail: `${m.invDelta > 0 ? '+' : ''}${m.invDelta}% ${per}`, read: m.invDelta > 3 ? 'supports' : 'neutral', weight: 0.7,
      why: lower ? 'More competing listings means buyers have options; pricing must stay sharp.' : 'Rising supply makes a firm buyer more valuable today.', availability: 'sourcing' },
    { key: 'fall', label: 'Contract fallout rate', value: `${m.fallout}%`, detail: `${pts(m.falloutDelta)} ${per}`, read: m.falloutDelta > 1 ? 'supports' : 'neutral', weight: type === 'contract' ? 0.85 : 0.45,
      why: type === 'contract' ? 'Fallout is rising; a qualified, approved buyer reduces re-marketing risk.' : 'More deals are failing, which signals buyer hesitancy at current prices.', availability: 'sourcing' },
    { key: 'red', label: 'Listings with price reductions', value: `${k(m.redCount)} · ${m.redPct}%`, detail: `${pts(m.redDelta)} ${per}`, read: m.redPct > 30 ? 'supports' : 'neutral', weight: lower ? 0.9 : 0.4,
      why: lower ? `${m.redPct}% of comparable listings have already cut price; the market is resetting.` : 'Widespread cuts mean holding out for list is unlikely to pay off.', availability: 'sourcing' },
    { key: 'stl', label: 'Sale price vs list price', value: `${m.stlPct}% · ${money(m.stlUsd, { compact: true })}`, detail: `${pts(m.stlDelta)} ${per}`, read: m.stlDelta < 0 ? 'supports' : 'contrary', weight: 0.75,
      why: type === 'contract' ? `Homes are selling at ${m.stlPct}% of list on average; this contract is in line with the market.` : `Buyers are paying ${Math.abs(m.stlUsd).toLocaleString('en-US', { style: 'currency', currency: 'USD', maximumFractionDigits: 0 })} below list on average.`, availability: 'partial' },
    { key: 'dom', label: 'Median days on market', value: `${m.dom} days`, detail: `${m.domDelta > 0 ? '+' : ''}${m.domDelta} days ${per}`, read: m.domDelta > 5 ? 'supports' : 'neutral', weight: 0.55,
      why: 'Homes are taking longer to sell; waiting adds holding cost without improving price.', availability: 'sourcing' },
  ]

  const reserve = Math.round((list * 0.92) / 1000) * 1000
  const highestBid = Math.round((reserve * 0.925) / 500) * 500
  const property: Signal[] = [
    { key: 'first', label: 'First list date', value: rec.firstList, detail: `${dom} days ago`, read: 'neutral', weight: 0.2, why: 'Anchors days on market; relists keep the original date.', availability: 'available' },
    { key: 'dom', label: 'Days on market', value: `${dom} days`, detail: `similar listings: ${similarDom} days`, read: dom > similarDom ? 'supports' : 'contrary', weight: 0.65,
      why: dom > similarDom ? `On market ${dom - similarDom} days longer than similar listings.` : 'Selling pace is in line with similar listings.', availability: 'available' },
    { key: 'bidders', label: 'Number of bidders', value: `${p.bidders || 3}`, detail: `similar listings: ${similarBidders}`, read: (p.bidders || 3) < similarBidders ? 'supports' : 'contrary', weight: 0.6,
      why: (p.bidders || 3) < similarBidders ? 'Fewer bidders than comparable properties at this price.' : 'Bidder interest is healthy.', availability: 'available' },
    { key: 'bids', label: 'Number of bids', value: `${p.bids || 5}`, detail: type === 'reserve' ? `highest ${money(highestBid, { compact: true })} vs reserve ${money(reserve, { compact: true })}` : 'no new bids in 21 days', read: 'supports', weight: type === 'reserve' ? 0.85 : 0.5,
      why: type === 'reserve' ? 'Bids are clustering below the reserve; the auction will not clear at the current reserve.' : 'Bid activity has stalled.', availability: 'available' },
    { key: 'offer', label: 'Previous highest offer', value: money(p.prevHighOffer ?? Math.round(list * 0.9)), detail: `${(offerGap * 100).toFixed(1)}% below list`, read: 'supports', weight: 0.7,
      why: type === 'contract' ? 'This contract matches or beats every offer received to date.' : 'The best real-world bid sits well under the list price; buyers are telling us the price.', availability: 'available' },
  ]
  // The valuation is the classic contrary signal: it may support a higher price.
  const valuation: Signal = {
    key: 'val', label: 'Current valuation (BPO)', value: money(p.valuation ?? rec.current), detail: 'BPO is 21 days old', read: 'contrary', weight: 0.55,
    why: 'The valuation supports a higher price, but it predates the latest market shift and the property\'s weak bidding.', availability: 'available',
  }
  const all = [...market, ...property, valuation]
  const score = all.reduce((a, s) => a + (s.read === 'supports' ? s.weight : s.read === 'contrary' ? -s.weight : 0), 0) / all.reduce((a, s) => a + s.weight, 0)
  const verdict = score > 0.35 ? 'supported' : score > 0 ? 'partial' : 'not'
  const ranked = [...all].filter((s) => s.read !== 'neutral').sort((a, b) => b.weight - a.weight)
  return { market, property, valuation, verdict: verdict as 'supported' | 'partial' | 'not', score, ranked, supportCount: all.filter((s) => s.read === 'supports').length, total: all.length, m }
}

/** Data inputs the agents rely on, and whether we have them today. */
export const DATA_INPUTS: { group: 'Market' | 'Property' | 'Context'; input: string; status: Availability; source: string; note: string }[] = [
  { group: 'Market', input: 'For-sale inventory', status: 'sourcing', source: 'Market / MSA data provider (not selected)', note: 'Needs ZIP + MSA, weekly refresh, licensed for automated decision support' },
  { group: 'Market', input: 'Contract fallout rate', status: 'sourcing', source: 'Market / MSA data provider', note: 'Pending-to-cancelled ratio by geography and period' },
  { group: 'Market', input: 'Listings with price reductions (count & %)', status: 'sourcing', source: 'Market provider or MLS aggregates', note: 'MLS access and licensing not yet confirmed' },
  { group: 'Market', input: 'Sale price vs list price (% and $)', status: 'partial', source: 'Own REO closings in Equator; market-wide needs provider/MLS', note: 'Internal closings give an REO benchmark today' },
  { group: 'Market', input: 'Market days on market', status: 'sourcing', source: 'Market / MSA data provider', note: 'Median and trend by geography' },
  { group: 'Market', input: 'REO-segment market trends', status: 'sourcing', source: 'Provider with REO flag, or derived from portfolio history', note: 'Few providers flag REO; samples are small' },
  { group: 'Property', input: 'First list date', status: 'available', source: 'Equator / Hubzu', note: 'Validate treatment of relists and fallen contracts' },
  { group: 'Property', input: 'Number of bidders', status: 'available', source: 'Hubzu bid instances', note: 'Confirm canonical aggregation per submitter' },
  { group: 'Property', input: 'Number of bids', status: 'available', source: 'Hubzu / Equator', note: 'Decide how backup and held bids count' },
  { group: 'Property', input: 'Days on market', status: 'available', source: 'Derived from first list date', note: 'Same relist rule as first list date' },
  { group: 'Property', input: 'Previous highest offer', status: 'available', source: 'Equator offers / Hubzu', note: 'Latest bid instance per submitter' },
  { group: 'Property', input: 'Hubzu views, watchers & showings', status: 'partial', source: 'Hubzu analytics', note: 'API coverage needs validation' },
  { group: 'Context', input: 'Valuations (BPO, appraisal)', status: 'available', source: 'Equator / SAMS', note: 'Authoritative SPS source to confirm' },
  { group: 'Context', input: 'Investor rules & delegated authority', status: 'available', source: 'Versioned investor rulebook', note: 'Rule changes can block impacted agents until approved' },
]
