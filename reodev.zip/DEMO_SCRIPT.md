# REO Control Tower · Home Page Demo Script

**Audience:** Leadership, Asset Management (Mason and team), product and engineering
**Length:** about 25 minutes plus Q&A (headline 3 · home page 17 · left menu 5)
**Persona:** Srini, an asset manager with a 236-file book, starting the day on **Tuesday, November 3**
**Where the asks come from:** the Nov 4 meeting notes (`recommendations.txt`: System Purpose, Asset Manager Workflow, Resolution Workflows, MVP Scope) and the exception catalog (`exceptions .docx`)

How to read this script: **Show** is what you click. **Say** is what you say. Each home page section also has **What it is** and **Why it's there**, so you can answer "why did you add this?"

---

## 0. Before you start

**One-time setup**
1. Install **Node.js 22 LTS** (or 20.19+). Check with `node -v`.
2. In the project folder, run:
   ```bash
   npm install
   ```

**Start the demo**
```bash
npm run dev
```
Open **http://localhost:5180** in Chrome.

**Presenter tips**
- Chrome, full screen, window **at least 1440 px wide**, **light mode**.
- **Reload the page to reset all demo data.** Everything is in memory, so a reload undoes every approval. Do one dry run, then reload before you present.
- Don't click **All · 2,759** in the header. It's a label until the asset-manager view is built (see section 7).

---

## 1. The headline: what Mason asked for, and what the home page does

**Show:** Today, untouched. Leave it on screen while you talk.

**Say:**
> "Mason set the bar in our meeting. If Control Tower only reports exceptions, it's barely better than Equator, which already lists the outstanding tasks. It has to **understand each problem, recommend the resolution, and let the asset manager resolve it with one click.** That's how an AM handles **70% more files** and moves them **70% faster**. The home page is built around exactly that. Here's how each ask maps to what you'll see."

| # | What Mason and the group asked for | What the home page does | Status |
|---|---|---|---|
| 1 | Structure the home page in three steps: the day's exceptions, a recommended resolution for each, and an action button to execute it | Every exception row shows the problem, the recommended resolution and one action button, such as *Send nudge*, *Review reduction* or *Send follow-up* | Built |
| 2 | A linear flow: show the exception, present the recommendation, approve with a button that clears the item | The review drawer walks **Exception → Recommended resolution → Action**. *Approve & send* clears the row, with Undo | Built |
| 3 | Clear 90%+ of items in the first hour; exceptions plus advancement files in about an hour and a half | The **first-hour goal ring** has a tick at 90%. The hero says how long the top 15 take (about 60 minutes) | Built (the target shows today; it isn't tracked over weeks yet) |
| 4 | Bulk: scan similar items and send them all at once, but still review unusual cases individually | Tick rows → **Review & approve N**. Untick anything unusual. *By type* groups items that share a template | Built |
| 5 | Show both administrative exceptions and advancement tasks, like moving a file forward when a BPO arrives | Every row is tagged **Saves admin time** or **Moves file forward**, and a separate **Ready to advance** section holds the advancement decisions | Built |
| 6 | A professional report combining the property's exception details with market data and graphics, which the AM reviews, approves and sends | The drawer drafts the message from the catalog template and adds a **market summary card**: median sale price, days to sell, sale-to-list and a 12-month trend | Built (sample market data) |
| 7 | Market data as concise bullet points; the AM picks the ones that support the narrative; the summary is generated from only those | The **market picker** pre-ticks points that support the request and shows points that cut against it unticked. *Generate summary* uses only the ticked points | Built (sample market data) |
| 8 | Publicly available market trends, such as year-over-year value change and days on market (for example from Redfin) | "Public ZIP trend" bullets in the picker | Partial: sample values; live retrieval not connected |
| 9 | Not every exception needs a report: when a vendor hasn't delivered a value, send a simple follow-up asking for it | Valuation exceptions use a short vendor follow-up with no market report | Built |
| 10 | Investor and vendor nudges visible in one centralized work queue | **Follow-ups and offers** leads to Investor follow-ups and Awaiting response. Anything without a reply by its date returns to Exceptions on its own | Built |
| 11 | Finish tasks like *set reserve price* inside Control Tower, even when Equator says fields are missing (Jesse) | **Equator task to complete** in Ready to advance: fill the missing fields in the drawer, then *Complete in Control Tower* | Built (Equator write-back simulated) |
| 12 | View the full portfolio, one asset manager's portfolio, or a client's, such as FirstKey (Jesse) | The **client filter** in the header scopes the whole home page | Partial: client view built; asset-manager view parked |
| 13 | Show what still needs doing, not how the agents work; remove the agent section | The agent section is gone from the home page. Each recommendation just names the agent that prepared it | Built |
| 14 | An opening screen that's easy to understand and immediately actionable, not a large volume of data (Bill) | One greeting, one sentence, one ring, then the work. No KPI wall | Built |
| 15 | Property journey view: defer until after the MVP | Not on the home page | Deferred, as agreed |

**Say:**
> "Twelve of the fifteen are in place. Two are partial because they need real data sources: live market data and the asset-manager view. One we agreed to defer. Let me show you the page top to bottom."

---

## 2. Run of show

| Time | Segment | Section |
|---|---|---|
| 0:00 | The headline | 1 |
| 0:03 | Header, greeting, first-hour ring, stage cards | 3.1–3.4 |
| 0:07 | Act today | 3.5 |
| 0:09 | Exceptions and the review drawer, single and bulk | 3.6–3.7 |
| 0:16 | Ready to advance, including the Equator task | 3.8 |
| 0:19 | Follow-ups and offers, and the "comes back if no reply" loop | 3.9 |
| 0:21 | Left menu tour | 4 |
| 0:25 | Close, then Q&A | 5, 8 |

---

## 3. The home page, section by section

### 3.1 Header bar (on every page)

**What it is:** search (⌘K) across properties, loan numbers and actions; the **client filter** (All clients, SPS, FirstKey, Onity/PHH, Calibr, NRZ/Newrez); a refresh button; light and dark mode; and the profile menu, which also holds notifications (the red badge).

**Why it's there:** Jesse asked for client-specific views such as FirstKey. Search replaces hunting through Equator screens. Notifications sit inside the profile menu so the header stays calm.

**Show:** Pick **FirstKey** in the client filter. The sentence, the ring, the stage cards, the exceptions and the sidebar badges all change (7 exceptions, 1 decision). Switch back to **All clients**.

**Say:**
> "One filter scopes the whole page. If Srini spends her morning on FirstKey, everything she sees is FirstKey: the work, the counts and the progress."

---

### 3.2 Greeting and one-line summary

**What it is:** "Good morning, Srini", then one sentence: *"42 exceptions and 13 decisions are waiting. Every one has a recommended resolution ready. The top 15 take about 60 minutes."* Two buttons: **Start with the top 15** and **Open My Work**.

**Why it's there:** Bill asked for an opening screen that is easy to understand and immediately actionable. This replaces the old KPI wall (30,047 exceptions, tiles showing "N/A") with the three facts an AM needs: how much is waiting, that it already has answers, and how long it will take. The time estimate speaks to Mason's first-hour goal.

**Say:**
> "In five seconds she knows her morning: 42 problems, 13 decisions, each with an answer already prepared, and about an hour of work."

---

### 3.3 First-hour goal ring

**What it is:** one ring showing the share of the work open at the start of the day that's been cleared since. Today that's **58 items**: 42 exceptions, 13 decisions and 3 investor-approved offers. A tick marks the **90%** target, and the line beside it says *"N more to reach 90%"*.

**Why it's there:** Mason's goal is for AMs to clear more than 90% of these items in the first hour and spend the rest of the day on the files that need real thinking. The ring makes that goal visible and counts real progress only. It follows the client filter, Undo moves it back, and it resets each business day. It replaced three decorative rings that started with made-up numbers.

**Say:**
> "This is Mason's first-hour goal. The tick is 90%. Watch it move as we work."

---

### 3.4 Stage cards

**What it is:** ten cards, Intake to Closing. The big number is files in that stage. **"exc"** is files with an open exception; **"ready"** is decisions ready to advance. A stage with nothing to act on, like Intake today, is greyed out and says *No action*.

**Why it's there:** it answers "where is my book stuck?" at a glance, and it's a shortcut to that stage's work. If evictions are the problem today (Eviction: 10 exceptions), one click shows only those.

**Show:** Click **Valuation**. The page scrolls down. Exceptions shows **2** and Ready to advance shows **4**, each with a **Valuation ✕** chip. Click the chip to clear it. Point at **Intake**: greyed out, *No action*.

**Say:**
> "Each card filters both work lists and takes her straight there. Cards with nothing to act on are greyed out, so she never clicks into an empty list."

---

### 3.5 Act today

**What it is:** investor approvals already in hand, each with one button:
- **7890 Spruce Dr, Tampa:** SPS approved acceptance at $214,000 → *Accept & send contract*
- **3677 Sunset Blvd, Columbus:** Onity/PHH approved a counter at $312,500 → *Send counter offer*
- **8973 Ash St, Austin:** Onity/PHH approved acceptance at $189,900 → *Accept & send contract*

**Why it's there:** an approval in hand is the fastest file to move and the most expensive to forget. The operating model says approved accepts and counters are top priority, so they sit above the exceptions.

**Show:** Click **Accept & send contract** on 7890 Spruce Dr. The confirm sheet shows the change and what will happen: re-check the facts, accept the offer in Equator, send the purchase contract through DocuSign, open closing tasks and order title in ResWare. Click **Accept & send contract**. The row slides out, a toast offers **Undo**, and the ring moves.

**Say:**
> "Nothing happens without her confirmation, and she sees exactly what will run before it runs. One click moved a file into contract."

---

### 3.6 Exceptions: the core of the page

**What it is:** her **top 15 of 42** exceptions, most severe first. Each row has five parts:
1. **Exception:** the type and what's wrong, for example *Investor follow-up due · Requested −4.0% · sent 16 BD ago*
2. **Property:** address, client and stage
3. **Over SLA:** business days past the catalog rule, marked Critical or Warning
4. **Recommended resolution:** the fix, tagged *Saves admin time* or *Moves file forward*, plus the agent that prepared it
5. **Action button:** the verb, such as *Send nudge*, *Review offer* or *Review reduction*

Controls: **Top 15 / By type / All**, **Sort** (Severity or Most days over), a checkbox on every row for bulk, and **Show all 42** at the bottom.

**Why it's there:** this is Mason's three steps, row by row. The rules come from the exception catalog (19 types in the POC), for example:
- Initial trash-out incomplete: 15 BD from initiation, then every 2 BD
- Initial valuation incomplete: 7 BD from order
- Investor follow-up: 2 BD from submission, then daily, with REO management copied
- Reduction needed: 25 days since the last price change
- Delayed closing review: 3 BD after HUD approval
- Delayed initial occupancy: 2 BD from order

Showing the top 15 keeps the first hour realistic. *By type* groups items that share an email template, which is where bulk saves the most time.

**Show:** Point at row 1: **2222 Cedar Ln**, *Investor follow-up due*, **+14 BD**, *Send nudge*. Click **By type** to show the catalog tiles, then go back to **Top 15**.

**Say:**
> "Every row answers three questions: what's wrong, what should we do, and what's the button. Equator would show this as an overdue task. Control Tower shows it with the answer attached."

---

### 3.7 The review drawer: recommended resolution → action

**Show:** Click the row **Delayed initial listing · 1013 Westland Pl, Tampa (Calibr)**. The drawer slides in from the right. Walk it top to bottom:

1. **Header pills:** *Critical*, the agent (*Complete Marketing Plan Agent*), *Moves file forward*, and **"You approve before anything is sent."**
2. **Three-step strip:** Exception → Recommended resolution → Action. This is Mason's linear flow, written out.
3. **Recommendation:** *Request initial list approval at $345,000*, with the facts behind it, the guideline ID (GL-LST-01), **88% confidence**, *Evidence 4 of 4*, and the list price, which she can edit.
4. **Market picker:** 14 points in three groups (Public ZIP trend, MSA market, Property). The six that support the request are ticked. Points that cut against it, like the valuation, are shown unticked.
5. **Message:** To *Calibr approvals*, Cc, Subject and body, from template *INV-INITLIST-01*. All editable.
6. **Agent pre-work:** the evidence the agent gathered, collapsed by default.
7. **Footer:** **Approve & send to Calibr** · **Snooze** (1 BD, 2 BD, next week) · **Open property** · **Reject**

**Why it's there:** each part answers a specific ask. The strip is Mason's linear flow. The picker and summary card are his "pick the bullets that support the narrative, then generate the summary". The message is the professional report the AM reviews and sends. The footer keeps her in control: approve, defer, dig in or reject.

**Show:** Untick one market point. Click **Generate summary from N points**. The summary card appears and the text drops into the email. Click **Approve & send to Calibr**. The row leaves, a toast offers Undo, and the ring moves.

**Say:**
> "She didn't gather data or write an email. She checked the agent's work, chose the market points she wanted the investor to see, and approved. That's minutes instead of the forty it used to take."

**Bulk (Mason: "scan the items and send all at once"):**

**Show:** Tick the three investor follow-up rows (2222 Cedar Ln, 8302 Granite Ridge, 4892 Pine Rd). A bar rises from the bottom: **Review & approve 3**. The drawer lists each item with its recipient. Untick one to show that unusual cases can be reviewed on their own, tick it back, then click **Approve & send 3**.

**Say:**
> "Same problem, same template, one approval. Anything unusual she unticks and opens on its own."

**Simple follow-up (Mason: "a simple email asking for the missing value"):**

**Show (optional):** Open **Initial valuation incomplete · 6092 Spruce Dr**. The message is a short note to the BPO vendor, with no market report.

**Say:**
> "Not every exception needs a report. A missing value gets a two-line follow-up."

**Market-backed reduction (optional):**

**Show:** Open **Reduction needed · 8761 Redbud Ln, Birmingham**. The recommendation reads *Reduce 8% from $453,000 to $416,800*, with the market picker and **Approve & send to SPS**.

---

### 3.8 Ready to advance

**What it is:** **13 decisions** that aren't problems. They move files forward or take admin off her plate.
- **Moves file forward:** Marketing plan ready (2), Reduction case ready (2), Offer recommendation ready (1), Ready to list (1), Values ready to agree (2), Equator task to complete (1)
- **Saves admin time:** Triple R bid to approve (2), Closing review (1), Occupancy result in: route the file (1)

Groups with more than one item have **Review all N**.

**Why it's there:** the group agreed the home page must show advancement tasks as well as exceptions, such as moving a file forward when its BPO arrives. Together with the exceptions, these make up Mason's "hour and a half at the start of the day". *Equator task to complete* exists because Jesse couldn't finish *set reserve price*: Equator said required fields were missing and sent him back to the client system.

**Show:** Open **Equator task to complete · 5043 Westland Pl**. The drawer shows the two missing fields, already filled in by the agent: *Reserve justification* and *Next auction cycle start*. Click **Complete in Control Tower**. Then on **Values ready to agree**, click **Review all 2** and approve both.

**Say:**
> "This is the task Jesse got stuck on. Equator said fields were missing. Here she fills them in and finishes the task without leaving Control Tower."

---

### 3.9 Follow-ups and offers

**What it is:** three cards:
- **Awaiting response:** 14 items waiting on vendors, brokers, title or field teams
- **Investor follow-ups:** 12 requests, 5 nudges due today
- **Live offers:** 9 offers

Each card opens its own page.

**Why it's there:** Mason asked for investor and vendor nudges in one centralized work queue. Everything Srini sends is tracked, and anything without a reply by its date comes back to Exceptions automatically. Nothing gets lost in an inbox.

**Show the loop:** Click **Awaiting response**. The follow-ups she approved are listed with what was sent, to whom, the expected reply date and a countdown. Click **Simulate next business day** two or three times. A toast says how many items came back. Go back to **Today** and click **All**: they're back in Exceptions, with "nothing received" in the detail.

**Say:**
> "She doesn't need to remember who owes her what. When a reply is late, it comes back to her list on its own."

---

### 3.10 What we took off the home page, and why

| Removed | Why | Where it lives now |
|---|---|---|
| The agent section | Mason and Richard agreed AMs need to see the remaining work, not how agents work | AI Agents page |
| "Your book" chart | Bill: no large volume of data on the opening screen | Portfolio page |
| AI recommendations and Market pulse cards | They were reading, not doing | Recommendations page, plus the market picker in the drawer |
| Date row, "Step 1/2/3" labels, stats lines | Clutter | — |
| Three activity rings with made-up starting numbers | Low value; ignored the client filter | One first-hour goal ring |
| Property journey view | Agreed as not urgent for the MVP | Deferred |

---

## 4. The left menu: what each item is for

**Say:**
> "The menu follows an AM's day: do the work, find a file, track what's in motion, make the bigger decisions, then look back. Badges show what's waiting."

| Menu item | What it is | How it helps the asset manager |
|---|---|---|
| **Today** | The command center you've just seen | Starts the day with the work, the answers and one-click actions |
| **My Work** (badge 42) | The full queue in four tabs: Exceptions 42 · Actions Ready 16 · Approvals Waiting 7 · Watchlist 14 | Everything beyond the top 15, and the place to dig into the two or three problem files a day that need real attention |
| **Properties** | All 215 active files, with stage cards, an occupancy filter and status chips; opens the Property Cockpit | Find any file and see where it's stuck, who owns the next step and what's due |
| **Offers** | Every live offer: approved and ready to execute (3), needs a decision (3), with the investor (3) | Offers are the most time-sensitive decisions; each shows % of list, % of reserve and the agent's recommendation |
| **Investor follow-ups** (badge 5) | Every request waiting on an investor, with its nudge schedule | Mason's centralized nudge queue: today's nudges in one approval, and responses logged in one place |
| **Awaiting response** | Everything sent to vendors and partners, with a countdown | Nothing is forgotten: late replies return to Exceptions automatically |
| **Recommendations** | Market-aware recommendations for list price, reserve, marketing plan and buyer contract decisions | The deeper pricing and offer decisions, with the evidence leadership asked for |
| **AI Agents** | The automation team: what each agent does, its mode, workload and time saved | Kept off the home page; gives leads, product and data teams visibility and trust |
| **Portfolio** | Your book by phase, 3D aging, velocity and metric definitions | Trends for weekly reviews and managers, kept off the home page so Today stays about the work |

Use the beats below for a short tour (about 30 seconds each). Skip any that you're short on time for.

### 4.1 My Work

**Show:** Click **My Work**. Point at the four tabs and their counts. Type "Cedar" in search (press **/** to jump there), then clear it. Tick two rows and the bulk bar rises (follow-up, snooze, reassign). Click a row: the **Action Center** panel opens beside the list, showing why the file needs attention, the SLA, each source system's status, history, missing data and the next step. Use **↑ / ↓** to move between items and **Esc** to close.

**Say:**
> "Today shows the top of the pile. My Work is the whole pile, sorted by urgency. The ⓘ explains the ranking, so there are no hidden scores. It's where she works the files that need more than one click."

### 4.2 Properties and the Property Cockpit

**Show:** Click **Properties**. Point at the stage cards, the occupancy filter and the status chips (Overdue 42 · Action today 3 · Ready 13 · Check-in due 3 · Waiting 18 · On track 136). Click **1234 Maple Grove Dr** to open the cockpit: the 3D house, the lifecycle with dates, the checklist, open tasks, the recommendation, system sync status, communications and Previous / Next.

**Say:**
> "Everything about one property in one place, so she isn't switching between Equator, Hubzu and email to answer one question."

### 4.3 Offers

**Show:** Click **Offers**. Point at the three status filters and the columns: best offer, % of list, % of reserve, the agent's recommendation and confidence.

**Say:**
> "Offers can't wait. Approved ones are at the top with an execute button. The ones that need her decision come with the agent's view against list and reserve."

### 4.4 Investor follow-ups

**Show:** Click **Investor follow-ups**. Point at the numbers: 12 outstanding, oldest 16 BD (2222 Cedar Ln), 5 due today. Click **Review & send 5 nudges due today**, then approve. On another row, click **Log response → Approved**; *Approved today* goes up.

**Say:**
> "This is Mason's centralized nudge queue. The rule is a nudge from day 2, then every business day, with REO management copied. One approval sends today's nudges, and the clock keeps the request's real age."

### 4.5 Awaiting response

**Show:** Click **Awaiting response**. Point at *What was sent*, *Expected by* and the countdown, then **Log response** and **Resend**.

**Say:**
> "Every vendor and partner follow-up, with its deadline. If the deadline passes, the item goes back to her exceptions."

### 4.6 Recommendations

**Show:** Click **Recommendations** (12 waiting: Pricing 7, Offers & contracts 2, Plans 3). Open **List price reduction · 1234 Maple Grove Dr → Review & decide**. Point at:
- the verdict
- the confidence and approval route (within her authority up to 5%, the investor up to 8%, beyond that a management exception)
- the market and property evidence, each tagged *Supports* or *Contrary*
- the market picker and the investor-ready brief

**Say:**
> "Leadership asked for market-aware recommendations on list price, reserve, plan amendments and buyer contracts. This is the deep version of the drawer you saw on Today, for the decisions that deserve it."

### 4.7 AI Agents

**Show:** Click **AI Agents**. Point at the headline numbers: **43.2 hours** saved this week, **89** recommendations prepared, **85%** accepted as drafted. Point at one card's mode (Shadow or Supervised), properties in scope and the ready / exceptions / blocked split.

**Say:**
> "Mason was clear that AMs don't need to see how the agents work, so this isn't on the home page. It's here for leads and for the product and data teams: what each agent does, how often its work is accepted, and the time it saves."

### 4.8 Portfolio

**Show:** Click **Portfolio**. Point at *Your book* (236 files by phase, with the coral cap for files with an exception; clicking a column opens those files in My Work), the 3D aging chart with its Table toggle, the velocity tiles and the metric definitions.

**Say:**
> "Trends and executive metrics live here, so the home page stays about today's work. Every number has a definition, a source and an as-of time."

---

## 5. Close

**Show:** Go back to **Today**. Toggle dark mode, then back to light.

**Say:**
> "To sum up: Control Tower now does what Mason said Equator can't. It finds each exception, recommends the resolution and lets the asset manager approve it with one click, one at a time or in bulk. Advancement work sits right beside it. Every nudge is tracked until it's answered. And the first-hour goal shows whether she's on pace. The next steps are real market data, the asset-manager view, and connecting the write-backs to Equator."

---

## 6. Before → after

| Before | After |
|---|---|
| A KPI wall: 30,047 exceptions and "N/A" tiles | One sentence: 42 exceptions, 13 decisions, about an hour |
| Equator lists tasks; the AM works out what to do | Every exception arrives with a recommended resolution and a button |
| Exceptions found by daily or weekly reports (~2-day lag) | 19 live exception types with business-day rules |
| 40 minutes to gather data and write an investor email | Review the drafted message, pick the market points, approve |
| One email at a time | Bulk approval for items that share a template |
| Nudges spread across inboxes | Investor follow-ups and Awaiting response, in one place |
| Tasks that Equator rejects for missing fields | Completed inside Control Tower |
| No sense of progress | A first-hour goal ring against Mason's 90% target |

---

## 7. What's real, what's sample, and what's next

- **Sample data.** All properties, people and numbers are mock data for one AM's book. Market values are **sample data** until a market data source is selected, and the UI says so.
- **Not connected yet.** There are no live integrations with Equator, Hubzu, ResWare, Triple R or DocuSign. Write-backs are simulated to show the intended supervised behaviour.
- **Known quirks (so you aren't caught out):**
  - **All · 2,759** in the header is a label only. The asset-manager view isn't built yet.
  - The **Recommendations** badge in the menu says 5, while the page lists 12 waiting.
  - The 90% first-hour, 95% resolution and 70% capacity targets aren't tracked over time yet.
- **Next steps:**
  1. An **asset-manager view**: a manager picks one AM's portfolio or the whole team (Jesse's ask; designed, parked).
  2. **Live market data:** public ZIP trends (Redfin-style) plus an MSA data provider.
  3. **Validate the catalog's business-day rules** per client with the AM team.
  4. **Connect write-backs** to Equator in supervised mode.
  5. **Property journey view** (deferred until after the MVP).
  6. **Usability sessions** with 3–5 asset managers.

---

## 8. Likely questions

- **"Does anything get sent automatically?"** No. Every message and every write needs her approval. The drawer says so at the top, and every action has Undo.
- **"How does it decide the recommended resolution?"** Each exception type in the catalog has a rule, an owner, a recommended resolution and a template. The agent prepares the specifics (amounts, recipients, evidence) and shows its confidence and the guideline it followed.
- **"How are the top 15 chosen?"** By severity: Critical before Warning, then how far past the SLA. She can switch to *Most days over* or view all 42.
- **"What if a vendor or investor doesn't reply?"** The item comes back to Exceptions after the expected date, with "nothing received" in the detail, so she can send the next follow-up.
- **"Where does the market data come from?"** It's sample data in the POC. The plan is public ZIP trends (like Redfin) plus an MSA provider. Either way, the AM picks which points go to the investor.
- **"Can a manager see a team or one AM's view?"** The client view works today. The asset-manager view is the next item on the list.
- **"Why aren't the agents on the home page?"** The meeting agreed the AM needs to see the remaining work, not the machinery. Agents are named on each recommendation, and the AI Agents page shows the detail.
- **"How is this different from Equator?"** Equator tells her what's overdue. Control Tower tells her what to do about it and does it when she approves.

---

## 9. How it was built (skills and references)

- **Skills used:**
  - **apple-design:** Apple's interface guidelines for the web (type, materials, springs, reduced motion)
  - **motion-framer:** Framer Motion patterns
  - **dataviz:** chart method and palette checks
  - Tooling only: **built-in-browser** (previewing) and **claude-api** (the helper script)
- **Design references:** React Bits (SpotlightCard, TiltedCard, GlassIcons, MagicBento/BorderGlow, AnimatedList) and 21st.dev (Shine Border), re-implemented in-house.
- **Steering for future work through the Claude API:** see `steering/README.md`.
