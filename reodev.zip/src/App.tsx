import { Component, useLayoutEffect, type ReactNode } from 'react'
import { AnimatePresence, MotionConfig, motion } from 'framer-motion'
import { restoreScroll, useRoute, type Route } from './lib/router'
import { spring } from './lib/motion'
import { AppFooter, CommandPalette, Sidebar, Toaster, Toolbar } from './components/chrome'
import { BatchSheet } from './features/BatchSheet'
import { ConfirmSheet } from './features/ConfirmSheet'
import { WorkItemPanel } from './features/WorkItemPanel'
import { ResolveSheet } from './features/ResolveSheet'
import Today from './pages/Today'
import PropertyCockpit from './pages/PropertyCockpit'
import Recommendation from './pages/Recommendation'
import Approval from './pages/Approval'
import Agents from './pages/Agents'
import Portfolio from './pages/Portfolio'
import { MyWork, Properties } from './pages/lists'
import type { DecisionType } from './data/market'
import Recommendations from './pages/Recommendations'
import { Awaiting, FollowUps, Offers } from './pages/tracking'

class Boundary extends Component<{ children: ReactNode; resetKey: string }, { error: Error | null }> {
  state = { error: null as Error | null }
  static getDerivedStateFromError(error: Error) { return { error } }
  componentDidUpdate(prev: { resetKey: string }) { if (prev.resetKey !== this.props.resetKey && this.state.error) this.setState({ error: null }) }
  render() {
    if (!this.state.error) return this.props.children
    return (
      <div className="card card-pad stack gap-8" style={{ maxWidth: 520, margin: '60px auto' }}>
        <span className="t-title3">This view hit a problem</span>
        <span className="t-sub">{this.state.error.message}</span>
        <button className="btn btn-primary" style={{ alignSelf: 'flex-start' }} onClick={() => this.setState({ error: null })}>Try again</button>
      </div>
    )
  }
}

function Page({ route }: { route: Route }) {
  switch (route.name) {
    case 'today': return <Today />
    case 'work': return <MyWork />
    case 'properties': return <Properties />
    case 'property': return <PropertyCockpit id={route.id} />
    case 'recs': return <Recommendations />
    case 'rec': return <Recommendation id={route.id} type={route.type as DecisionType} />
    case 'approval': return <Approval id={route.id} type={route.type as DecisionType} />
    case 'agents': return <Agents />
    case 'portfolio': return <Portfolio />
    case 'followups': return <FollowUps />
    case 'awaiting': return <Awaiting />
    case 'offers': return <Offers />
  }
}

const TITLES: Record<Route['name'], string> = {
  today: 'Today', work: 'My Work', properties: 'Properties', property: 'Property', recs: 'Recommendations',
  rec: 'Recommendation', approval: 'Approval Package', agents: 'AI Agents', portfolio: 'Portfolio',
  followups: 'Investor follow-ups', awaiting: 'Awaiting response', offers: 'Offers',
}

export default function App() {
  const { path, route } = useRoute()
  useLayoutEffect(() => { document.title = `${TITLES[route.name]} · REO Control Tower` }, [route.name])
  return (
    <MotionConfig reducedMotion="user" transition={spring}>
      <div className="app">
        <Sidebar route={route} />
        <div className="main-col">
          <Toolbar />
          <main className="content">
            <AnimatePresence mode="wait" initial={false} onExitComplete={() => restoreScroll(path)}>
              <motion.div key={path} initial={{ opacity: 0, y: 12, filter: 'blur(6px)' }} animate={{ opacity: 1, y: 0, filter: 'blur(0px)' }}
                exit={{ opacity: 0, y: -6, filter: 'blur(4px)', transition: { duration: 0.14 } }} transition={{ ...spring, duration: 0.45 }}>
                <Boundary resetKey={path}><Page route={route} /></Boundary>
              </motion.div>
            </AnimatePresence>
          </main>
          <AppFooter />
        </div>
        <WorkItemPanel />
        <BatchSheet />
        <ConfirmSheet />
        <ResolveSheet />
        <CommandPalette />
        <Toaster />
      </div>
    </MotionConfig>
  )
}
