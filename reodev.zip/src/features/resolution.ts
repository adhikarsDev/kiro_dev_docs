// Resolution engine: exception → recommended resolution → one-click action.
import { money, signalDef, type Property, type WorkItem } from '../data/mock'
import { recFor } from '../data/rec'
import { addBD, dateFor, fmtDate, overBy, recheckBD, requestOf, stageOf, unitOf } from '../data/workflow'
import { useApp } from '../lib/store'
import type { DecisionType } from '../data/market'

export type Outcome = 'watch' | 'approvals' | 'done' | 'navigate'
export interface Resolution {
  title: string
  decision: string
  facts: string[]
  guideline: string
  guidelineText: string
  agent: string
  kind: 'admin' | 'advance'
  confidence: number
  evidence: [number, number]
  missing?: string
  evidenceRows: [string, string][]
  outcome: Outcome
  actionLabel: string
  market?: DecisionType
  decisionInput?: { label: string; value: number }
  equatorFields?: { label: string; value: string; options?: string[] }[]
  to: string
  cc: string
  subject: string
  body: string
  template: string
  navigateTo?: string
}

export const ADVANCE_RULES: Record<string, { outcome: Outcome; action: string; agent: string; to?: string }> = {
  'Values ready to agree': { outcome: 'done', action: 'Agree & write to Equator', agent: 'Complete Marketing Plan Agent' },
  'Triple R bid to approve': { outcome: 'done', action: 'Approve bid', agent: 'Pre-Marketing Agent', to: 'Triple R Operations <dispatch@triple-r.example>' },
  'Ready to list': { outcome: 'done', action: 'Send to Hubzu', agent: 'Complete Marketing Plan Agent', to: 'Hubzu listings <listings@hubzu.example>' },
  'Closing review': { outcome: 'done', action: 'Approve settlement', agent: 'Closing Monitor' },
  'Equator task to complete': { outcome: 'done', action: 'Complete in Control Tower', agent: 'Set Reserve Price Agent' },
  'Occupancy result in: route the file': { outcome: 'watch', action: 'Order services', agent: 'Pre-Marketing Agent', to: 'Triple R Operations <dispatch@triple-r.example>' },
  'Offer recommendation ready': { outcome: 'approvals', action: 'Send H&B request', agent: 'Highest & Best Agent' },
  'Marketing plan ready': { outcome: 'approvals', action: 'Send plan for approval', agent: 'Complete Marketing Plan Agent' },
  'Reduction case ready': { outcome: 'navigate', action: 'Review reduction case', agent: 'Review Marketing Plan Agent' },
}

const MARKET_TYPE: Partial<Record<string, DecisionType>> = { reduction: 'list', rma: 'plan', initlist: 'list', relist: 'reserve', relistcancel: 'list', offerreview: 'contract' }

export function resolutionFor(i: WorkItem, p: Property): Resolution {
  const list = p.listPrice ?? p.valuation ?? 220000
  const stage = stageOf(p) ?? 'Sold'
  const rec = recFor(p)
  const hub = `${180 + (parseInt(p.id.slice(1), 10) % 60)} page views · ${14 + (parseInt(p.id.slice(1), 10) % 12)} watchers · ${6 + (parseInt(p.id.slice(1), 10) % 8)} showing requests`
  const baseRows: [string, string][] = [
    ['Stage', `${stage} · day ${p.daysInPhase} in stage`],
    ['Days in gap', `${i.days} ${unitOf(i)} (SLA ${i.slaDays} ${unitOf(i)}, ${overBy(i)} over)`],
    ['Finding', i.detail],
    ['Client', p.investor],
    ['Occupancy', p.occupancy],
    ['Loan', p.loan],
  ]
  const investorTo = `${p.investor} approvals <reo-approvals@${p.investor.split('/')[0].toLowerCase()}.example>`
  const sign = '\n\nThank you,\nSrini\nAsset Management'

  // ---------- advancement items (Ready to advance) ----------
  if (i.queue === 'actions' && i.advance) {
    const r = ADVANCE_RULES[i.advance] ?? { outcome: 'done' as Outcome, action: i.nextAction, agent: 'Asset Management Agent' }
    const eqFields = i.advance === 'Equator task to complete'
      ? [{ label: 'Reserve justification', value: 'Market decline (MSA reductions 37%)', options: ['Market decline (MSA reductions 37%)', 'Low bidder activity', 'Valuation update'] }, { label: 'Next auction cycle start', value: fmtDate(addBD(dateFor(0), 3)) }]
      : undefined
    const reserve = Math.round((list * 0.92) / 1000) * 1000
    return {
      title: i.reason, decision: i.advance === 'Equator task to complete' ? `Set reserve at ${money(reserve)} and finish the Equator task` : i.advance === 'Values ready to agree' ? `Agree the marketing value at ${money(p.valuation)}` : `${r.action}: ${i.detail}`,
      facts: [i.detail, `${p.investor} file · ${stage}`, i.advance === 'Equator task to complete' ? 'Equator rejected the task: 2 required fields missing. Complete them here instead of switching to Equator.' : 'Ready for your decision; moves the file forward'],
      guideline: 'GL-ADV-01', guidelineText: 'Advance the file the same day the prerequisite arrives.', agent: r.agent, kind: 'advance', confidence: 92, evidence: [3, 3],
      evidenceRows: [...baseRows, ['List / value', `${money(p.listPrice)} / ${money(p.valuation)}`]],
      outcome: r.outcome, actionLabel: r.action, equatorFields: eqFields,
      to: r.to ?? (r.outcome === 'approvals' ? investorTo : 'Equator (system of record)'), cc: 'REO Client Manager',
      subject: `${i.reason}: ${p.street}`, body: `Hello,\n\n${i.reason} for ${p.street}, ${p.city}, ${p.state} (loan ${p.loan}).\n${i.detail}.${sign}`, template: 'ADV-01',
      navigateTo: r.outcome === 'navigate' ? `/rec/${p.id}?type=list` : undefined,
    }
  }

  // ---------- exceptions (catalog types) ----------
  // Approvals already with the investor get the same nudge rule as an overdue one.
  const def = i.signal ? signalDef(i.signal) : i.queue === 'approvals' ? signalDef('investor') : null
  const key = i.signal ?? 'investor'
  const outcome: Outcome = def?.owner === 'Internal' ? 'done' : def?.owner === 'Investor' ? 'approvals' : 'watch'
  let decision = def?.resolution ?? i.nextAction
  let decisionInput: Resolution['decisionInput']
  const facts = [i.detail, `${def?.title ?? i.reason}: ${def?.rule ?? ''}`, `Day ${i.days} ${unitOf(i)} · ${overBy(i)} ${unitOf(i)} past the ${i.slaDays} ${unitOf(i)} target`]
  const rows = [...baseRows]
  if (p.phase !== 'pre') { rows.push(['Listed', `${rec.firstList} · ${p.dom ?? 0} days on market`], ['List price', money(p.listPrice)], ['Hubzu metrics', hub], ['Highest offer', money(p.prevHighOffer)]) }
  if (key === 'reduction' || key === 'rma' || key === 'relistcancel') {
    const pct = key === 'rma' ? 0.05 : 0.08
    const to = Math.round((list * (1 - pct)) / 100) * 100
    decision = `Reduce ${Math.round(pct * 100)}% from ${money(list)} to ${money(to)}${key === 'rma' ? ' and move to a traditional listing' : ''}`
    decisionInput = { label: 'New list price', value: to }
    facts.push(`Hubzu: ${hub}`, `${p.investor} must approve the reduction`)
    rows.push(['Comps (3 sold within 1 mile)', [0.94, 0.97, 1.0].map((k) => money(Math.round((to * k) / 100) * 100)).join(' · ')])
  } else if (key === 'initlist') {
    const v = p.valuation ?? list
    decision = `Request initial list approval at ${money(v)}`
    decisionInput = { label: 'Initial list price', value: v }
    facts.push(`Agreed value ${money(v)} · trash-out complete`, `${p.investor} requires initial list approval`)
  } else if (key === 'relist') {
    const reserve = Math.round((list * 0.92 * 0.95) / 500) * 500
    decision = `Relist next Hubzu cycle with reserve ${money(reserve)} (−5%)`
    decisionInput = { label: 'New reserve', value: reserve }
  } else if (key === 'offerreview') {
    const offer = p.prevHighOffer ?? Math.round((list * 0.93) / 500) * 500
    const counter = Math.round((offer + (list - offer) * 0.6) / 100) * 100
    decision = offer / list >= 0.97 ? `Accept ${money(offer)}` : `Counter at ${money(counter)} (offer ${money(offer)}, ${(offer / list * 100).toFixed(1)}% of list)`
    decisionInput = { label: offer / list >= 0.97 ? 'Accept at' : 'Counter at', value: offer / list >= 0.97 ? offer : counter }
    rows.push(['Offers', `${p.bids} offers · ${p.bidders} bidders · best ${money(offer)}`], ['Reserve', money(Math.round((list * 0.92) / 1000) * 1000)])
  } else if (key === 'reconcile') {
    const v = p.valuation ?? list
    decision = `Agree the marketing value at ${money(Math.round((v * 1.009) / 500) * 500)} (midpoint, values within 2%)`
    decisionInput = { label: 'Agreed value', value: Math.round((v * 1.009) / 500) * 500 }
  }
  const recheck = def ? recheckBD(def.recheck) : 2
  const owner = def?.owner === 'Investor' ? investorTo : def ? `${def.template.to} <${def.template.toEmail}>` : i.counterparty
  const subjectBase = def ? def.template.name.split('·')[1]?.trim() ?? def.title : i.reason
  const body = outcome === 'done'
    ? ''
    : `Hello ${def?.owner === 'Investor' ? `${p.investor} team` : `${def?.template.to.split(' ')[0] ?? ''} team`},\n\n${def?.template.intro.replace('The properties below have', `${p.street}, ${p.city}, ${p.state} (loan ${p.loan}) has`).replace('The properties below are', `${p.street} is`).replace('the properties below', p.street).replace('The requests below remain', 'This request remains').replace('The closings below are', 'This closing is').replace('The listings below have', 'This listing has').replace('The contracts below were', 'The contract was').replace('The occupied properties below are', 'This occupied property is') ?? ''}\n\n${decisionInput ? `${decision}.\n` : ''}${i.detail}.\n\n${def?.template.ask ?? ''}${sign}`
  return {
    title: def?.title ?? i.reason, decision, facts, guideline: def?.guideline ?? 'GL-INV-01',
    guidelineText: def ? `${def.title}: ${def.rule}. ${def.resolution}.` : '', agent: def?.agent ?? 'Asset Management Agent', kind: def?.kind ?? 'admin',
    confidence: def?.market ? 86 + (parseInt(p.id.slice(1), 10) % 8) : 95, evidence: key === 'trashout' && !p.valuation ? [3, 4] : [4, 4],
    missing: key === 'trashout' && !p.valuation ? 'No values on file: the valuation exception is also open' : undefined,
    evidenceRows: rows, outcome, actionLabel: outcome === 'done' ? 'Approve & write to Equator' : def?.owner === 'Investor' ? `Approve & send to ${p.investor}` : 'Approve & send',
    market: MARKET_TYPE[key], decisionInput,
    to: outcome === 'done' ? 'Equator (system of record)' : owner, cc: def?.template.cc ?? 'Srini',
    subject: `${subjectBase}: ${p.street}, loan ${p.loan}`, body, template: def?.template.name ?? 'GEN-01',
    navigateTo: undefined,
  } satisfies Resolution & { navigateTo?: string }
}

/** Where an approved item goes next, with the fields Awaiting response / Investor follow-ups need. */
export function movePatch(i: WorkItem, r: Resolution, at: string): { to: 'watch' | 'approvals' | 'done'; patch?: Partial<WorkItem> } {
  const def = i.signal ? signalDef(i.signal) : null
  const bd = def ? recheckBD(def.recheck) : 2
  const off = useApp.getState().dayOffset
  const expect = fmtDate(addBD(dateFor(off), bd))
  at = `${fmtDate(dateFor(off))}, ${at}`
  if (r.outcome === 'done' || r.outcome === 'navigate') return { to: 'done' }
  if (r.outcome === 'approvals') {
    const isNudge = i.signal === 'investor' || i.queue === 'approvals'
    return { to: 'approvals', patch: { status: 'Approval Pending', reason: isNudge ? `${requestOf(i)} · with ${i.counterparty}` : `${r.title} · sent to ${i.counterparty}`, detail: `Sent ${at} · next follow-up ${isNudge ? fmtDate(addBD(dateFor(off), 1)) : expect}`,
      // A nudge keeps the request's age (it's still outstanding) and comes due again the next business day.
      days: isNudge ? i.days : 0, slaDays: isNudge ? Math.max(i.days, 1) : 2, risk: 'Low', actionKind: 'view', nextAction: 'View package', followUps: (i.followUps ?? 0) + (isNudge ? 1 : 0), sentOn: at, expectBy: expect, sentWhat: isNudge ? 'Investor nudge' : r.title } }
  }
  return { to: 'watch', patch: { status: 'Waiting External', reason: `${def?.action ?? 'Follow-up'} sent · ${def?.owner ?? i.counterparty}`, detail: `Sent ${at} · reply expected by ${expect}`, days: 0, slaDays: bd, risk: 'Low', actionKind: 'view', nextAction: 'View', sentOn: at, expectBy: expect, sentWhat: def?.template.name.split('·')[1]?.trim() ?? r.title } }
}
