import { useEffect, useMemo, useRef, useState } from 'react'
import { AnimatePresence, motion } from 'framer-motion'
import { ArrowDownUp, ArrowRight, ChevronLeft, ChevronRight, Info, Inbox, Search, X } from 'lucide-react'
import { countBy, inClient, overdue, rank, useApp } from '../lib/store'
import { navigate } from '../lib/router'
import { PHASES, propertyById, type Phase, type Queue, type WorkItem } from '../data/mock'
import { spring, springSnappy } from '../lib/motion'
import { AnimatedNumber, Check, PhasePill, Segmented, riskTone } from '../components/ui'
import { originOf, performAction } from './actions'

export const QUEUES: { key: Queue; label: string; tone: string }[] = [
  { key: 'exceptions', label: 'Exceptions', tone: 'red' },
  { key: 'actions', label: 'Actions Ready', tone: 'green' },
  { key: 'approvals', label: 'Approvals Waiting', tone: 'orange' },
  { key: 'watch', label: 'Watchlist', tone: 'gray' },
]

export function useQueueList() {
  const items = useApp((s) => s.items)
  const queueTab = useApp((s) => s.queueTab)
  const phaseFilter = useApp((s) => s.phaseFilter)
  const client = useApp((s) => s.clientFilter)
  return useMemo(() => {
    const inTab = items.filter((i) => i.queue === queueTab && inClient(client, propertyById(i.propertyId).investor)).sort(rank)
    const filtered = phaseFilter === 'all' ? inTab : inTab.filter((i) => propertyById(i.propertyId).phase === phaseFilter)
    return { inTab, filtered }
  }, [items, queueTab, phaseFilter, client])
}

export function WorkQueue({ limit, selectable, search, paginate, compact }: { limit?: number; selectable?: boolean; search?: boolean; paginate?: boolean; compact?: boolean }) {
  const allItems = useApp((s) => s.items)
  const client = useApp((s) => s.clientFilter)
  const items = useMemo(() => allItems.filter((i) => inClient(client, propertyById(i.propertyId).investor)), [allItems, client])
  const { queueTab, setQueueTab, phaseFilter, setPhaseFilter, selectedId, select, openBatch } = useApp()
  const counts = countBy(items)
  const { inTab, filtered } = useQueueList()
  const [q, setQ] = useState('')
  const [picked, setPicked] = useState<Set<string>>(new Set())
  const [page, setPage] = useState(0)
  const [size, setSize] = useState(10)

  const searched = q
    ? filtered.filter((i) => { const p = propertyById(i.propertyId); return `${p.street} ${p.city} ${p.loan} ${p.investor} ${i.reason}`.toLowerCase().includes(q.toLowerCase()) })
    : filtered
  const pages = Math.max(1, Math.ceil(searched.length / size))
  useEffect(() => { setPage(0) }, [queueTab, phaseFilter, q, size])
  useEffect(() => { if (page > pages - 1) setPage(pages - 1) }, [page, pages])
  const shown = limit ? searched.slice(0, limit) : paginate ? searched.slice(page * size, page * size + size) : searched
  const phaseCount = (ph: Phase) => inTab.filter((i) => propertyById(i.propertyId).phase === ph).length
  const togglePick = (id: string) => setPicked((s) => { const n = new Set(s); n.has(id) ? n.delete(id) : n.add(id); return n })
  const pickedItems = items.filter((i) => picked.has(i.id))

  return (
    <div className="card" id="my-work" style={{ overflow: 'hidden' }}>
      {/* Row 1: which queue · search */}
      <div className="queue-bar">
        <Segmented layoutId={`queue-thumb-${selectable ? 'p' : 'h'}`} value={queueTab} onChange={(k) => { setQueueTab(k); setPicked(new Set()) }}
          items={QUEUES.map((x) => ({ key: x.key, label: x.label, count: counts[x.key], tone: x.tone }))} />
        <span className="spacer" />
        {search && <SearchField value={q} onChange={setQ} />}
      </div>
      {/* Row 2: phase filter · ordering */}
      <div className="queue-bar sub">
        <div className="hstack gap-6 wrap">
          <button className={`chip ${phaseFilter === 'all' ? 'on' : ''}`} onClick={() => setPhaseFilter('all')}>All phases <span className="c">{inTab.length}</span></button>
          {PHASES.filter((p) => p.key !== 'sold').map((p) => (
            <button key={p.key} className={`chip ${phaseFilter === p.key ? 'on' : ''}`} onClick={() => setPhaseFilter(p.key)}>
              {p.label} <span className="c">{phaseCount(p.key)}</span>
            </button>
          ))}
        </div>
        <span className="spacer" />
        <SortNote />
      </div>
      <div className={`qcols ${selectable ? 'selectable' : ''} ${compact ? 'compact' : ''}`}>
        {selectable && <span><Check on={shown.length > 0 && shown.every((i) => picked.has(i.id))} onClick={() => setPicked(shown.every((i) => picked.has(i.id)) ? new Set() : new Set(shown.map((i) => i.id)))} label="Select all" /></span>}
        <span /><span>Property</span>{!compact && <span>Phase</span>}<span>Why attention is needed</span><span>Days</span><span>Next best action</span>
      </div>
      <div style={{ position: 'relative' }}>
        <AnimatePresence initial={false} mode="popLayout">
          {shown.map((it, k) => (
            <QueueRow key={it.id} it={it} k={k} sel={selectedId === it.id} onSelect={() => select(selectedId === it.id ? null : it.id)}
              selectable={selectable} picked={picked.has(it.id)} onPick={() => togglePick(it.id)} compact={compact} />
          ))}
        </AnimatePresence>
        {!shown.length && (
          <motion.div className="empty" initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
            <Inbox size={30} />
            <div className="t-headline" style={{ color: 'var(--label)' }}>{q ? `No matches for “${q}”` : `Nothing here${phaseFilter !== 'all' ? ' for this phase' : ''}`}</div>
            <div className="t-sub">Files that need you will appear here automatically.</div>
          </motion.div>
        )}
      </div>
      {paginate && searched.length > 0 && (
        <Pager page={page} pages={pages} size={size} total={searched.length} onPage={setPage} onSize={setSize} />
      )}
      {limit && filtered.length > limit && (
        <button className="hstack gap-6" onClick={() => navigate('/work')}
          style={{ width: '100%', justifyContent: 'center', padding: '13px', borderTop: '0.5px solid var(--separator)', color: 'var(--blue-text)', fontWeight: 600, fontSize: 13.5 }}>
          View all {filtered.length} in My Work <ArrowRight size={15} />
        </button>
      )}
      <AnimatePresence>
        {selectable && picked.size > 0 && (
          <motion.div className="bulkbar" initial={{ y: 80, opacity: 0, x: '-50%' }} animate={{ y: 0, opacity: 1, x: '-50%' }} exit={{ y: 80, opacity: 0, x: '-50%' }} transition={{ type: 'spring', bounce: 0.2, duration: 0.45 }}>
            <span className="strong num">{picked.size} selected</span>
            <span className="t-caption" style={{ marginRight: 6 }}>{new Set(pickedItems.map((i) => i.signal).filter(Boolean)).size > 1 ? 'mixed signals' : ''}</span>
            {(() => {
              const sigs = Array.from(new Set(pickedItems.map((i) => i.signal).filter(Boolean)))
              return sigs.length === 1 ? (
                <button className="btn btn-primary" onClick={(e) => { openBatch({ signal: sigs[0]!, itemIds: pickedItems.map((i) => i.id), origin: originOf(e) }); setPicked(new Set()) }}>Draft follow-ups</button>
              ) : null
            })()}
            <button className="btn btn-gray" onClick={() => {
              const undo = useApp.getState().moveItems(Array.from(picked), 'watch', { status: 'Waiting External', reason: 'Snoozed 1 day', detail: 'Returns to Exceptions tomorrow 9:00 AM' })
              useApp.getState().toast({ title: `${picked.size} items snoozed until tomorrow`, undo }); setPicked(new Set())
            }}>Snooze 1 day</button>
            <button className="btn btn-gray" onClick={() => { useApp.getState().toast({ title: `${picked.size} items assigned to Jesse R.`, tone: 'info' }); setPicked(new Set()) }}>Assign…</button>
            <button className="btn btn-plain" onClick={() => setPicked(new Set())}>Cancel</button>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  )
}

function QueueRow({ it, k, sel, onSelect, selectable, picked, onPick, compact }: {
  it: WorkItem; k: number; sel: boolean; onSelect: () => void; selectable?: boolean; picked: boolean; onPick: () => void; compact?: boolean
}) {
  const p = propertyById(it.propertyId)
  const late = overdue(it)
  const dayTone = it.actToday ? 'blue' : it.queue === 'exceptions' ? (late > 0 ? 'red' : 'orange') : it.queue === 'actions' ? 'green' : 'gray'
  return (
    <motion.div
      layout="position"
      className={`qrow ${sel ? 'sel' : ''} ${selectable ? 'selectable' : ''} ${compact ? 'compact' : ''}`}
      role="button"
      tabIndex={0}
      aria-pressed={sel}
      onClick={onSelect}
      onKeyDown={(e) => { if (e.key === 'Enter') onSelect() }}
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0, transition: { ...spring, delay: Math.min(k, 10) * 0.025 } }}
      exit={{ opacity: 0, x: 60, scale: 0.98, transition: { duration: 0.28, ease: [0.32, 0.72, 0, 1] } }}
    >
      {selectable && <span onClick={(e) => { e.stopPropagation(); onPick() }}><Check on={picked} /></span>}
      <span className="risk-bar" data-tone={it.actToday ? 'blue' : riskTone(it.risk)} title={`${it.risk} risk`} />
      <span className="stack min0">
        <span className="strong ellipsis" style={{ fontSize: 13.5 }}>{p.street}</span>
        <span className="t-caption ellipsis">{p.city}, {p.state} · {p.loan} · {p.investor}</span>
      </span>
      {!compact && <span><PhasePill phase={p.phase} /></span>}
      <span className="stack min0">
        <span className="ellipsis" style={{ fontWeight: 550, fontSize: 13.5 }}>{it.reason}</span>
        <span className="t-caption ellipsis">{it.detail}</span>
      </span>
      <span className="stack" data-tone={dayTone}>
        {it.actToday ? <span className="days" style={{ fontSize: 15 }}>Today</span> : <span className="days">{it.days}<span style={{ fontSize: 12, fontWeight: 600 }}>d</span></span>}
        <span className="t-caption" style={{ fontSize: 11 }}>{it.actToday ? it.approvedAgo : it.queue === 'exceptions' && late > 0 ? (compact ? `+${late}d late` : `+${late}d over SLA`) : `SLA ${it.slaDays}d`}</span>
      </span>
      <span style={{ justifySelf: 'end' }}>
        <motion.button className={`btn btn-sm ${it.actToday ? 'btn-primary' : 'btn-tinted'}`} whileTap={{ scale: 0.95 }} transition={springSnappy}
          onClick={(e) => { e.stopPropagation(); performAction(it, originOf(e)) }}>
          {it.nextAction}
        </motion.button>
      </span>
    </motion.div>
  )
}

/* Search with a clear button and a "/" shortcut. */
function SearchField({ value, onChange }: { value: string; onChange: (v: string) => void }) {
  const ref = useRef<HTMLInputElement>(null)
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const t = e.target as HTMLElement
      if (e.key === '/' && !['INPUT', 'TEXTAREA'].includes(t?.tagName) && !t?.isContentEditable) { e.preventDefault(); ref.current?.focus() }
    }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [])
  return (
    <label className="q-search">
      <Search size={15} className="t-3" />
      <input ref={ref} value={value} onChange={(e) => onChange(e.target.value)} placeholder="Search address, loan # or reason"
        onKeyDown={(e) => { if (e.key === 'Escape') { onChange(''); (e.target as HTMLInputElement).blur() } }} aria-label="Search the queue" />
      <AnimatePresence initial={false} mode="wait">
        {value
          ? <motion.button key="x" className="q-clear" onClick={() => onChange('')} aria-label="Clear search" initial={{ scale: 0.6, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0.6, opacity: 0 }}><X size={12} strokeWidth={3} /></motion.button>
          : <motion.span key="k" className="kbd" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>/</motion.span>}
      </AnimatePresence>
    </label>
  )
}

/* "Sorted by urgency" with the ranking explained on hover (no opaque scores). */
function SortNote() {
  const [open, setOpen] = useState(false)
  return (
    <span style={{ position: 'relative' }} onMouseEnter={() => setOpen(true)} onMouseLeave={() => setOpen(false)}>
      <button className="sort-note" onFocus={() => setOpen(true)} onBlur={() => setOpen(false)}><ArrowDownUp size={13} />Sorted by urgency<Info size={13} /></button>
      <AnimatePresence>
        {open && (
          <motion.span className="tooltip" style={{ right: 0, top: 34, width: 290, whiteSpace: 'normal', lineHeight: 1.5, transformOrigin: 'top right' }}
            initial={{ opacity: 0, y: -4, scale: 0.97 }} animate={{ opacity: 1, y: 0, scale: 1 }} exit={{ opacity: 0, y: -4, scale: 0.97 }} transition={{ duration: 0.16 }}>
            <b>How items are ranked</b><br />1. Same-day investor approvals<br />2. Risk tier, High → Low<br />3. How far past SLA (days ÷ SLA)<br />4. Age<br />
            <span className="t-caption">Thresholds are configurable per client and investor.</span>
          </motion.span>
        )}
      </AnimatePresence>
    </span>
  )
}

function Pager({ page, pages, size, total, onPage, onSize }: { page: number; pages: number; size: number; total: number; onPage: (p: number) => void; onSize: (n: number) => void }) {
  const from = page * size + 1, to = Math.min(total, page * size + size)
  const nums: (number | '…')[] = []
  for (let i = 0; i < pages; i++) {
    if (i === 0 || i === pages - 1 || Math.abs(i - page) <= 1) nums.push(i)
    else if (nums[nums.length - 1] !== '…') nums.push('…')
  }
  return (
    <div className="pager">
      <span className="t-sub">Showing <b className="num" style={{ color: 'var(--label)' }}>{from}–{to}</b> of <b className="num" style={{ color: 'var(--label)' }}>{total}</b></span>
      <span className="spacer" />
      <label className="hstack gap-6 t-sub">Rows
        <select className="pg-size" value={size} onChange={(e) => onSize(+e.target.value)}>{[10, 20, 50].map((n) => <option key={n} value={n}>{n}</option>)}</select>
      </label>
      <div className="pg-group">
        <button className="pg" onClick={() => onPage(page - 1)} disabled={page === 0} aria-label="Previous page"><ChevronLeft size={15} /></button>
        {nums.map((n, k) => n === '…'
          ? <span key={`e${k}`} className="pg ell">…</span>
          : (
            <button key={n} className={`pg ${n === page ? 'on' : ''}`} onClick={() => onPage(n)} aria-current={n === page ? 'page' : undefined}>
              {n === page && <motion.span layoutId="pg-thumb" className="pg-thumb" transition={springSnappy} />}
              <span>{n + 1}</span>
            </button>
          ))}
        <button className="pg" onClick={() => onPage(page + 1)} disabled={page >= pages - 1} aria-label="Next page"><ChevronRight size={15} /></button>
      </div>
    </div>
  )
}
