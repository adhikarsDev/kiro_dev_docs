import { useMemo, useState } from 'react'
import { AnimatePresence, motion } from 'framer-motion'
import { Check as CheckIcon, Globe, Sparkles } from 'lucide-react'
import { money, type Property } from '../data/mock'
import { evidenceFor, geoLabel, resolveGeo, type DecisionType } from '../data/market'
import { publicTrend } from '../data/workflow'
import { spring } from '../lib/motion'
import { Check, Sparkline } from '../components/ui'

export interface Bullet { id: string; group: 'Public ZIP trend' | 'MSA market' | 'Property'; text: string; supports: boolean; source: string }

/** Concise, selectable data points: public ZIP trends + MSA signals + property performance. */
export function bulletsFor(p: Property, type: DecisionType): Bullet[] {
  const t = publicTrend(p)
  const g = resolveGeo('all', '30d').geo
  const ev = evidenceFor(type, p, g, 'all', '30d')
  const offer = type === 'contract'
  const pub: Bullet[] = [
    { id: 'z1', group: 'Public ZIP trend', text: `Median sale price in ZIP ${t.zip} is ${money(t.medianSale)}, ${t.yoyValue < 0 ? '−' : '+'}${Math.abs(t.yoyValue)}% year over year`, supports: true, source: 'Public market data' },
    { id: 'z2', group: 'Public ZIP trend', text: `Homes in ZIP ${t.zip} take ${t.dom} days to sell, ${t.domYoy} days longer than a year ago`, supports: true, source: 'Public market data' },
    { id: 'z3', group: 'Public ZIP trend', text: `Homes sold in ZIP ${t.zip} are down ${Math.abs(t.soldYoy)}% year over year`, supports: true, source: 'Public market data' },
    { id: 'z4', group: 'Public ZIP trend', text: `Homes in ZIP ${t.zip} sell at ${t.saleToList.toFixed(1)}% of list price`, supports: t.saleToList < 97, source: 'Public market data' },
  ]
  const msa: Bullet[] = ev.market.map((s) => ({ id: `m-${s.key}`, group: 'MSA market', text: `${s.label}: ${s.value} (${s.detail}, ${geoLabel(g, p)})`, supports: s.read === 'supports', source: 'Market feed (sample)' }))
  const prop: Bullet[] = [...ev.property.filter((s) => s.key !== 'first'), ev.valuation].map((s) => ({ id: `p-${s.key}`, group: 'Property', text: `${s.label}: ${s.value}${s.detail ? ` (${s.detail})` : ''}`, supports: s.read === 'supports', source: s.key === 'val' ? 'Equator' : 'Hubzu / Equator' }))
  return [...pub, ...msa, ...prop]
}

export function summaryFrom(p: Property, picked: Bullet[], proposal: string) {
  const t = publicTrend(p)
  const market = picked.filter((b) => b.group !== 'Property' && b.supports).map((b) => b.text.replace(/\.$/, ''))
  const prop = picked.filter((b) => b.group === 'Property' && b.supports).map((b) => b.text)
  const contra = picked.filter((b) => !b.supports).map((b) => b.text)
  const parts = [
    market.length ? `Market context for ${p.city}, ${p.state} (ZIP ${t.zip}): ${market.join('; ')}.` : '',
    prop.length ? `Property performance: ${prop.join('; ')}.` : '',
    contra.length ? `We also considered: ${contra.join('; ')}.` : '',
    `Together these support our request to ${proposal}.`,
  ]
  return parts.filter(Boolean).join(' ')
}

/** The block that goes into the email: a small, professional market summary. */
export function MarketSummaryCard({ p, picked }: { p: Property; picked: Bullet[] }) {
  const t = publicTrend(p)
  return (
    <div className="msum">
      <div className="hstack gap-8"><Globe size={14} /><b>Market summary · {p.city}, {p.state} {t.zip}</b><span className="spacer" /><span className="t-caption">Sample public data · as of Nov 3</span></div>
      <div className="msum-kpis">
        <div><span>Median sale price</span><b>{money(t.medianSale, { compact: true })}</b><em className="neg">{t.yoyValue < 0 ? '−' : '+'}{Math.abs(t.yoyValue)}% YoY</em></div>
        <div><span>Days to sell</span><b>{t.dom}</b><em className="neg">+{t.domYoy} YoY</em></div>
        <div><span>Sale-to-list</span><b>{t.saleToList.toFixed(1)}%</b><em>ZIP average</em></div>
        <div className="msum-chart"><span>12-month median price</span><Sparkline values={t.trend} tone="rose" w={150} h={34} /></div>
      </div>
      {picked.length > 0 && <ul>{picked.map((b) => <li key={b.id}>{b.text}</li>)}</ul>}
    </div>
  )
}

/** Review the data points, tick the ones that apply, then generate the summary from those only. */
export function MarketPicker({ p, type, proposal, onSummary }: { p: Property; type: DecisionType; proposal: string; onSummary: (text: string, picked: Bullet[]) => void }) {
  const all = useMemo(() => bulletsFor(p, type), [p, type])
  const [sel, setSel] = useState<Set<string>>(() => new Set(all.filter((b) => b.supports).slice(0, 6).map((b) => b.id)))
  const [done, setDone] = useState<Bullet[] | null>(null)
  const toggle = (id: string) => { setSel((s) => { const n = new Set(s); n.has(id) ? n.delete(id) : n.add(id); return n }); setDone(null) }
  const groups: Bullet['group'][] = ['Public ZIP trend', 'MSA market', 'Property']
  const picked = all.filter((b) => sel.has(b.id))
  return (
    <div className="mpick">
      <div className="hstack gap-8 wrap">
        <span className="t-headline" style={{ flex: 1 }}>Market data: pick the points that support this request</span>
        <span className="t-caption">{picked.length} of {all.length} selected</span>
      </div>
      <span className="t-caption">Not every data point supports the narrative. Points that cut against it are shown but left unticked, so you decide what goes to the investor.</span>
      {groups.map((g) => (
        <div key={g} className="stack">
          <span className="t-eyebrow" style={{ padding: '8px 0 4px' }}>{g}</span>
          {all.filter((b) => b.group === g).map((b) => (
            <button key={b.id} className={`mpick-row ${sel.has(b.id) ? 'on' : ''}`} onClick={() => toggle(b.id)}>
              <Check on={sel.has(b.id)} />
              <span style={{ flex: 1 }}>{b.text}</span>
              <span className="pill" data-tone={b.supports ? 'mint' : 'peach'} style={{ height: 20 }}>{b.supports ? 'Supports' : 'Cuts against'}</span>
            </button>
          ))}
        </div>
      ))}
      <div className="hstack gap-8">
        <motion.button className="btn btn-tinted" whileTap={{ scale: 0.97 }} disabled={!picked.length}
          onClick={() => { const text = summaryFrom(p, picked, proposal); setDone(picked); onSummary(text, picked) }}>
          {done ? <CheckIcon size={14} /> : <Sparkles size={14} />}{done ? 'Summary added to the message' : `Generate summary from ${picked.length} point${picked.length === 1 ? '' : 's'}`}
        </motion.button>
        <span className="t-caption">Public ZIP data and market feed are sample values until retrieval is connected.</span>
      </div>
      <AnimatePresence initial={false}>
        {done && (
          <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: 'auto' }} exit={{ opacity: 0, height: 0 }} transition={spring} style={{ overflow: 'hidden' }}>
            <MarketSummaryCard p={p} picked={done} />
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  )
}
