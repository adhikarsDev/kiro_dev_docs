import { useEffect, useMemo, useState } from 'react'
import { AnimatePresence, motion } from 'framer-motion'
import { AlarmClock, ArrowRight, Check as CheckIcon, ChevronDown, ExternalLink, FileText, ShieldCheck, X } from 'lucide-react'
import { nowLabel, useApp } from '../lib/store'
import { navigate } from '../lib/router'
import { money, propertyById, signalDef, type WorkItem } from '../data/mock'
import { overBy, severityOf, unitOf } from '../data/workflow'
import { springSheet, springSnappy, spring } from '../lib/motion'
import { Check } from '../components/ui'
import { MarketPicker, MarketSummaryCard, type Bullet } from './marketPicker'
import { movePatch, resolutionFor } from './resolution'
import { SIGNAL_TONE } from './BatchSheet'

export function ResolveSheet() {
  const open = useApp((s) => s.resolve)
  return <AnimatePresence>{open && <Inner key="resolve" />}</AnimatePresence>
}

function Inner() {
  const { closeResolve, items } = useApp()
  const [snap] = useState(() => useApp.getState().resolve!)
  const [frozen] = useState(() => snap.itemIds.map((id) => useApp.getState().items.find((i) => i.id === id)).filter(Boolean) as WorkItem[])
  const list = frozen.map((f) => items.find((i) => i.id === f.id) ?? f)
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => { if (e.key === 'Escape') closeResolve() }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [closeResolve])
  return (
    <>
      <motion.div className="scrim" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={closeResolve} />
      <motion.aside className="rdrawer" role="dialog" aria-modal initial={{ x: '104%' }} animate={{ x: 0 }} exit={{ x: '104%' }} transition={springSheet}>
        {list.length === 1 ? <Single item={list[0]} /> : <Multi items={list} />}
      </motion.aside>
    </>
  )
}

/* ------------------------------------------------------------ one exception: full review */
function Single({ item }: { item: WorkItem }) {
  const { closeResolve, applyMoves, toast } = useApp()
  const p = propertyById(item.propertyId)
  const r = useMemo(() => resolutionFor(item, p), [item, p])
  const [value, setValue] = useState(r.decisionInput?.value ?? 0)
  const [subject, setSubject] = useState(r.subject)
  const [body, setBody] = useState(r.body)
  const [summary, setSummary] = useState<{ text: string; picked: Bullet[] } | null>(null)
  const [fields, setFields] = useState(r.equatorFields?.map((f) => f.value) ?? [])
  const [showEv, setShowEv] = useState(false)
  const [snooze, setSnooze] = useState(false)
  const tone = item.signal ? SIGNAL_TONE[item.signal] : 'mint'
  const def = item.signal ? signalDef(item.signal) : null
  const decisionText = r.decisionInput ? r.decision.replace(money(r.decisionInput.value), money(value)) : r.decision

  const approve = () => {
    if (r.outcome === 'navigate' && r.navigateTo) { closeResolve(); navigate(r.navigateTo); return }
    const at = nowLabel()
    const mv = movePatch(item, r, at)
    const undo = applyMoves([{ id: item.id, to: mv.to, patch: mv.patch }])
    toast({
      title: r.outcome === 'done' ? `Resolved · ${p.street}` : `Sent · ${p.street}`,
      body: r.outcome === 'done' ? 'Written to Equator in your session. Cleared from today\'s list.' : `${r.to.split('<')[0].trim()} · tracked in ${mv.to === 'approvals' ? 'Investor follow-ups' : 'Awaiting response'}`,
      undo,
    })
    closeResolve()
  }

  return (
    <>
      <div className="rd-head">
        <div className="stack gap-4" style={{ flex: 1, minWidth: 0 }}>
          <span className="t-title3">{r.title} · {p.street}</span>
          <span className="t-sub">{p.city}, {p.state} · {p.investor} · day {item.days} {unitOf(item)}{item.queue === 'exceptions' ? ` · ${overBy(item)} ${unitOf(item)} over target` : ''}</span>
          <div className="hstack gap-6 wrap" style={{ marginTop: 4 }}>
            {item.queue === 'exceptions' && <span className="pill" data-tone={severityOf(item) === 'Critical' ? 'rose' : 'sand'}>{severityOf(item)}</span>}
            <span className="pill" data-tone="sky">{r.agent}</span>
            <span className="pill" data-tone={r.kind === 'advance' ? 'mint' : 'gray'}>{r.kind === 'advance' ? 'Moves file forward' : 'Saves admin time'}</span>
            <span className="pill pill-outline" data-tone="gray">You approve before anything is sent</span>
          </div>
        </div>
        <button className="icon-btn" onClick={closeResolve} aria-label="Close"><X size={18} /></button>
      </div>

      <div className="rd-body">
        {/* 1 · exception → 2 · recommendation → 3 · action */}
        <div className="rd-steps">
          {[['1', 'Exception', def ? `${def.title}: ${def.rule}` : item.reason], ['2', 'Recommended resolution', decisionText], ['3', 'Action', `${r.actionLabel}${r.outcome === 'done' ? '' : ` → ${r.to.split('<')[0].trim()}`}`]].map(([n, h, t]) => (
            <div key={n} className="rd-step"><b>{n}</b><span className="stack"><em>{h}</em><span>{t}</span></span></div>
          ))}
        </div>

        <div className="rd-rec" data-tone={tone}>
          <span className="t-headline">{decisionText}</span>
          <ul>{r.facts.map((f) => <li key={f}>{f}</li>)}</ul>
          <span className="t-caption">Guideline <b>{r.guideline}</b> · {r.guidelineText}</span>
          <div className="hstack gap-12 wrap">
            <span className="t-caption">Confidence <b style={{ color: 'var(--label)' }}>{r.confidence}%</b></span>
            <span className="rd-conf"><motion.span initial={{ width: 0 }} animate={{ width: `${r.confidence}%` }} transition={{ ...spring, duration: 0.8 }} /></span>
            <span className="t-caption">Evidence {r.evidence[0]} of {r.evidence[1]}</span>
            <span className="t-caption" style={{ color: r.missing ? 'var(--orange-text)' : 'var(--green-text)' }}>{r.missing ?? 'No missing evidence'}</span>
          </div>
          {r.decisionInput && (
            <label className="rd-input">
              <span>{r.decisionInput.label}</span>
              <input type="number" step={100} value={value} onChange={(e) => setValue(+e.target.value)} />
              <span className="t-caption">Agent: {money(r.decisionInput.value)}</span>
            </label>
          )}
        </div>

        {r.equatorFields && (
          <div className="callout stack gap-10" data-tone="sand">
            <span className="t-headline">Equator needs {r.equatorFields.length} more fields to finish this task</span>
            <span className="t-caption">Fill them here. Control Tower completes the task in Equator, so you don't have to switch systems.</span>
            {r.equatorFields.map((f, k) => (
              <label key={f.label} className="rd-input">
                <span>{f.label}</span>
                {f.options
                  ? <select value={fields[k]} onChange={(e) => setFields((v) => v.map((x, j) => (j === k ? e.target.value : x)))}>{f.options.map((o) => <option key={o}>{o}</option>)}</select>
                  : <input value={fields[k]} onChange={(e) => setFields((v) => v.map((x, j) => (j === k ? e.target.value : x)))} />}
              </label>
            ))}
          </div>
        )}

        {r.market && (
          <MarketPicker p={p} type={r.market} proposal={decisionText.charAt(0).toLowerCase() + decisionText.slice(1)}
            onSummary={(text, picked) => { setSummary({ text, picked }); setBody((b) => b.replace(/\n\nThank you,/, `\n\n${text}\n\nThank you,`)) }} />
        )}

        {r.outcome !== 'done' && r.outcome !== 'navigate' && (
          <div className="rd-msg">
            <div className="hstack"><span className="t-headline" style={{ flex: 1 }}>Message</span><span className="pill" data-tone="sky"><FileText size={12} />{r.template}</span></div>
            <div className="mail-meta">
              <span className="k">To</span><span>{r.to}</span>
              <span className="k">Cc</span><span>{r.cc}</span>
              <span className="k">Subject</span><input className="rd-subject" value={subject} onChange={(e) => setSubject(e.target.value)} />
            </div>
            <textarea className="rd-body-text" value={body} onChange={(e) => setBody(e.target.value)} rows={Math.min(16, body.split('\n').length + 2)} />
            {summary && <MarketSummaryCard p={p} picked={summary.picked} />}
          </div>
        )}
        {(r.outcome === 'done') && (
          <div className="callout hstack gap-10" data-tone="mint"><ShieldCheck size={18} style={{ color: 'var(--mint-text)', flex: 'none' }} /><span style={{ fontSize: 13 }}>Approving writes the change to Equator in your session and clears it from today's list. No email is needed.</span></div>
        )}

        <button className="rd-ev-toggle" onClick={() => setShowEv((v) => !v)}>
          <motion.span animate={{ rotate: showEv ? 0 : -90 }} transition={springSnappy} style={{ display: 'grid' }}><ChevronDown size={15} /></motion.span>
          Agent pre-work: evidence ({r.evidenceRows.length})
        </button>
        <AnimatePresence initial={false}>
          {showEv && (
            <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: 'auto', opacity: 1 }} exit={{ height: 0, opacity: 0 }} transition={spring} style={{ overflow: 'hidden' }}>
              <div className="rd-ev">{r.evidenceRows.map(([k, v]) => <div key={k}><span>{k}</span><b>{v}</b></div>)}</div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      <div className="rd-foot">
        <motion.button className="btn btn-primary btn-lg" whileTap={{ scale: 0.97 }} onClick={approve}>{r.actionLabel}<ArrowRight size={15} /></motion.button>
        <div style={{ position: 'relative' }}>
          <button className="btn btn-gray" onClick={() => setSnooze((v) => !v)}><AlarmClock size={14} />Snooze</button>
          <AnimatePresence>
            {snooze && (
              <motion.div className="menu" style={{ top: 'auto', bottom: 44, right: 'auto', left: 0, width: 200 }} initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: 6 }} transition={springSnappy}>
                {['1 business day', '2 business days', 'Next week'].map((l) => (
                  <button key={l} className="menu-item" onClick={() => { const undo = applyMoves([{ id: item.id, to: 'watch', patch: { status: 'Waiting External', reason: `Snoozed · ${item.reason}`, days: 0, slaDays: l.startsWith('1') ? 1 : l.startsWith('2') ? 2 : 5, sentOn: nowLabel(), expectBy: l === 'Next week' ? 'next Monday' : `in ${l}`, sentWhat: 'Snooze' } }]); toast({ title: `Snoozed for ${l}`, body: p.street, undo }); closeResolve() }}>{l}</button>
                ))}
              </motion.div>
            )}
          </AnimatePresence>
        </div>
        <button className="btn btn-plain" onClick={() => { closeResolve(); navigate(`/property/${p.id}`) }}><ExternalLink size={14} />Open property</button>
        <span className="spacer" />
        <button className="btn btn-plain" style={{ color: 'var(--label-3)' }} onClick={() => { toast({ title: 'Recommendation rejected', body: 'Kept in your list · reason logged', tone: 'info' }); closeResolve() }}>Reject</button>
      </div>
    </>
  )
}

/* ------------------------------------------------------------ several: scan and approve together */
function Multi({ items }: { items: WorkItem[] }) {
  const { closeResolve, applyMoves, toast } = useApp()
  const rows = useMemo(() => items.map((i) => ({ i, p: propertyById(i.propertyId), r: resolutionFor(i, propertyById(i.propertyId)) })), [items])
  const [sel, setSel] = useState<Set<string>>(() => new Set(rows.filter((x) => x.r.outcome !== 'navigate').map((x) => x.i.id)))
  const [phase, setPhase] = useState<'idle' | 'sending'>('idle')
  const [done, setDone] = useState(0)
  const chosen = rows.filter((x) => sel.has(x.i.id))
  const emails = chosen.filter((x) => x.r.outcome === 'watch' || x.r.outcome === 'approvals').length
  const writes = chosen.length - emails
  const go = () => {
    setPhase('sending')
    chosen.forEach((_, k) => window.setTimeout(() => setDone(k + 1), 90 + k * 80))
    window.setTimeout(() => {
      const at = nowLabel()
      const undo = applyMoves(chosen.map((x) => { const mv = movePatch(x.i, x.r, at); return { id: x.i.id, to: mv.to, patch: mv.patch } }))
      toast({ title: `${chosen.length} resolution${chosen.length === 1 ? '' : 's'} approved`, body: `${emails} message${emails === 1 ? '' : 's'} sent and tracked · ${writes} written to Equator`, undo })
      closeResolve()
    }, 200 + chosen.length * 80)
  }
  return (
    <>
      <div className="rd-head">
        <div className="stack gap-4" style={{ flex: 1 }}>
          <span className="t-title3">Approve {rows.length} recommended resolutions</span>
          <span className="t-sub">Scan the list, untick anything unusual to review on its own, then approve the rest in one go.</span>
        </div>
        <button className="icon-btn" onClick={closeResolve} aria-label="Close"><X size={18} /></button>
      </div>
      <div className="rd-body" style={{ gap: 0 }}>
        {rows.map(({ i, p, r }, k) => {
          const on = sel.has(i.id)
          const sent = phase === 'sending' && on && chosen.findIndex((c) => c.i.id === i.id) < done
          return (
            <motion.button key={i.id} className="rd-mrow" onClick={() => phase === 'idle' && r.outcome !== 'navigate' && setSel((s) => { const n = new Set(s); n.has(i.id) ? n.delete(i.id) : n.add(i.id); return n })}
              initial={{ opacity: 0, x: 10 }} animate={{ opacity: 1, x: 0 }} transition={{ ...springSnappy, delay: Math.min(k, 12) * 0.03 }}>
              {sent ? <span className="check on" style={{ background: 'var(--green)' }}><CheckIcon size={12} strokeWidth={3.2} /></span> : <Check on={on} />}
              <span className="stack min0" style={{ flex: 1 }}>
                <span className="strong ellipsis" style={{ fontSize: 13.5 }}>{p.street} <span className="t-caption">· {p.city}, {p.state} · {p.investor}</span></span>
                <span className="t-caption ellipsis">{r.title} · {i.days} {unitOf(i)}</span>
                <span className="ellipsis" style={{ fontSize: 13, color: 'var(--label-2)' }}>→ {r.decision}</span>
              </span>
              <span className="pill" data-tone={r.outcome === 'done' ? 'mint' : r.outcome === 'navigate' ? 'gray' : 'sky'}>{r.outcome === 'done' ? 'Writes to Equator' : r.outcome === 'navigate' ? 'Review on its own' : r.to.split('<')[0].trim()}</span>
            </motion.button>
          )
        })}
      </div>
      <div className="rd-foot">
        <motion.button className="btn btn-primary btn-lg" disabled={!chosen.length || phase !== 'idle'} whileTap={{ scale: 0.97 }} onClick={go}>
          {phase === 'idle' ? `Approve & send ${chosen.length}` : `Working ${done}/${chosen.length}…`}
        </motion.button>
        <span className="t-caption">{emails} message{emails === 1 ? '' : 's'} · {writes} Equator update{writes === 1 ? '' : 's'} · each logged to its property</span>
        <span className="spacer" />
        <button className="btn btn-gray" onClick={closeResolve}>Cancel</button>
      </div>
    </>
  )
}
