import { useMemo, useState } from 'react'
import { AnimatePresence, motion } from 'framer-motion'
import { ArrowDownUp, ArrowRight, ChevronDown, Clock, Handshake, Inbox, Send, Timer, X } from 'lucide-react'
import { inClient, useApp } from '../lib/store'
import { navigate } from '../lib/router'
import { PROPERTIES, SIGNALS, propertyById, signalDef, type WorkItem } from '../data/mock'
import { STAGES, exceptionScore, isLiveOffer, overBy, severityOf, stageOf, unitOf, type Stage } from '../data/workflow'
import { fadeUp, inView, spring, springSnappy, stagger } from '../lib/motion'
import { AnimatedNumber, Check, Segmented } from '../components/ui'
import { originOf } from './actions'
import { SignalTile } from './today'
import { SIGNAL_TONE } from './BatchSheet'

/** One clean header row: title + count on the left, controls on the right. */
function SectionHead({ title, count, children }: { title: string; count?: number; children?: React.ReactNode }) {
  return (
    <div className="sec-head">
      <div className="sec-title"><h2 className="t-title2">{title}</h2>{count != null && <span className="sec-count num">{count}</span>}</div>
      {children && <div className="sec-tools">{children}</div>}
    </div>
  )
}

/** Items visible under the current client filter. */
export function useScopedItems() {
  const items = useApp((s) => s.items)
  const client = useApp((s) => s.clientFilter)
  return useMemo(() => items.filter((i) => inClient(client, propertyById(i.propertyId).investor)), [items, client])
}

/* ------------------------------------------------------------ stage strip (mockup) */
export function StageStrip({ active, onPick, mode = 'browse' }: { active: Stage | null; onPick: (s: Stage | null, info?: { exc: number; ready: number }) => void; mode?: 'act' | 'browse' }) {
  const items = useScopedItems()
  const client = useApp((s) => s.clientFilter)
  const counts = useMemo(() => {
    const m = new Map<Stage, { n: number; exc: number; due: number; ready: number }>()
    STAGES.forEach((s) => m.set(s, { n: 0, exc: 0, due: 0, ready: 0 }))
    const seenExc = new Set<string>()
    for (const p of PROPERTIES) { const st = stageOf(p); if (st && inClient(client, p.investor)) m.get(st)!.n++ }
    for (const i of items) {
      const st = stageOf(propertyById(i.propertyId)); if (!st) continue
      if (i.queue === 'exceptions' && !seenExc.has(i.propertyId)) { m.get(st)!.exc++; seenExc.add(i.propertyId) }
      if (i.queue === 'actions' && i.advance && !i.actToday) m.get(st)!.ready++
      if (i.queue === 'watch' && i.days >= i.slaDays - 1) m.get(st)!.due++
    }
    return m
  }, [items, client])
  const pill = { height: 18, fontSize: 10.5, padding: '0 6px' }
  return (
    <div className={`stage-strip ${mode === 'act' ? 'act' : ''}`} role="group" aria-label={mode === 'act' ? 'Jump to work by stage' : 'Portfolio by stage'}>
      {STAGES.map((s) => {
        const c = counts.get(s)!
        const on = active === s
        const idle = mode === 'act' && c.exc + c.ready === 0
        return (
          <motion.button key={s} className={`stage-cell ${on ? 'on' : ''} ${idle ? 'idle' : ''}`} disabled={idle && !on}
            onClick={() => onPick(on ? null : s, { exc: c.exc, ready: c.ready })} whileTap={idle ? undefined : { scale: 0.97 }} aria-pressed={on}
            title={idle ? `Nothing to act on in ${s}` : mode === 'act' ? `Show ${s} exceptions and decisions` : undefined}>
            <span className="sc-name">{s}</span>
            <span className="sc-n"><AnimatedNumber value={c.n} /></span>
            <span className="hstack gap-4 wrap">
              {c.exc > 0 && <span className="pill" data-tone="rose" style={pill}>{c.exc} exc</span>}
              {mode === 'act'
                ? c.ready > 0 && <span className="pill" data-tone="mint" style={pill}>{c.ready} ready</span>
                : c.due > 0 && <span className="pill" data-tone="sand" style={pill}>{c.due} due</span>}
              {idle && <span className="sc-idle">No action</span>}
            </span>
            {on && <motion.span layoutId="stage-on" className="stage-on" transition={springSnappy} />}
          </motion.button>
        )
      })}
    </div>
  )
}

/* ------------------------------------------------------------ Step 1 · exceptions with resolutions */
export function ExceptionCenter({ stage, onClearStage }: { stage: Stage | null; onClearStage?: () => void }) {
  const scoped = useScopedItems()
  const openResolve = useApp((s) => s.openResolve)
  const [view, setView] = useState<'top' | 'type' | 'all'>('top')
  const [sort, setSort] = useState<'severity' | 'days'>('severity')
  const [picked, setPicked] = useState<Set<string>>(new Set())
  const exc = useMemo(() => scoped.filter((i) => i.queue === 'exceptions' && (!stage || stageOf(propertyById(i.propertyId)) === stage))
    .sort((a, b) => (sort === 'severity' ? exceptionScore(b) - exceptionScore(a) : overBy(b) - overBy(a))), [scoped, stage, sort])
  const shown = view === 'top' ? exc.slice(0, 15) : exc
  const toggle = (id: string) => setPicked((s) => { const n = new Set(s); n.has(id) ? n.delete(id) : n.add(id); return n })
  const pickedList = shown.filter((i) => picked.has(i.id))
  const allOn = shown.length > 0 && shown.every((i) => picked.has(i.id))

  return (
    <section className="stack gap-14" id="exceptions" style={{ scrollMarginTop: 80 }}>
      <SectionHead title="Exceptions" count={exc.length}>
        {stage && <button className="filter-chip" onClick={onClearStage}>{stage}<X size={12} /></button>}
        <Segmented layoutId="exc-view" size="sm" value={view} onChange={(v) => { setView(v); setPicked(new Set()) }} items={[{ key: 'top', label: 'Top 15' }, { key: 'type', label: 'By type' }, { key: 'all', label: 'All' }]} />
        {view !== 'type' && (
          <label className="sort-select" title="Sort exceptions">
            <ArrowDownUp size={13} />
            <select value={sort} onChange={(e) => setSort(e.target.value as 'severity' | 'days')} aria-label="Sort">
              <option value="severity">Severity</option>
              <option value="days">Most days over</option>
            </select>
            <ChevronDown size={12} />
          </label>
        )}
      </SectionHead>

      {view === 'type' ? (
        <motion.div className="signals" variants={stagger(0.05)} initial="hidden" whileInView="show" viewport={inView}>
          {SIGNALS.filter((d) => exc.some((i) => i.signal === d.key)).sort((a, b) => exc.filter((i) => i.signal === b.key).length - exc.filter((i) => i.signal === a.key).length)
            .map((d) => <SignalTile key={d.key} def={d} items={exc} />)}
        </motion.div>
      ) : (
        <div className="card" style={{ overflow: 'hidden' }}>
          <div className="xrow head">
            <span><Check on={allOn} onClick={() => setPicked(allOn ? new Set() : new Set(shown.map((i) => i.id)))} label="Select all" /></span>
            <span /><span>Exception</span><span>Property</span><span>Over SLA</span><span>Recommended resolution</span><span />
          </div>
          <AnimatePresence initial={false} mode="popLayout">
            {shown.map((i, k) => <ExceptionRow key={i.id} i={i} k={k} picked={picked.has(i.id)} onPick={() => toggle(i.id)} onOpen={(e) => openResolve({ itemIds: [i.id], origin: originOf(e) })} />)}
          </AnimatePresence>
          {!shown.length && <div className="empty"><Inbox size={28} /><span className="t-headline" style={{ color: 'var(--label)' }}>All clear{stage ? ` in ${stage}` : ''}</span><span className="t-sub">New exceptions appear here the moment a follow-up point passes.</span></div>}
          {view === 'top' && exc.length > 15 && (
            <button className="xmore" onClick={() => setView('all')}>Show all {exc.length} exceptions <ArrowRight size={14} /></button>
          )}
        </div>
      )}

      <AnimatePresence>
        {pickedList.length > 0 && (
          <motion.div className="bulkbar" initial={{ y: 80, opacity: 0, x: '-50%' }} animate={{ y: 0, opacity: 1, x: '-50%' }} exit={{ y: 80, opacity: 0, x: '-50%' }} transition={{ type: 'spring', bounce: 0.2, duration: 0.45 }}>
            <span className="strong num">{pickedList.length} selected</span>
            <button className="btn btn-primary" onClick={(e) => { openResolve({ itemIds: pickedList.map((i) => i.id), origin: originOf(e) }); setPicked(new Set()) }}><Send size={14} />Review & approve {pickedList.length}</button>
            <button className="btn btn-plain" onClick={() => setPicked(new Set())}>Cancel</button>
          </motion.div>
        )}
      </AnimatePresence>
    </section>
  )
}

function ExceptionRow({ i, k, picked, onPick, onOpen }: { i: WorkItem; k: number; picked: boolean; onPick: () => void; onOpen: (e: React.MouseEvent) => void }) {
  const p = propertyById(i.propertyId)
  const def = i.signal ? signalDef(i.signal) : null
  const sev = severityOf(i)
  const tone = i.signal ? SIGNAL_TONE[i.signal] : 'gray'
  return (
    <motion.div layout="position" className={`xrow ${picked ? 'sel' : ''}`} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0, transition: { ...spring, delay: Math.min(k, 12) * 0.02 } }}
      exit={{ opacity: 0, x: 60, transition: { duration: 0.28, ease: [0.32, 0.72, 0, 1] } }} onClick={onOpen} role="button" tabIndex={0} onKeyDown={(e) => { if (e.key === 'Enter') onOpen(e as unknown as React.MouseEvent) }}>
      <span onClick={(e) => { e.stopPropagation(); onPick() }}><Check on={picked} /></span>
      <span className="risk-bar" data-tone={sev === 'Critical' ? 'rose' : 'sand'} title={sev} />
      <span className="stack min0">
        <span className="strong ellipsis" style={{ fontSize: 13.5 }}>{def?.title ?? i.reason}</span>
        <span className="t-caption ellipsis">{i.detail}</span>
      </span>
      <span className="stack min0">
        <span className="ellipsis" style={{ fontSize: 13.5, fontWeight: 600 }}>{p.street}</span>
        <span className="t-caption ellipsis">{p.city}, {p.state} · {p.investor} · {stageOf(p)}</span>
      </span>
      <span className="stack" data-tone={sev === 'Critical' ? 'rose' : 'sand'}>
        <span className="days" style={{ fontSize: 17 }}>+{overBy(i)}<span style={{ fontSize: 11, fontWeight: 600 }}> {unitOf(i)}</span></span>
        <span className="t-caption" style={{ fontSize: 11 }}>{sev}</span>
      </span>
      <span className="stack min0">
        <span className="ellipsis" style={{ fontSize: 13 }}>{def?.resolution ?? i.nextAction}</span>
        <span className="hstack gap-6 t-caption min0"><span className="kind-dot" data-tone={def?.kind === 'advance' ? 'mint' : 'gray'} /><span className="ellipsis">{def?.kind === 'advance' ? 'Moves file forward' : 'Saves admin time'} · {def?.agent ?? 'Agent'}</span></span>
      </span>
      <span className="xrow-act">
        <motion.button className="btn btn-sm btn-tone" data-tone={tone} whileTap={{ scale: 0.95 }} onClick={(e) => { e.stopPropagation(); onOpen(e) }}>{def?.action ?? 'Review'}</motion.button>
      </span>
    </motion.div>
  )
}

/* ------------------------------------------------------------ Step 2 · ready to advance */
const FORWARD = ['Offer recommendation ready', 'Reduction case ready', 'Values ready to agree', 'Ready to list', 'Marketing plan ready', 'Equator task to complete']
export function AdvanceCenter({ stage, onClearStage }: { stage?: Stage | null; onClearStage?: () => void } = {}) {
  const scoped = useScopedItems()
  const openResolve = useApp((s) => s.openResolve)
  const adv = scoped.filter((i) => i.queue === 'actions' && i.advance && !i.actToday && (!stage || stageOf(propertyById(i.propertyId)) === stage))
  const groups = Array.from(new Set(adv.map((i) => i.advance!))).sort((a, b) => (FORWARD.includes(b) ? 1 : 0) - (FORWARD.includes(a) ? 1 : 0))
  const block = (label: string, list: string[]) => list.length > 0 && (
    <div className="stack gap-10">
      <span className="t-eyebrow" style={{ paddingTop: 6 }}>{label}</span>
      <div className="adv-grid">
        {list.map((g) => {
          const its = adv.filter((i) => i.advance === g)
          return (
            <motion.div key={g} className="card adv-card" variants={fadeUp} layout>
              <div className="hstack gap-8">
                <span className="t-headline" style={{ flex: 1 }}>{g}</span>
                <span className="pill" data-tone={FORWARD.includes(g) ? 'mint' : 'gray'}>{its.length}</span>
                {its.length > 1 && <button className="btn btn-sm btn-tinted" onClick={(e) => openResolve({ itemIds: its.map((i) => i.id), origin: originOf(e) })}>Review all {its.length}</button>}
              </div>
              <AnimatePresence initial={false}>
                {its.map((i) => {
                  const p = propertyById(i.propertyId)
                  return (
                    <motion.button key={i.id} className="adv-row" layout initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0, height: 0 }} onClick={(e) => openResolve({ itemIds: [i.id], origin: originOf(e) })}>
                      <span className="stack min0" style={{ flex: 1 }}>
                        <span className="strong ellipsis" style={{ fontSize: 13.5 }}>{p.street}</span>
                        <span className="t-caption ellipsis">{p.city}, {p.state} · {p.investor} · {i.detail}</span>
                      </span>
                      <span className="btn btn-sm btn-gray">{i.nextAction}</span>
                    </motion.button>
                  )
                })}
              </AnimatePresence>
            </motion.div>
          )
        })}
      </div>
    </div>
  )
  return (
    <section className="stack gap-14" id="advance" style={{ scrollMarginTop: 80 }}>
      <SectionHead title="Ready to advance" count={adv.length}>
        {stage && <button className="filter-chip" onClick={onClearStage}>{stage}<X size={12} /></button>}
      </SectionHead>
      {!adv.length && <div className="card empty" style={{ padding: 28 }}><span className="t-sub">Nothing to advance{stage ? ` in ${stage}` : ''} right now.</span></div>}
      <motion.div className="stack gap-16" variants={stagger(0.05)} initial="hidden" whileInView="show" viewport={inView}>
        {block('Moves file forward', groups.filter((g) => FORWARD.includes(g)))}
        {block('Saves admin time', groups.filter((g) => !FORWARD.includes(g)))}
      </motion.div>
    </section>
  )
}

/* ------------------------------------------------------------ Step 3 · track */
export function TrackStrip() {
  const scoped = useScopedItems()
  const awaiting = scoped.filter((i) => i.queue === 'watch')
  const late = awaiting.filter((i) => i.days > i.slaDays).length
  const investor = scoped.filter((i) => i.queue === 'approvals' || (i.queue === 'exceptions' && i.signal === 'investor'))
  const due = investor.filter((i) => i.queue === 'exceptions').length
  const offers = scoped.filter(isLiveOffer).length
  const cards = [
    { icon: Clock, tone: 'sky', t: 'Awaiting response', v: awaiting.length, s: late ? `${late} late` : 'Returns to exceptions if late', to: '/awaiting' },
    { icon: Timer, tone: 'lavender', t: 'Investor follow-ups', v: investor.length, s: due ? `${due} nudges due today` : 'No nudges due', to: '/followups' },
    { icon: Handshake, tone: 'mint', t: 'Live offers', v: offers, s: 'Approve, counter or execute', to: '/offers' },
  ]
  return (
    <section className="stack gap-14">
      <SectionHead title="Follow-ups and offers" />
      <div className="track-grid">
        {cards.map((c) => (
          <motion.button key={c.t} className="card track-card" data-tone={c.tone} whileHover={{ y: -2 }} transition={spring} onClick={() => navigate(c.to)}>
            <span className="rec-ico" data-tone={c.tone}><c.icon size={18} /></span>
            <span className="stack" style={{ flex: 1 }}><span className="t-headline">{c.t}</span><span className="t-caption">{c.s}</span></span>
            <span className="round" style={{ fontSize: 28, fontWeight: 750 }}><AnimatedNumber value={c.v} /></span>
            <ArrowRight size={16} className="t-3" />
          </motion.button>
        ))}
      </div>
    </section>
  )
}
