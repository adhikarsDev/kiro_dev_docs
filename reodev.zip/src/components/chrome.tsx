import { useEffect, useMemo, useRef, useState } from 'react'
import { AnimatePresence, motion, useScroll, useTransform } from 'framer-motion'
import {
  Bot, Building2, Clock, Handshake, Timer, ChartColumn, ChevronDown, CircleCheck, House, Inbox, Info, Moon,
  RefreshCw, Search, Sparkles, Sun, TriangleAlert, Undo2, X, CornerDownLeft, User, LogOut, SlidersHorizontal,
} from 'lucide-react'
import { navigate, type Route } from '../lib/router'
import { countBy, inClient, useApp } from '../lib/store'
import { PROPERTIES, SIGNALS, ALL_SCOPE, CLIENTS, phaseLabel, propertyById } from '../data/mock'
import { spring, springSheet, springSnappy } from '../lib/motion'
import { Segmented } from './ui'

const NAV = [
  { key: 'today', label: 'Today', icon: House, path: '/' },
  { key: 'work', label: 'My Work', icon: Inbox, path: '/work' },
  { key: 'properties', label: 'Properties', icon: Building2, path: '/properties' },
  { key: 'offers', label: 'Offers', icon: Handshake, path: '/offers' },
  { key: 'followups', label: 'Investor follow-ups', icon: Timer, path: '/followups' },
  { key: 'awaiting', label: 'Awaiting response', icon: Clock, path: '/awaiting' },
  { key: 'recs', label: 'Recommendations', icon: Sparkles, path: '/recs' },
  { key: 'agents', label: 'AI Agents', icon: Bot, path: '/agents' },
  { key: 'portfolio', label: 'Portfolio', icon: ChartColumn, path: '/portfolio' },
] as const

function activeKey(r: Route) {
  if (r.name === 'property') return 'properties'
  if (r.name === 'rec' || r.name === 'approval') return 'recs'
  return r.name
}

export function BrandMark({ size = 18 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" aria-hidden>
      <path d="M12 3.2a8.8 8.8 0 0 1 8.8 8.8" stroke="currentColor" strokeWidth="2" strokeLinecap="round" opacity=".55" />
      <path d="M12 6.6A5.4 5.4 0 0 1 17.4 12" stroke="currentColor" strokeWidth="2" strokeLinecap="round" opacity=".8" />
      <path d="M8 21V12.5L12 9.8l4 2.7V21" stroke="currentColor" strokeWidth="2" strokeLinejoin="round" />
      <path d="M10.6 21v-4h2.8v4" stroke="currentColor" strokeWidth="2" strokeLinejoin="round" />
    </svg>
  )
}

export function Sidebar({ route }: { route: Route }) {
  const allItems = useApp((s) => s.items)
  const client = useApp((s) => s.clientFilter)
  const items = useMemo(() => allItems.filter((i) => inClient(client, propertyById(i.propertyId).investor)), [allItems, client])
  const c = countBy(items)
  const invDue = items.filter((i) => i.queue === 'exceptions' && i.signal === 'investor').length
  const active = activeKey(route)
  return (
    <aside className="sidebar" aria-label="Primary">
      <div className="brand">
        <div className="brand-mark"><BrandMark /></div>
        <div className="hide-narrow">
          <div className="brand-name">Real Estate</div>
          <div className="brand-sub">CONTROL TOWER</div>
        </div>
      </div>
      <nav className="stack gap-4">
        {NAV.map((n) => {
          const Icon = n.icon
          const on = active === n.key
          const badge = n.key === 'work' ? c.exceptions : n.key === 'recs' ? 5 : n.key === 'followups' ? invDue : null
          return (
            <motion.button key={n.key} className="nav-item" onClick={() => navigate(n.path)} whileTap={{ scale: 0.97 }} aria-current={on ? 'page' : undefined} title={n.label}>
              <span className="nav-bg-hover" />
              {on && <motion.span layoutId="nav-active" className="nav-active-bg" transition={spring} />}
              <Icon size={18} strokeWidth={2} />
              <span className="hide-narrow">{n.label}</span>
              {badge != null && badge > 0 && (
                <span className={`nav-badge ${n.key !== 'work' ? 'soft' : ''}`}>{badge}</span>
              )}
            </motion.button>
          )
        })}
      </nav>
    </aside>
  )
}

export function Toolbar() {
  const { theme, toggleTheme, scope, setScope, setPaletteOpen, clientFilter, setClientFilter } = useApp()
  const { scrollY } = useScroll()
  const edge = useTransform(scrollY, [0, 24], [0, 1])
  const [spin, setSpin] = useState(0)
  return (
    <header className="toolbar">
      <motion.div className="toolbar-edge" style={{ opacity: edge }} />
      <button className="searchbox" onClick={() => setPaletteOpen(true)} aria-label="Search">
        <Search size={15} />
        <span style={{ flex: 1, textAlign: 'left' }}>Search properties, loan #, or actions</span>
        <span className="kbd">⌘</span><span className="kbd">K</span>
      </button>
      <div className="spacer" />
      <label className={`client-select ${clientFilter !== 'all' ? 'on' : ''}`} title="Filter every view by client">
        <Building2 size={14} />
        <select value={clientFilter} onChange={(e) => setClientFilter(e.target.value)} aria-label="Client">
          <option value="all">All clients</option>
          {CLIENTS.map((cl) => <option key={cl} value={cl}>{cl}</option>)}
        </select>
        <ChevronDown size={13} />
      </label>
      <Segmented
        layoutId="scope-thumb"
        size="sm"
        value={scope}
        onChange={setScope}
        items={[
          { key: 'mine', label: 'My Properties' },
          { key: 'all', label: `All · ${ALL_SCOPE.total.toLocaleString()}` },
        ]}
      />
      <motion.button className="icon-btn" aria-label="Refresh data (last refreshed 9:50 AM)" title="Refreshed 9:50 AM" onClick={() => setSpin((s) => s + 1)}
        animate={{ rotate: spin * 360 }} transition={{ type: 'spring', bounce: 0, duration: 0.8 }}>
        <RefreshCw size={17} />
      </motion.button>
      <button className="icon-btn" aria-label="Toggle appearance" onClick={toggleTheme}>
        <AnimatePresence mode="wait" initial={false}>
          <motion.span key={theme} initial={{ rotate: -90, opacity: 0, scale: 0.6 }} animate={{ rotate: 0, opacity: 1, scale: 1 }} exit={{ rotate: 90, opacity: 0, scale: 0.6 }} transition={springSnappy}>
            {theme === 'dark' ? <Sun size={18} /> : <Moon size={18} />}
          </motion.span>
        </AnimatePresence>
      </button>
      <ProfileMenu />
    </header>
  )
}

const NOTES = [
  { tone: 'rose', title: '5 properties missing valuations past 10 days', time: '1 h ago' },
  { tone: 'peach', title: '3 trash-outs pending past 15 days', time: '2 h ago' },
  { tone: 'lavender', title: 'Investor response times rising (avg 16 days)', time: '3 h ago' },
  { tone: 'sky', title: 'SPS guideline SPS-LPR-2.3 published', time: 'Yesterday' },
]

/** One compact control for identity + notifications (single line, everything else in the menu). */
function ProfileMenu() {
  const [open, setOpen] = useState(false)
  const [unread, setUnread] = useState(NOTES.length)
  const ref = useRef<HTMLDivElement>(null)
  useEffect(() => {
    if (!open) return
    const close = (e: MouseEvent) => { if (!ref.current?.contains(e.target as Node)) setOpen(false) }
    const esc = (e: KeyboardEvent) => { if (e.key === 'Escape') setOpen(false) }
    window.addEventListener('mousedown', close); window.addEventListener('keydown', esc)
    return () => { window.removeEventListener('mousedown', close); window.removeEventListener('keydown', esc) }
  }, [open])
  return (
    <div ref={ref} style={{ position: 'relative', marginLeft: 2 }}>
      <button className="profile-btn" onClick={() => setOpen((v) => !v)} aria-haspopup="menu" aria-expanded={open} aria-label={`Srini, ${unread} notifications`}>
        <span className="avatar" style={{ position: 'relative' }}>
          S
          <AnimatePresence>{unread > 0 && <motion.span className="avatar-badge" initial={{ scale: 0 }} animate={{ scale: 1 }} exit={{ scale: 0 }} transition={springSnappy}>{unread}</motion.span>}</AnimatePresence>
        </span>
        <span className="strong who" style={{ fontSize: 13.5 }}>Srini</span>
        <motion.span animate={{ rotate: open ? 180 : 0 }} transition={springSnappy} style={{ display: 'grid' }}><ChevronDown size={14} className="t-3" /></motion.span>
      </button>
      <AnimatePresence>
        {open && (
          <motion.div className="menu" role="menu" style={{ width: 340 }} initial={{ opacity: 0, scale: 0.94, y: -6, filter: 'blur(6px)' }} animate={{ opacity: 1, scale: 1, y: 0, filter: 'blur(0px)' }}
            exit={{ opacity: 0, scale: 0.96, y: -4, filter: 'blur(4px)' }} transition={springSheet}>
            <div className="hstack gap-10" style={{ padding: '8px 10px 12px' }}>
              <span className="avatar" style={{ width: 40, height: 40, fontSize: 15 }}>S</span>
              <span className="stack" style={{ flex: 1 }}><span className="strong">Srini</span><span className="t-caption">Asset Manager · SPS book · 236 files</span></span>
            </div>
            <div className="hstack" style={{ padding: '4px 10px 6px' }}>
              <span className="t-eyebrow" style={{ flex: 1 }}>Notifications</span>
              {unread > 0 && <button className="btn-plain" style={{ fontSize: 12, fontWeight: 600, color: 'var(--blue-text)' }} onClick={() => setUnread(0)}>Mark all read</button>}
            </div>
            <div className="stack" style={{ padding: '0 4px 6px' }}>
              {NOTES.map((n, i) => (
                <div key={n.title} className="note-row">
                  <span className="status-dot" data-tone={n.tone} style={{ opacity: i < unread ? 1 : 0.25 }} />
                  <span className="stack min0" style={{ flex: 1 }}>
                    <span style={{ fontSize: 13, fontWeight: i < unread ? 600 : 500 }}>{n.title}</span>
                    <span className="t-caption">{n.time}</span>
                  </span>
                </div>
              ))}
            </div>
            <div className="hairline" style={{ margin: '2px 6px 6px' }} />
            {[[User, 'My profile'], [SlidersHorizontal, 'Signal thresholds & alerts'], [LogOut, 'Sign out']].map(([Icon, l]) => {
              const I = Icon as typeof User
              return <button key={l as string} className="menu-item" role="menuitem" onClick={() => setOpen(false)}><I size={15} />{l as string}</button>
            })}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  )
}

export function Toaster() {
  const { toasts, dismissToast } = useApp()
  const drawerOpen = useApp((s) => !!s.resolve)
  return (
    <div className={`toasts ${drawerOpen ? 'beside-drawer' : ''}`} aria-live="polite">
      <AnimatePresence initial={false}>
        {toasts.map((t) => (
          <motion.div key={t.id} layout className="toast" initial={{ opacity: 0, y: 24, scale: 0.94, filter: 'blur(8px)' }}
            animate={{ opacity: 1, y: 0, scale: 1, filter: 'blur(0px)' }} exit={{ opacity: 0, y: 12, scale: 0.96, filter: 'blur(6px)' }} transition={springSheet}>
            <span style={{ color: t.tone === 'warn' ? '#ffd60a' : t.tone === 'info' ? '#64d2ff' : '#30d158', display: 'grid' }}>
              {t.tone === 'warn' ? <TriangleAlert size={20} /> : t.tone === 'info' ? <Info size={20} /> : <CircleCheck size={20} />}
            </span>
            <div className="stack" style={{ flex: 1, minWidth: 0 }}>
              <span className="tt">{t.title}</span>
              {t.body && <span className="tb">{t.body}</span>}
            </div>
            {t.undo && (
              <button className="btn btn-sm btn-glass" onClick={() => { t.undo!(); dismissToast(t.id) }}><Undo2 size={13} />Undo</button>
            )}
            <button className="icon-btn" style={{ width: 28, height: 28, color: 'rgba(255,255,255,.7)' }} onClick={() => dismissToast(t.id)} aria-label="Dismiss"><X size={15} /></button>
          </motion.div>
        ))}
      </AnimatePresence>
    </div>
  )
}

type PalItem = { id: string; label: string; sub?: string; group: string; run: () => void }

export function CommandPalette() {
  const { paletteOpen, setPaletteOpen, openBatch, toggleTheme, items } = useApp()
  const [q, setQ] = useState('')
  const [idx, setIdx] = useState(0)
  const inputRef = useRef<HTMLInputElement>(null)

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') { e.preventDefault(); setPaletteOpen(!useApp.getState().paletteOpen) }
    }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [setPaletteOpen])
  useEffect(() => { if (paletteOpen) { setQ(''); setIdx(0); setTimeout(() => inputRef.current?.focus(), 30) } }, [paletteOpen])

  const results = useMemo<PalItem[]>(() => {
    const close = () => setPaletteOpen(false)
    const actions: PalItem[] = [
      ...SIGNALS.map((s) => {
        const n = items.filter((i) => i.queue === 'exceptions' && i.signal === s.key).length
        return { id: `a-${s.key}`, group: 'Actions', label: s.cta(n), sub: `${s.title} · ${n} files`, run: () => { close(); if (n) openBatch({ signal: s.key }) } }
      }),
      { id: 'a-theme', group: 'Actions', label: 'Toggle light / dark appearance', run: () => { close(); toggleTheme() } },
    ]
    const pages: PalItem[] = NAV.map((n) => ({ id: `p-${n.key}`, group: 'Go to', label: n.label, run: () => { close(); navigate(n.path) } }))
    const term = q.trim().toLowerCase()
    const props: PalItem[] = PROPERTIES.filter((p) => !term || `${p.street} ${p.city} ${p.state} ${p.loan} ${p.investor}`.toLowerCase().includes(term))
      .slice(0, term ? 8 : 4)
      .map((p) => ({ id: p.id, group: 'Properties', label: `${p.street}, ${p.city} ${p.state}`, sub: `${p.loan} · ${p.investor} · ${phaseLabel(p.phase)}`, run: () => { close(); navigate(`/property/${p.id}`) } }))
    const all = [...actions, ...pages].filter((a) => !term || a.label.toLowerCase().includes(term) || a.sub?.toLowerCase().includes(term))
    return [...(term ? props : []), ...all, ...(term ? [] : props)]
  }, [q, items, openBatch, setPaletteOpen, toggleTheme])

  const onKey = (e: React.KeyboardEvent) => {
    if (e.key === 'ArrowDown') { e.preventDefault(); setIdx((i) => Math.min(results.length - 1, i + 1)) }
    if (e.key === 'ArrowUp') { e.preventDefault(); setIdx((i) => Math.max(0, i - 1)) }
    if (e.key === 'Enter') results[idx]?.run()
    if (e.key === 'Escape') setPaletteOpen(false)
  }

  let lastGroup = ''
  return (
    <AnimatePresence>
      {paletteOpen && (
        <>
          <motion.div key="scrim" className="scrim" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={() => setPaletteOpen(false)} />
          <div className="sheet-wrap" key="wrap">
            <motion.div className="palette" initial={{ opacity: 0, scale: 0.96, y: -8, filter: 'blur(10px)' }} animate={{ opacity: 1, scale: 1, y: 0, filter: 'blur(0px)' }}
              exit={{ opacity: 0, scale: 0.97, y: -6, filter: 'blur(8px)' }} transition={springSheet} role="dialog" aria-label="Command palette">
              <div style={{ position: 'relative' }}>
                <Search size={18} style={{ position: 'absolute', left: 18, top: 19, color: 'var(--label-3)' }} />
                <input ref={inputRef} value={q} onChange={(e) => { setQ(e.target.value); setIdx(0) }} onKeyDown={onKey} placeholder="Search properties, loan #, or run an action…" />
              </div>
              <div className="hairline" />
              <div style={{ maxHeight: 420, overflow: 'auto', padding: '6px 0 8px' }}>
                {results.map((r, i) => {
                  const head = r.group !== lastGroup ? (lastGroup = r.group) : null
                  return (
                    <div key={r.id}>
                      {head && <div className="t-eyebrow" style={{ padding: '10px 20px 4px' }}>{head}</div>}
                      <button className={`pal-item ${i === idx ? 'on' : ''}`} onMouseEnter={() => setIdx(i)} onClick={r.run}>
                        <span style={{ flex: 1, minWidth: 0 }} className="stack">
                          <span className="ellipsis">{r.label}</span>
                          {r.sub && <span className="t-caption ellipsis">{r.sub}</span>}
                        </span>
                        {i === idx && <CornerDownLeft size={14} />}
                      </button>
                    </div>
                  )
                })}
                {!results.length && <div className="empty">No matches</div>}
              </div>
            </motion.div>
          </div>
        </>
      )}
    </AnimatePresence>
  )
}

/** Quiet, app-wide footer: identity, data freshness and the few links people look for. */
export function AppFooter() {
  return (
    <footer className="app-footer">
      <div className="app-footer-inner">
        <span className="brand-mini"><span><BrandMark size={13} /></span>Real Estate Control Tower</span>
        <span className="spacer" />
        <nav aria-label="Footer">
          <a onClick={() => navigate('/portfolio')}>Portfolio analytics</a>
          <a>Help</a>
          <a>Privacy</a>
        </nav>
        <span>© 2026 · v0.4 POC</span>
      </div>
    </footer>
  )
}
