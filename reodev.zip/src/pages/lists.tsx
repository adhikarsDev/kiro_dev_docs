import { useMemo, useState } from 'react'
import { motion } from 'framer-motion'
import { Search } from 'lucide-react'
import { navigate } from '../lib/router'
import { inClient, useApp } from '../lib/store'
import { PROPERTIES, money, signalDef, type WorkItem } from '../data/mock'
import { overBy, stageOf, unitOf, type Stage } from '../data/workflow'
import { StageStrip } from '../features/command'
import { ADVANCE_RULES } from '../features/resolution'
import { fadeUp } from '../lib/motion'
import { Segmented } from '../components/ui'
import { WorkQueue } from '../features/WorkQueue'

export function MyWork() {
  return (
    <div className="page">
      <motion.div className="stack gap-4" variants={fadeUp} initial="hidden" animate="show">
        <span className="t-large">My Work</span>
        <span className="t-sub" style={{ fontSize: 14.5 }}>Every file that needs you, across all phases. Select rows to batch a follow-up, snooze or reassign.</span>
      </motion.div>
      <WorkQueue selectable search paginate />
    </div>
  )
}

type PStatus = 'Overdue' | 'Action today' | 'Ready' | 'Check-in due' | 'Waiting' | 'On track'
const P_TONE: Record<PStatus, string> = { Overdue: 'rose', 'Action today': 'mint', Ready: 'sky', 'Check-in due': 'sand', Waiting: 'lavender', 'On track': 'gray' }
const STAGE_AGENT: Record<Stage, string> = {
  Intake: 'Pre-Marketing Agent', Occupancy: 'Pre-Marketing Agent', 'Eviction (ESD)': 'CFK / Eviction Agent', Preservation: 'Preservation Agent',
  Valuation: 'BPO Review Agent', Listing: 'Complete Marketing Plan Agent', 'On market': 'Review Marketing Plan Agent', Offers: 'Offer Acceptance Agent',
  'Under contract': 'Closing Monitor', Closing: 'Closing Monitor',
}
const Q_ORDER = { exceptions: 0, actions: 1, approvals: 2, watch: 3 } as const

export function Properties() {
  const items = useApp((s) => s.items)
  const client = useApp((s) => s.clientFilter)
  const [stage, setStage] = useState<Stage | null>(null)
  const [occ, setOcc] = useState<'all' | 'Vacant' | 'Occupied'>('all')
  const [chip, setChip] = useState<PStatus | 'all'>('all')
  const [q, setQ] = useState('')
  const [n, setN] = useState(40)

  // The most urgent open item per property drives its status and next action.
  const top = useMemo(() => {
    const m = new Map<string, WorkItem>()
    const w = (i: WorkItem) => Q_ORDER[i.queue] * 2 - (i.actToday ? 1 : 0)
    items.forEach((i) => { const c = m.get(i.propertyId); if (!c || w(i) < w(c)) m.set(i.propertyId, i) })
    return m
  }, [items])
  const statusOf = (pid: string): PStatus => {
    const i = top.get(pid)
    if (!i) return 'On track'
    if (i.queue === 'exceptions') return 'Overdue'
    if (i.queue === 'actions') return i.actToday ? 'Action today' : 'Ready'
    if (i.queue === 'watch' && i.days >= i.slaDays - 1) return 'Check-in due'
    return 'Waiting'
  }
  const base = useMemo(() => PROPERTIES.filter((p) => p.phase !== 'sold' && inClient(client, p.investor) && (!stage || stageOf(p) === stage) && (occ === 'all' || p.occupancy === occ)
    && (!q || `${p.street} ${p.city} ${p.loan} ${p.investor}`.toLowerCase().includes(q.toLowerCase()))), [client, stage, occ, q])
  const withStatus = base.map((p) => ({ p, st: statusOf(p.id) }))
  const list = chip === 'all' ? withStatus : withStatus.filter((r) => r.st === chip)
  const chips: (PStatus | 'all')[] = ['all', 'Overdue', 'Action today', 'Ready', 'Check-in due', 'Waiting', 'On track']

  return (
    <div className="page">
      <div className="hstack gap-12 wrap" style={{ alignItems: 'flex-end' }}>
        <div className="stack gap-4" style={{ flex: 1 }}>
          <span className="t-large">Properties</span>
          <span className="t-sub" style={{ fontSize: 14.5 }}>{base.length} active files{client !== 'all' ? ` for ${client}` : ''}. Pick a stage, then a status, to see exactly where files are stuck.</span>
        </div>
        <Segmented layoutId="prop-occ" size="sm" value={occ} onChange={setOcc} items={[{ key: 'all', label: 'Any occupancy' }, { key: 'Vacant', label: 'Vacant' }, { key: 'Occupied', label: 'Occupied' }]} />
        <label className="hstack gap-6 field" style={{ width: 260 }}>
          <Search size={14} className="t-3" />
          <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Address, loan # or investor" style={{ border: 0, background: 'transparent', outline: 'none', flex: 1 }} />
        </label>
      </div>
      <StageStrip active={stage} onPick={setStage} />
      <div className="hstack gap-8 wrap">
        {chips.map((k) => (
          <button key={k} className={`chip ${chip === k ? 'on' : ''}`} onClick={() => setChip(k)}>
            {k !== 'all' && <span className="kind-dot" data-tone={P_TONE[k]} />}{k === 'all' ? 'All' : k}<span className="c">{k === 'all' ? withStatus.length : withStatus.filter((r) => r.st === k).length}</span>
          </button>
        ))}
      </div>
      <motion.div className="card" variants={fadeUp} initial="hidden" animate="show" style={{ overflow: 'hidden' }}>
        <table className="table trk-table">
          <thead><tr><th style={{ paddingLeft: 22 }}>Property</th><th>Stage</th><th style={{ textAlign: 'right' }}>Days</th><th>SLA status</th><th>Next action</th><th>Agent</th><th>Investor</th><th style={{ textAlign: 'right', paddingRight: 22 }}>Value / List</th></tr></thead>
          <tbody>
            {list.slice(0, n).map(({ p, st }) => {
              const i = top.get(p.id)
              const sg = stageOf(p)!
              const agent = i?.signal ? signalDef(i.signal).agent : i?.advance ? ADVANCE_RULES[i.advance]?.agent ?? STAGE_AGENT[sg] : STAGE_AGENT[sg]
              return (
                <tr key={p.id} onClick={() => navigate(`/property/${p.id}`)} style={{ cursor: 'pointer' }} className="hover-row">
                  <td style={{ paddingLeft: 22 }}><div className="strong">{p.street}</div><div className="t-caption" style={{ maxWidth: 190 }}>{p.city}, {p.state} · {p.loan}</div></td>
                  <td style={{ whiteSpace: 'nowrap' }}>{sg}</td>
                  <td className="num" style={{ textAlign: 'right' }}>{p.daysInPhase}</td>
                  <td><span className="pill pill-dot" data-tone={P_TONE[st]}>{st === 'Overdue' && i ? `${overBy(i)} ${unitOf(i)} over` : st}</span></td>
                  <td><div className="ellipsis" style={{ maxWidth: 180 }}>{i?.nextAction ?? 'Monitor'}</div>{i && <div className="t-caption" style={{ maxWidth: 180 }}>{i.signal ? signalDef(i.signal).title : i.reason}</div>}</td>
                  <td><span className="t-caption prop-agent">{agent}</span></td>
                  <td style={{ whiteSpace: 'nowrap' }}><div>{p.investor}</div><div className="t-caption">{p.occupancy}</div></td>
                  <td className="num" style={{ textAlign: 'right', paddingRight: 22, whiteSpace: 'nowrap' }}><div className="strong">{money(p.valuation, { compact: true })}</div><div className="t-caption">list {money(p.listPrice, { compact: true })}</div></td>
                </tr>
              )
            })}
          </tbody>
        </table>
        {!list.length && <div className="empty"><span className="t-headline" style={{ color: 'var(--label)' }}>No files match</span><span className="t-sub">Try another stage or status.</span></div>}
        {list.length > n && <button className="btn btn-plain" style={{ width: '100%', height: 44 }} onClick={() => setN((x) => x + 60)}>Show more ({list.length - n})</button>}
      </motion.div>
    </div>
  )
}
