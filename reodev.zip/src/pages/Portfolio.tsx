import { Suspense, lazy, useMemo, useRef, useState } from 'react'
import { motion, useInView, useReducedMotion } from 'framer-motion'
import { Box, Table2 } from 'lucide-react'
import { inClient, useApp } from '../lib/store'
import { AGING, AGING_BUCKETS, PHASES, PROPERTIES, type Phase } from '../data/mock'
import { navigate } from '../lib/router'
import { BookColumns } from '../features/book/Bars'
import { fadeUp, inView, stagger } from '../lib/motion'
import { AnimatedNumber, Segmented, Sparkline } from '../components/ui'

const AgingSkyline = lazy(() => import('../three/AgingSkyline'))

const VELOCITY = [
  { l: 'Referral → list', v: 38, prior: 77, unit: 'days', good: true, spark: [77, 72, 70, 66, 61, 58, 52, 49, 45, 41, 39, 38] },
  { l: 'Avg days on market', v: 47, prior: 52, unit: 'days', good: true, spark: [52, 53, 55, 54, 52, 51, 50, 50, 49, 48, 47, 47] },
  { l: 'Contract → close', v: 34, prior: 41, unit: 'days', good: true, spark: [41, 40, 42, 39, 38, 37, 37, 36, 35, 35, 34, 34] },
  { l: 'Accepted price to list', v: 95.6, prior: 96.0, unit: '%', good: false, spark: [96.8, 96.6, 96.5, 96.4, 96.2, 96.1, 96.0, 95.9, 95.8, 95.7, 95.6, 95.6] },
]

const DEFS = [
  ['Exceptions', 'Files past a configured signal threshold (6 signals)', 'Control Tower rules on Equator data', 'Distinct work items in Exceptions', 'Live'],
  ['Days in inventory', 'Days since boarding into the AM portfolio', 'Equator', 'Today − boarding date', '9:38 AM'],
  ['Days on market', 'Days since first Hubzu list date (relists keep first date)', 'Hubzu', 'Today − first list date', '9:37 AM'],
  ['Investor response age', 'Days since an approval package was sent without a decision', 'Equator + email tracking', 'Today − sent date', 'Live'],
  ['Sale-to-list', 'Accepted price ÷ list price at acceptance', 'Equator offers', 'Mean over last 30 days', '9:38 AM'],
]

export default function Portfolio() {
  const theme = useApp((s) => s.theme)
  const reduce = !!useReducedMotion()
  const [view, setView] = useState<'3d' | 'table'>('3d')
  const ref = useRef<HTMLDivElement>(null)
  const visible = useInView(ref, { amount: 0.1 })
  const rows = (Object.keys(AGING) as (keyof typeof AGING)[]).map((k) => ({ label: PHASES.find((p) => p.key === k)!.label, values: AGING[k] }))

  return (
    <div className="page">
      <div className="stack gap-4">
        <span className="t-large">Portfolio</span>
        <span className="t-sub" style={{ fontSize: 14.5 }}>Trends and executive metrics moved off Today, so the home page stays about the work. Every number has a definition, a source and an as-of time.</span>
      </div>

      <YourBook />

      <div className="grid g-12" style={{ alignItems: 'start' }}>
        <motion.div className="card span-8 r-full" variants={fadeUp} initial="hidden" animate="show" ref={ref}>
          <div className="card-h">
            <div className="stack" style={{ flex: 1 }}>
              <span className="t-title3">Aging of inventory</span>
              <span className="t-caption">Time since current phase entry · My Properties · as of Nov 3, 9:50 AM</span>
            </div>
            <Segmented layoutId="aging-view" size="sm" value={view} onChange={setView}
              items={[{ key: '3d', label: <span className="hstack gap-4"><Box size={13} />3D</span> }, { key: 'table', label: <span className="hstack gap-4"><Table2 size={13} />Table</span> }]} />
          </div>
          {view === '3d' ? (
            <div style={{ height: 440, position: 'relative' }}>
              <Suspense fallback={null}>
                <AgingSkyline rows={rows} buckets={AGING_BUCKETS} dark={theme === 'dark'} reduce={reduce} running={visible} />
              </Suspense>
              <div className="hero-hint" style={{ left: 22, right: 'auto' }}>Drag to orbit · hover a bar for exact counts · darker = older</div>
            </div>
          ) : (
            <div className="card-pad">
              <table className="table">
                <thead><tr><th>Phase</th>{AGING_BUCKETS.map((b) => <th key={b} style={{ textAlign: 'right' }}>{b}</th>)}<th style={{ textAlign: 'right' }}>Total</th></tr></thead>
                <tbody>
                  {rows.map((r) => (
                    <tr key={r.label}><td className="strong">{r.label}</td>{r.values.map((v, i) => <td key={i} style={{ textAlign: 'right' }}>{v}</td>)}<td style={{ textAlign: 'right' }} className="strong">{r.values.reduce((a, b) => a + b, 0)}</td></tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </motion.div>

        <motion.div className="span-4 r-full stack gap-12" variants={stagger(0.06)} initial="hidden" animate="show">
          {VELOCITY.map((v) => {
            const delta = ((v.v - v.prior) / v.prior) * 100
            const better = v.good ? delta < 0 : delta > 0
            return (
              <motion.div key={v.l} className="card card-pad hstack gap-12" variants={fadeUp}>
                <div className="stack" style={{ flex: 1 }}>
                  <span className="t-sub">{v.l}</span>
                  <span className="round" style={{ fontSize: 30, fontWeight: 700, letterSpacing: '-0.03em' }}>
                    <AnimatedNumber value={v.v} format={(n) => (v.unit === '%' ? n.toFixed(1) : Math.round(n).toString())} />
                    <span style={{ fontSize: 15, fontWeight: 600, color: 'var(--label-3)' }}> {v.unit}</span>
                  </span>
                  <span className="t-caption" style={{ color: better ? 'var(--green-text)' : 'var(--red-text)' }}>{delta > 0 ? '↑' : '↓'} {Math.abs(delta).toFixed(1)}% vs prior period ({v.prior}{v.unit === '%' ? '%' : ' d'})</span>
                </div>
                <Sparkline values={v.spark} tone={better ? 'green' : 'red'} w={96} h={40} />
              </motion.div>
            )
          })}
        </motion.div>
      </div>

      <motion.div className="card" variants={fadeUp} initial="hidden" whileInView="show" viewport={inView}>
        <div className="card-h"><span className="t-title3">Metric definitions</span><span className="t-caption">Dashboard counts reconcile to drill-down lists. Mismatches raise a data-quality alert.</span></div>
        <div className="card-pad">
          <table className="table">
            <thead><tr><th>Metric</th><th>Definition</th><th>Source</th><th>Calculation</th><th>As of</th></tr></thead>
            <tbody>{DEFS.map((d) => <tr key={d[0]}>{d.map((c, i) => <td key={i} className={i === 0 ? 'strong' : i === 1 ? '' : 't-2'}>{c}</td>)}</tr>)}</tbody>
          </table>
        </div>
      </motion.div>
    </div>
  )
}

/** "Your book" moved here from Today: Today is now only the work. */
function YourBook() {
  const items = useApp((s) => s.items)
  const client = useApp((s) => s.clientFilter)
  const { setPhaseFilter, setQueueTab } = useApp()
  const phases = useMemo(() => {
    const props = PROPERTIES.filter((p) => inClient(client, p.investor))
    const att = new Set(items.filter((i) => i.queue === 'exceptions').map((i) => i.propertyId))
    return PHASES.map((ph) => {
      const inPh = props.filter((p) => p.phase === ph.key)
      return { phase: ph.key, label: ph.label, total: inPh.length, attention: inPh.filter((p) => att.has(p.id)).length }
    })
  }, [items, client])
  const total = phases.reduce((m, p) => m + p.total, 0)
  const pick = (ph: Phase) => { setPhaseFilter(ph); setQueueTab('exceptions'); navigate('/work') }
  return (
    <motion.div className="card" variants={fadeUp} initial="hidden" animate="show">
      <div className="card-h">
        <div className="stack" style={{ flex: 1 }}>
          <span className="t-title3">Your book</span>
          <span className="t-caption">{total} files by phase{client !== 'all' ? ` · ${client}` : ''} · coral = files with an open exception · click a column to open those files in My Work</span>
        </div>
      </div>
      <div style={{ padding: '4px 22px 18px', height: 300, display: 'flex' }}><BookColumns phases={phases} active="all" onPick={pick} titleCount={total} /></div>
    </motion.div>
  )
}
