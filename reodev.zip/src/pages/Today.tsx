import { useMemo, useRef, useState } from 'react'
import { motion, useReducedMotion, useScroll, useTransform } from 'framer-motion'
import { ArrowDown } from 'lucide-react'
import { countBy, inClient, isOpenWork, useApp } from '../lib/store'
import { navigate } from '../lib/router'
import { INITIAL_ITEMS, propertyById } from '../data/mock'
import type { Stage } from '../data/workflow'
import { fadeUp, spring, stagger } from '../lib/motion'
import { GoalRing } from '../components/ui'
import { ActToday } from '../features/today'
import { AdvanceCenter, ExceptionCenter, StageStrip, TrackStrip, useScopedItems } from '../features/command'

// Mason: clear 90%+ of the day's items in the first hour.
const GOAL = 0.9
const INITIAL_BY_ID = new Map(INITIAL_ITEMS.map((i) => [i.id, i]))

/**
 * Command center: the AM's opening screen.
 * 1 · exceptions with a recommended resolution → 2 · decisions that advance files → 3 · tracking.
 */
export default function Today() {
  const items = useApp((s) => s.items)
  const scoped = useScopedItems()
  const { clientFilter, setClientFilter } = useApp()
  const reduce = !!useReducedMotion()
  const heroRef = useRef<HTMLDivElement>(null)
  const { scrollYProgress } = useScroll({ target: heroRef, offset: ['start start', 'end start'] })
  const copyY = useTransform(scrollYProgress, [0, 1], [0, 40])
  const [stage, setStage] = useState<Stage | null>(null)

  const sc = useMemo(() => countBy(scoped), [scoped])
  const advance = scoped.filter((i) => i.queue === 'actions' && i.advance && !i.actToday).length
  const minutes = Math.max(10, Math.round((Math.min(15, sc.exceptions) * 2.2 + advance * 2) / 5) * 5)

  // Real progress: share of the work open at the start of the day that has been cleared since.
  const dayStartIds = useApp((st) => st.dayStartIds)
  const progress = useMemo(() => {
    const open = new Set(items.filter(isOpenWork).map((i) => i.id))
    const start = dayStartIds.filter((id) => { const it = INITIAL_BY_ID.get(id); return !!it && inClient(clientFilter, propertyById(it.propertyId).investor) })
    const done = start.filter((id) => !open.has(id)).length
    return { done, total: start.length, pct: start.length ? done / start.length : 0 }
  }, [items, dayStartIds, clientFilter])
  const need = Math.max(0, Math.ceil(progress.total * GOAL) - progress.done)
  const jump = (id: string) => window.setTimeout(() => document.getElementById(id)?.scrollIntoView({ behavior: reduce ? 'auto' : 'smooth', block: 'start' }), 60)
  const start = () => jump('exceptions')
  // A stage card filters both lists and takes you to the first one with work in it.
  const pickStage = (s: Stage | null, info?: { exc: number; ready: number }) => {
    setStage(s)
    if (s && info) jump(info.exc > 0 ? 'exceptions' : 'advance')
  }

  return (
    <div className="page">
      <section className="hero2 cc-hero" ref={heroRef}>
        <div className="hero2-top">
          <motion.div className="stack gap-14" style={{ y: copyY, alignSelf: 'center' }} variants={stagger(0.07, 0.04)} initial="hidden" animate="show">
            <motion.h1 className="t-large" style={{ margin: 0, fontSize: 40, letterSpacing: '-0.03em' }} variants={fadeUp}>Good morning, Srini</motion.h1>
            <motion.p variants={fadeUp} style={{ margin: 0, fontSize: 17, lineHeight: 1.5, color: 'var(--label-2)', maxWidth: 600, letterSpacing: '-0.014em' }}>
              <b style={{ color: 'var(--label)', fontWeight: 600 }}>{sc.exceptions} exception{sc.exceptions === 1 ? '' : 's'}</b> and <b style={{ color: 'var(--label)', fontWeight: 600 }}>{advance} decision{advance === 1 ? '' : 's'}</b> are waiting{clientFilter !== 'all' ? ` for ${clientFilter}` : ''}. Every one has a recommended resolution ready. {sc.exceptions > 15 ? 'The top 15 take' : 'They take'} about {minutes} minutes.
            </motion.p>
            <motion.div className="hstack gap-10 wrap" variants={fadeUp} style={{ marginTop: 6 }}>
              <motion.button className="btn btn-primary btn-lg" whileTap={{ scale: 0.97 }} onClick={start}>{sc.exceptions > 15 ? 'Start with the top 15' : 'Start resolving'} <ArrowDown size={16} /></motion.button>
              {clientFilter !== 'all' && <button className="btn btn-gray btn-lg" onClick={() => setClientFilter('all')}>Showing {clientFilter} · show all</button>}
              <button className="btn btn-gray btn-lg" onClick={() => navigate('/work')}>Open My Work</button>
            </motion.div>
          </motion.div>
          <motion.div className="goal-wrap" variants={fadeUp} initial="hidden" animate="show" transition={{ ...spring, delay: 0.2 }}>
            <GoalRing pct={progress.pct} goal={GOAL} />
            <div className="goal-legend">
              <span className="t-eyebrow">First-hour goal</span>
              <span className="goal-v num"><b>{progress.done}</b> of {progress.total} cleared</span>
              <span className={`goal-s ${need === 0 ? 'met' : ''}`}>{need === 0 ? 'Goal met for today' : `${need} more to reach ${Math.round(GOAL * 100)}%`}</span>
            </div>
          </motion.div>
        </div>
        <div style={{ padding: '0 14px 14px' }}><StageStrip mode="act" active={stage} onPick={pickStage} /></div>
      </section>

      <div id="act-today" style={{ scrollMarginTop: 80 }}><ActToday /></div>
      <ExceptionCenter stage={stage} onClearStage={() => setStage(null)} />
      <AdvanceCenter stage={stage} onClearStage={() => setStage(null)} />
      <TrackStrip />
    </div>
  )
}
