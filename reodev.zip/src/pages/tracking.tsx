import { useMemo, useState } from 'react'
import { AnimatePresence, motion } from 'framer-motion'
import { CalendarPlus, Check as CheckIcon, Clock, Handshake, Inbox, MessageSquareReply, RotateCcw, Send, Timer } from 'lucide-react'
import { nowLabel, useApp } from '../lib/store'
import { navigate } from '../lib/router'
import { money, propertyById, type WorkItem } from '../data/mock'
import { addBD, dateFor, fmtDate, fmtDay, isLiveOffer, requestOf } from '../data/workflow'
import { fadeUp, springSnappy, stagger } from '../lib/motion'
import { AnimatedNumber } from '../components/ui'
import { originOf } from '../features/actions'
import { useScopedItems } from '../features/command'

/* ------------------------------------------------------------ shared bits */
function PageHead({ eyebrow, title, sub, right }: { eyebrow: string; title: string; sub: React.ReactNode; right?: React.ReactNode }) {
  return (
    <motion.div className="hstack gap-12 wrap" style={{ alignItems: 'flex-end' }} variants={fadeUp} initial="hidden" animate="show">
      <div className="stack gap-4" style={{ flex: 1, minWidth: 280 }}>
        <span className="t-eyebrow">{eyebrow}</span>
        <span className="t-large">{title}</span>
        <span className="t-sub" style={{ fontSize: 14.5, maxWidth: 720 }}>{sub}</span>
      </div>
      {right}
    </motion.div>
  )
}

function Kpis({ items }: { items: { l: string; v: number; s?: string; tone?: string; suffix?: string }[] }) {
  return (
    <motion.div className="trk-kpis" variants={stagger(0.05)} initial="hidden" animate="show">
      {items.map((k) => (
        <motion.div key={k.l} className="trk-kpi" data-tone={k.tone ?? 'gray'} variants={fadeUp}>
          <span className="l">{k.l}</span>
          <span className="v"><AnimatedNumber value={k.v} />{k.suffix && <small>{k.suffix}</small>}</span>
          {k.s && <span className="s">{k.s}</span>}
        </motion.div>
      ))}
    </motion.div>
  )
}

/** Small anchored menu for "Log response". */
function LogMenu({ options, onPick, label = 'Log response' }: { options: string[]; onPick: (o: string) => void; label?: string }) {
  const [open, setOpen] = useState(false)
  return (
    <span style={{ position: 'relative' }} onClick={(e) => e.stopPropagation()}>
      <button className="btn btn-sm btn-gray" onClick={() => setOpen((v) => !v)}><MessageSquareReply size={13} />{label}</button>
      <AnimatePresence>
        {open && (
          <motion.div className="menu" style={{ top: 34, width: 210 }} initial={{ opacity: 0, y: -4, scale: 0.97 }} animate={{ opacity: 1, y: 0, scale: 1 }} exit={{ opacity: 0, y: -4, scale: 0.97 }} transition={springSnappy}
            onMouseLeave={() => setOpen(false)}>
            {options.map((o) => <button key={o} className="menu-item" onClick={() => { setOpen(false); onPick(o) }}>{o}</button>)}
          </motion.div>
        )}
      </AnimatePresence>
    </span>
  )
}

const Empty = ({ title, sub }: { title: string; sub: string }) => (
  <div className="empty"><Inbox size={28} /><span className="t-headline" style={{ color: 'var(--label)' }}>{title}</span><span className="t-sub">{sub}</span></div>
)

/* ------------------------------------------------------------ Investor follow-ups */
export function FollowUps() {
  const scoped = useScopedItems()
  const { dayOffset, openResolve, applyMoves, toast, cleared, markCleared } = useApp()
  const rows = useMemo(() => scoped.filter((i) => i.queue === 'approvals' || (i.queue === 'exceptions' && i.signal === 'investor')).sort((a, b) => b.days - a.days), [scoped])
  const due = rows.filter((i) => i.queue === 'exceptions')
  const approved = cleared['inv-approved']?.n ?? 0
  const today = dateFor(dayOffset)

  const log = (i: WorkItem, o: string) => {
    const p = propertyById(i.propertyId)
    if (o === 'Approved') {
      const undo = applyMoves([{ id: i.id, to: 'done' }])
      markCleared('inv-approved', approved + 1)
      toast({ title: `${p.investor} approved · ${requestOf(i)}`, body: `${p.street} · logged in Equator, next step queued`, undo })
    } else if (o === 'Declined') {
      const undo = applyMoves([{ id: i.id, to: 'exceptions', patch: { signal: undefined, reason: `${requestOf(i)} declined by ${p.investor}`, detail: 'Investor declined · decide next step', nextAction: 'Review', risk: 'High', status: 'Review Required', days: 0, slaDays: 1 } }])
      toast({ title: 'Logged: declined', body: `${p.street} is back in your exceptions to decide the next step`, tone: 'info', undo })
    } else {
      const undo = applyMoves([{ id: i.id, to: 'approvals', patch: { reason: `${requestOf(i)} · with ${p.investor}`, detail: 'Investor asked for more information', days: 0, nextAction: 'View package' } }])
      toast({ title: 'Logged: more info requested', body: `${p.street} · clock restarted`, tone: 'info', undo })
    }
  }

  return (
    <div className="page">
      <PageHead eyebrow="Track · investors" title="Investor follow-ups"
        sub={<>Every request waiting on an investor. A nudge is due from day 2 and every business day after, with REO management copied. Approve today's nudges in one go.</>}
        right={due.length > 0 && (
          <motion.button className="btn btn-primary btn-lg" whileTap={{ scale: 0.97 }} onClick={(e) => openResolve({ itemIds: due.map((i) => i.id), origin: originOf(e) })}>
            <Send size={15} />Review & send {due.length} nudge{due.length === 1 ? '' : 's'} due today
          </motion.button>
        )} />
      <Kpis items={[
        { l: 'Outstanding requests', v: rows.length, s: 'with investors now', tone: 'lavender' },
        { l: 'Oldest request', v: rows[0]?.days ?? 0, suffix: ' BD', s: rows[0] ? propertyById(rows[0].propertyId).street : '—', tone: 'rose' },
        { l: 'Nudges due today', v: due.length, s: 'past the 2 BD point', tone: 'peach' },
        { l: 'Approved today', v: approved, s: 'responses logged', tone: 'mint' },
      ]} />
      <motion.div className="card" style={{ overflow: 'visible' }} variants={fadeUp} initial="hidden" animate="show">
        <table className="table trk-table">
          <thead><tr><th style={{ paddingLeft: 22 }}>Property</th><th>Request</th><th>Investor</th><th>Submitted</th><th style={{ textAlign: 'right' }}>Days</th><th style={{ textAlign: 'right' }}>Nudges</th><th>Next due</th><th>Status</th><th /></tr></thead>
          <tbody>
            <AnimatePresence initial={false}>
              {rows.map((i) => {
                const p = propertyById(i.propertyId)
                const isDue = i.queue === 'exceptions'
                const next = isDue ? 'Today' : fmtDate(addBD(today, Math.max(1, i.slaDays - i.days)))
                return (
                  <motion.tr key={i.id} layout="position" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0, x: 40 }} className="hover-row" onClick={() => navigate(`/property/${p.id}`)} style={{ cursor: 'pointer' }}>
                    <td style={{ paddingLeft: 22 }}><div className="strong">{p.street}</div><div className="t-caption">{p.city}, {p.state} · {p.loan}</div></td>
                    <td>{requestOf(i)}</td>
                    <td>{p.investor}</td>
                    <td className="num">{fmtDate(addBD(today, -i.days))}</td>
                    <td className="num" style={{ textAlign: 'right' }} data-tone={isDue ? 'rose' : undefined}><span className={isDue ? 'days' : ''}>{i.days}</span></td>
                    <td className="num" style={{ textAlign: 'right' }}>{i.followUps ?? 0}</td>
                    <td className="num">{next}</td>
                    <td>{isDue ? <span className="pill pill-dot" data-tone="peach">Nudge due</span> : <span className="pill pill-dot" data-tone="sky">Waiting</span>}</td>
                    <td style={{ textAlign: 'right', paddingRight: 16, whiteSpace: 'nowrap' }} onClick={(e) => e.stopPropagation()}>
                      <span className="hstack gap-6" style={{ justifyContent: 'flex-end' }}>
                        <button className="btn btn-sm btn-tone" data-tone="lavender" onClick={(e) => openResolve({ itemIds: [i.id], origin: originOf(e) })}>{isDue ? 'Review nudge' : 'Nudge early'}</button>
                        <LogMenu options={['Approved', 'Declined', 'Asked for more info']} onPick={(o) => log(i, o)} />
                      </span>
                    </td>
                  </motion.tr>
                )
              })}
            </AnimatePresence>
          </tbody>
        </table>
        {!rows.length && <Empty title="Nothing waiting on investors" sub="Requests you send appear here with their nudge schedule." />}
      </motion.div>
    </div>
  )
}

/* ------------------------------------------------------------ Awaiting response */
export function Awaiting() {
  const scoped = useScopedItems()
  const { dayOffset, simulateDay, applyMoves, toast } = useApp()
  const rows = useMemo(() => scoped.filter((i) => i.queue === 'watch').sort((a, b) => (a.slaDays - a.days) - (b.slaDays - b.days)), [scoped])
  const today = dateFor(dayOffset)
  const late = rows.filter((i) => i.days > i.slaDays).length
  const dueSoon = rows.filter((i) => i.slaDays - i.days <= 1 && i.days <= i.slaDays).length
  const sentToday = rows.filter((i) => i.sentOn && i.days === 0).length

  const next = () => {
    const n = simulateDay()
    toast({ title: `Moved to ${fmtDay(dateFor(dayOffset + 1))}`, body: n ? `${n} item${n === 1 ? '' : 's'} without a reply went back to your exceptions.` : 'Nothing came due overnight.', tone: 'info' })
  }
  const log = (i: WorkItem, o: string) => {
    const p = propertyById(i.propertyId)
    const undo = applyMoves([{ id: i.id, to: 'done' }])
    toast({ title: `Logged: ${o.toLowerCase()}`, body: `${p.street} · ${i.counterparty} · recorded in Equator`, undo })
  }
  const resend = (i: WorkItem) => {
    const p = propertyById(i.propertyId)
    const undo = applyMoves([{ id: i.id, to: 'watch', patch: { days: 0, sentOn: `${fmtDate(today)}, ${nowLabel()}`, detail: `Resent ${nowLabel()} · reply expected by ${fmtDate(addBD(today, i.slaDays))}`, expectBy: fmtDate(addBD(today, i.slaDays)) } }])
    toast({ title: 'Follow-up resent', body: `${p.street} · ${i.counterparty}`, undo })
  }

  return (
    <div className="page">
      <PageHead eyebrow="Track · vendors and partners" title="Awaiting response"
        sub={<>Everything you sent that's waiting on a vendor, broker, title or field team. If nothing comes back by the expected date, it returns to your exceptions automatically.</>}
        right={<button className="btn btn-gray btn-lg" onClick={next} title="Prototype: advance one business day"><CalendarPlus size={15} />Simulate next business day</button>} />
      <Kpis items={[
        { l: 'Waiting on a reply', v: rows.length, s: fmtDay(today), tone: 'sky' },
        { l: 'Due today or tomorrow', v: dueSoon, s: 'reply window closing', tone: 'sand' },
        { l: 'Late', v: late, s: 'returns to exceptions overnight', tone: 'rose' },
        { l: 'Sent today', v: sentToday, s: 'from your resolutions', tone: 'mint' },
      ]} />
      <motion.div className="card" style={{ overflow: 'visible' }} variants={fadeUp} initial="hidden" animate="show">
        <table className="table trk-table">
          <thead><tr><th style={{ paddingLeft: 22 }}>Property</th><th>What was sent</th><th>To</th><th>Sent</th><th>Expected by</th><th>Countdown</th><th /></tr></thead>
          <tbody>
            <AnimatePresence initial={false}>
              {rows.map((i) => {
                const p = propertyById(i.propertyId)
                const left = i.slaDays - i.days
                const expect = i.expectBy ?? fmtDate(addBD(today, Math.max(0, left)))
                const tone = left < 0 ? 'rose' : left <= 1 ? 'sand' : 'mint'
                return (
                  <motion.tr key={i.id} layout="position" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0, x: 40 }} className="hover-row" onClick={() => navigate(`/property/${p.id}`)} style={{ cursor: 'pointer' }}>
                    <td style={{ paddingLeft: 22 }}><div className="strong">{p.street}</div><div className="t-caption">{p.city}, {p.state} · {p.investor}</div></td>
                    <td><div>{i.sentWhat ?? i.reason}</div><div className="t-caption ellipsis" style={{ maxWidth: 280 }}>{i.sentWhat ? i.reason : i.detail}</div></td>
                    <td>{i.counterparty}</td>
                    <td className="num">{i.sentOn ?? fmtDate(addBD(today, -i.days))}</td>
                    <td className="num">{expect}</td>
                    <td><span className="pill pill-dot" data-tone={tone}>{left < 0 ? `${-left} BD late` : left === 0 ? 'Due today' : `${left} BD left`}</span></td>
                    <td style={{ textAlign: 'right', paddingRight: 16, whiteSpace: 'nowrap' }} onClick={(e) => e.stopPropagation()}>
                      <span className="hstack gap-6" style={{ justifyContent: 'flex-end' }}>
                        <LogMenu options={['Reply received', 'Task completed', 'Document uploaded']} onPick={(o) => log(i, o)} />
                        <button className="btn btn-sm btn-plain" onClick={() => resend(i)}><RotateCcw size={13} />Resend</button>
                      </span>
                    </td>
                  </motion.tr>
                )
              })}
            </AnimatePresence>
          </tbody>
        </table>
        {!rows.length && <Empty title="Nothing outstanding" sub="Follow-ups you approve on Today are tracked here until a reply comes back." />}
      </motion.div>
    </div>
  )
}

/* ------------------------------------------------------------ Offers */
type OfferStatus = 'execute' | 'decide' | 'investor'
interface OfferRow { i: WorkItem; status: OfferStatus; best: number; list: number; reserve: number; n: number; rec: string; conf: number }

function offerRows(items: WorkItem[]): OfferRow[] {
  const out: OfferRow[] = []
  for (const i of items) {
    if (!isLiveOffer(i)) continue
    const p = propertyById(i.propertyId)
    const list = p.listPrice ?? p.valuation ?? 220000
    const best = i.offer?.amount ?? p.prevHighOffer ?? Math.round((list * 0.93) / 500) * 500
    const reserve = Math.round((list * 0.92) / 1000) * 1000
    const status: OfferStatus = i.actToday ? 'execute' : i.queue === 'approvals' || i.signal === 'investor' ? 'investor' : 'decide'
    const counter = Math.round((best + (list - best) * 0.6) / 100) * 100
    const rec = i.offer ? (i.offer.type === 'accept' ? 'Accept' : 'Counter') : best / list >= 0.97 ? 'Accept' : best >= reserve ? `Counter at ${money(counter)}` : `Counter at reserve ${money(reserve)}`
    out.push({ i, status, best, list, reserve, n: Math.max(1, p.bids), rec, conf: 82 + (parseInt(p.id.slice(1), 10) % 14) })
  }
  const order = { execute: 0, decide: 1, investor: 2 }
  return out.sort((a, b) => order[a.status] - order[b.status] || b.best / b.list - a.best / a.list)
}

export function Offers() {
  const scoped = useScopedItems()
  const { openResolve, openConfirm } = useApp()
  const [f, setF] = useState<'all' | OfferStatus>('all')
  const all = useMemo(() => offerRows(scoped), [scoped])
  const rows = f === 'all' ? all : all.filter((r) => r.status === f)
  const count = (s: OfferStatus) => all.filter((r) => r.status === s).length
  const avg = all.length ? all.reduce((m, r) => m + r.best / r.list, 0) / all.length * 100 : 0
  const ST = {
    execute: { l: 'Approved · execute today', tone: 'mint' },
    decide: { l: 'Needs decision', tone: 'peach' },
    investor: { l: 'With investor', tone: 'lavender' },
  } as const

  return (
    <div className="page">
      <PageHead eyebrow="Track · offers" title="Offers"
        sub={<>Every live offer in one list: approvals to execute today first, then offers that need your decision, then those waiting on the investor. Each one has an agent recommendation against list and reserve.</>} />
      <Kpis items={[
        { l: 'Live offers', v: all.length, s: 'across your book', tone: 'sky' },
        { l: 'Execute today', v: count('execute'), s: 'investor already approved', tone: 'mint' },
        { l: 'Need your decision', v: count('decide'), s: 'agent recommendation ready', tone: 'peach' },
        { l: 'Average best offer', v: Math.round(avg * 10) / 10, suffix: '% of list', s: 'sample data', tone: 'lavender' },
      ]} />
      <div className="hstack gap-8 wrap">
        {(['all', 'execute', 'decide', 'investor'] as const).map((k) => (
          <button key={k} className={`chip ${f === k ? 'on' : ''}`} onClick={() => setF(k)}>
            {k === 'all' ? 'All' : k === 'execute' ? 'Investor approved' : ST[k].l}<span className="c">{k === 'all' ? all.length : count(k)}</span>
          </button>
        ))}
      </div>
      <motion.div className="card" style={{ overflow: 'hidden' }} variants={fadeUp} initial="hidden" animate="show">
        <table className="table trk-table">
          <thead><tr><th style={{ paddingLeft: 22 }}>Property</th><th style={{ textAlign: 'right' }}>Best offer</th><th style={{ textAlign: 'right' }}>% of list</th><th style={{ textAlign: 'right' }}>% of reserve</th><th>Agent recommendation</th><th>Status</th><th /></tr></thead>
          <tbody>
            <AnimatePresence initial={false}>
              {rows.map((r) => {
                const p = propertyById(r.i.propertyId)
                const pl = (r.best / r.list) * 100, pr = (r.best / r.reserve) * 100
                return (
                  <motion.tr key={r.i.id} layout="position" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0, x: 40 }} className="hover-row" onClick={() => navigate(`/property/${p.id}`)} style={{ cursor: 'pointer' }}>
                    <td style={{ paddingLeft: 22 }}><div className="strong">{p.street}</div><div className="t-caption">{p.city}, {p.state} · {p.investor}</div></td>
                    <td style={{ textAlign: "right" }}><div className="strong num">{money(r.best)}</div><div className="t-caption">best of {r.n} · list {money(r.list, { compact: true })}</div></td>
                    <td className="num" style={{ textAlign: 'right' }}><span className="pct-bar"><span style={{ width: `${Math.min(100, Math.max(0, (pl - 85) / 15 * 100))}%` }} /></span>{pl.toFixed(1)}%</td>
                    <td className="num" style={{ textAlign: 'right', color: pr >= 100 ? 'var(--mint-text)' : 'var(--rose-text)', fontWeight: 600 }}>{pr.toFixed(1)}%</td>
                    <td><div className="strong" style={{ whiteSpace: 'normal', maxWidth: 170 }}>{r.rec}</div><div className="t-caption">{r.conf}% confidence</div></td>
                    <td><span className="pill pill-dot" data-tone={ST[r.status].tone}>{r.status === 'investor' ? `With investor · ${r.i.days} BD` : ST[r.status].l}</span></td>
                    <td style={{ textAlign: 'right', paddingRight: 16, whiteSpace: 'nowrap' }} onClick={(e) => e.stopPropagation()}>
                      {r.status === 'execute'
                        ? <button className="btn btn-sm btn-primary" onClick={(e) => openConfirm({ kind: 'contract', itemId: r.i.id, origin: originOf(e) })}><CheckIcon size={13} />{r.i.offer?.type === 'counter' ? 'Send counter' : 'Accept & send'}</button>
                        : <button className="btn btn-sm btn-tone" data-tone={r.status === 'decide' ? 'mint' : 'lavender'} onClick={(e) => openResolve({ itemIds: [r.i.id], origin: originOf(e) })}>{r.status === 'decide' ? 'Review offer' : 'Nudge investor'}</button>}
                    </td>
                  </motion.tr>
                )
              })}
            </AnimatePresence>
          </tbody>
        </table>
        {!rows.length && <Empty title="No offers here" sub="New Hubzu offers appear the moment they're received." />}
      </motion.div>
    </div>
  )
}

export const TRACK_ICONS = { followups: Timer, awaiting: Clock, offers: Handshake }
