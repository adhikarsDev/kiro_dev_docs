// Shared workflow helpers: fine-grained stages, business-day dates, and public market trends.
import { INITIAL_ITEMS, type Property, type WorkItem, signalDef } from './mock'

/* ---------------------------------------------------------- stages (mockup stage strip) */
export const STAGES = ['Intake', 'Occupancy', 'Eviction (ESD)', 'Preservation', 'Valuation', 'Listing', 'On market', 'Offers', 'Under contract', 'Closing'] as const
export type Stage = (typeof STAGES)[number]

const LISTING = new Set(INITIAL_ITEMS.filter((i) => i.signal === 'initlist' || i.advance === 'Ready to list').map((i) => i.propertyId))

export function stageOf(p: Property): Stage | null {
  if (p.phase === 'sold') return null
  if (p.phase === 'closing') return 'Closing'
  if (p.phase === 'contract') return 'Under contract'
  if (p.phase === 'on') return p.stage >= 6 ? 'Offers' : 'On market'
  if (p.occupancy === 'Occupied') return 'Eviction (ESD)'
  if (LISTING.has(p.id)) return 'Listing'
  if (p.daysInInventory <= 3 && p.stage <= 2) return 'Intake'
  if (p.stage <= 2) return 'Occupancy'
  if (p.stage === 3) return 'Preservation'
  return 'Valuation'
}

/* ---------------------------------------------------------- business days (prototype date) */
export const BASE_DATE = new Date(2026, 10, 3) // Tue Nov 3, 2026 (the demo's "today")
export function addBD(d: Date, n: number) {
  const x = new Date(d)
  let k = n
  const step = k < 0 ? -1 : 1
  while (k !== 0) { x.setDate(x.getDate() + step); if (x.getDay() !== 0 && x.getDay() !== 6) k -= step }
  return x
}
export const fmtDate = (d: Date) => d.toLocaleDateString('en-US', { month: 'short', day: 'numeric' })
export const fmtDay = (d: Date) => d.toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric' })
export const dateFor = (offset: number) => addBD(BASE_DATE, offset)
/** "2 BD" → 2 business days; "30 days" → 22 business days (approx.). */
export const recheckBD = (recheck: string) => { const n = parseInt(recheck, 10) || 2; return /day/.test(recheck) && !/BD/.test(recheck) ? Math.round(n * 0.72) : n }

/* ---------------------------------------------------------- SLA helpers */
export const overBy = (i: WorkItem) => Math.max(0, i.days - i.slaDays)
export const unitOf = (i: WorkItem) => (i.signal && /BD/.test(signalDef(i.signal).rule) && i.slaDays <= 15 ? 'BD' : 'd')
export const severityOf = (i: WorkItem): 'Critical' | 'Warning' => (i.risk === 'High' || overBy(i) >= Math.max(3, i.slaDays * 0.5) ? 'Critical' : 'Warning')
export function exceptionScore(i: WorkItem) {
  const sev = severityOf(i) === 'Critical' ? 1000 : 0
  const advance = i.signal && signalDef(i.signal).kind === 'advance' ? 50 : 0
  return sev + advance + Math.min(400, (overBy(i) / Math.max(1, i.slaDays)) * 100) + overBy(i)
}

/* ---------------------------------------------------------- public market trends (sample) */
// The meeting agreed public sources (e.g. Redfin) via web search are enough for the MVP.
// These are SAMPLE values, deterministic per ZIP, until the retrieval is wired up.
export interface PublicTrend { zip: string; city: string; medianSale: number; yoyValue: number; dom: number; domYoy: number; soldYoy: number; saleToList: number; trend: number[] }
export function publicTrend(p: Property): PublicTrend {
  const seed = parseInt(p.zip, 10) % 97
  const base = Math.round(((p.listPrice ?? p.valuation ?? 220000) * (0.97 + (seed % 7) / 100)) / 1000) * 1000
  const yoy = -(3 + (seed % 9)) // −3% … −11%
  const trend = Array.from({ length: 12 }, (_, k) => Math.round(base * (1 - (yoy / 100) * ((11 - k) / 11)) + Math.sin(k + seed) * base * 0.006))
  return { zip: p.zip, city: p.city, medianSale: base, yoyValue: yoy, dom: 44 + (seed % 26), domYoy: 8 + (seed % 15), soldYoy: -(5 + (seed % 13)), saleToList: 94.2 + (seed % 25) / 10, trend }
}

/** The investor request behind a follow-up ("Reduction request", "Initial listing approval"). */
export function requestOf(i: WorkItem) {
  const r = i.reason === 'Investor follow-up due' || i.reason.startsWith('No reply') ? i.detail.split(' · ')[0] : i.reason
  return r.replace(/ · (with|sent to) .*/, '').replace(/ pending$/, '')
}

/** A live offer, as listed on the Offers page (same rule everywhere). */
export function isLiveOffer(i: WorkItem) {
  const isOffer = !!i.offer || i.signal === 'offerreview' || i.advance === 'Offer recommendation ready'
    || (i.queue === 'approvals' && /Offer|Counter/.test(i.reason)) || (i.signal === 'investor' && /Offer/.test(i.reason))
  return isOffer && !(i.queue === 'actions' && !!i.offer && !i.actToday)
}
