// Deterministic mock portfolio for one Asset Manager (~236 files, per the transcript's
// "a couple hundred files, 20–40 exceptions on any given day").

export type Phase = 'pre' | 'on' | 'contract' | 'closing' | 'sold'
export type Queue = 'exceptions' | 'actions' | 'approvals' | 'watch'
// Exception types from the AM exception catalog (business-day SLAs). The first six keep their original keys.
export type SignalKey =
  | 'trashout' | 'novalue' | 'investor' | 'reduction' | 'eviction' | 'closing'
  | 'occupancy' | 'lockchange' | 'valorder' | 'reconcile' | 'initlist' | 'relist' | 'offerreview'
  | 'rma' | 'broker' | 'uvdue' | 'occreview' | 'pts' | 'relistcancel'
export type Risk = 'High' | 'Medium' | 'Low'
export type ActionKind =
  | 'vendor' | 'investor' | 'recommendation' | 'eviction' | 'contract'
  | 'approve' | 'review' | 'closing' | 'view'

export const PHASES: { key: Phase; label: string; short: string }[] = [
  { key: 'pre', label: 'Pre-Marketing', short: 'Pre-Mkt' },
  { key: 'on', label: 'On-Market', short: 'On-Mkt' },
  { key: 'contract', label: 'Under Contract', short: 'Contract' },
  { key: 'closing', label: 'Closing', short: 'Closing' },
  { key: 'sold', label: 'Sold · 30d', short: 'Sold' },
]
export const phaseLabel = (p: Phase) => PHASES.find((x) => x.key === p)!.label

export const LIFECYCLE = [
  'Foreclosure', 'Boarding', 'Occupancy', 'Initial Services', 'Valuation',
  'Marketing', 'Offers', 'Contract', 'Closing', 'Sold',
]

export interface Property {
  id: string
  loan: string
  street: string
  city: string
  state: string
  zip: string
  msa: string
  investor: string
  phase: Phase
  stage: number // index in LIFECYCLE
  daysInInventory: number
  daysInPhase: number
  dom: number | null
  listPrice: number | null
  valuation: number | null
  prevHighOffer: number | null
  bids: number
  bidders: number
  broker: string
  occupancy: 'Vacant' | 'Occupied' | 'Unknown'
  type: 'Single Family' | 'Townhome' | 'Condo' | 'Multi-Family'
  beds: number
  baths: number
  sqft: number
  titleTrack: boolean
  hubzuId: string | null
}

export interface WorkItem {
  id: string
  propertyId: string
  queue: Queue
  signal?: SignalKey
  approaching?: boolean
  reason: string
  detail: string
  days: number
  slaDays: number
  risk: Risk
  nextAction: string
  actionKind: ActionKind
  counterparty: string
  actToday?: boolean
  approvedAgo?: string
  offer?: { amount: number; financing: string; buyer: string; type: 'accept' | 'counter' }
  status: 'Review Required' | 'Ready' | 'Blocked' | 'Waiting External' | 'Approval Pending' | 'Completed'
  note?: string
  /** "Ready to advance" group for decisions that move a file forward. */
  advance?: string
  /** Follow-ups already sent (investor requests). */
  followUps?: number
  /** Set when a resolution sends something out, for Awaiting response tracking. */
  sentOn?: string
  expectBy?: string
  sentWhat?: string
}

// ---------- seeded RNG ----------
function mulberry32(a: number) {
  return function () {
    a |= 0; a = (a + 0x6d2b79f5) | 0
    let t = Math.imul(a ^ (a >>> 15), 1 | a)
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296
  }
}
const rnd = mulberry32(20261103)
const pick = <T,>(arr: T[]) => arr[Math.floor(rnd() * arr.length)]
const int = (a: number, b: number) => a + Math.floor(rnd() * (b - a + 1))

const CITIES: [string, string, string, string][] = [
  ['Phoenix', 'AZ', '850', 'Phoenix–Mesa'], ['Mesa', 'AZ', '852', 'Phoenix–Mesa'],
  ['Dallas', 'TX', '752', 'Dallas–Fort Worth'], ['Houston', 'TX', '770', 'Houston'],
  ['Austin', 'TX', '787', 'Austin'], ['Atlanta', 'GA', '303', 'Atlanta'],
  ['Orlando', 'FL', '328', 'Orlando'], ['Tampa', 'FL', '336', 'Tampa Bay'],
  ['Jacksonville', 'FL', '322', 'Jacksonville'], ['Miami', 'FL', '331', 'Miami'],
  ['Charlotte', 'NC', '282', 'Charlotte'], ['Raleigh', 'NC', '276', 'Raleigh'],
  ['Las Vegas', 'NV', '891', 'Las Vegas'], ['Denver', 'CO', '802', 'Denver'],
  ['Columbus', 'OH', '432', 'Columbus'], ['Memphis', 'TN', '381', 'Memphis'],
  ['Indianapolis', 'IN', '462', 'Indianapolis'], ['Birmingham', 'AL', '352', 'Birmingham'],
  ['Baltimore', 'MD', '212', 'Baltimore'], ['Manassas', 'VA', '201', 'Washington'],
]
const STREETS = [
  'Maple Grove Dr', 'Oak Ave', 'Pine Rd', 'Cedar Ln', 'Birch Ct', 'Spruce Dr', 'Palm Way', 'Elm St',
  'Lakeview Rd', 'Willow Ct', 'Ash St', 'Westland Pl', 'Hope St', 'Jeddo Rd', 'Commodore Ave',
  'Sunset Blvd', 'River Rd', 'Juniper Way', 'Magnolia Dr', 'Aspen Ct', 'Hawthorne St', 'Sycamore Ln',
  'Bluebonnet Dr', 'Cypress Pt', 'Mesquite Trl', 'Peachtree Ct', 'Sagebrush Rd', 'Harbor View Dr',
  'Granite Ridge', 'Meadowlark Ln', 'Chestnut St', 'Briarwood Dr', 'Foxglove Ct', 'Redbud Ln',
  'Silver Creek Rd', 'Canyon Vista Dr',
]
const BROKERS: Record<string, string> = {
  AZ: 'AZ Prime Realty', TX: 'Lone Star REO Group', GA: 'Peachtree Asset Realty', FL: 'Suncoast REO Partners',
  NC: 'Carolina Crest Realty', NV: 'Desert Peak Brokers', CO: 'Front Range REO', OH: 'Buckeye Realty Group',
  TN: 'River City Brokers', IN: 'Hoosier Home Realty', AL: 'Magnolia REO', MD: 'Chesapeake Realty', VA: 'Old Dominion REO',
}
const INVESTORS = ['SPS', 'SPS', 'SPS', 'SPS', 'FirstKey', 'FirstKey', 'Onity/PHH', 'Onity/PHH', 'Calibr', 'NRZ/Newrez']
export const CLIENTS = ['SPS', 'FirstKey', 'Onity/PHH', 'Calibr', 'NRZ/Newrez']
const TYPES: Property['type'][] = ['Single Family', 'Single Family', 'Single Family', 'Townhome', 'Condo', 'Multi-Family']

// Hand-seeded files that mirror the wireframes, so reviewers recognise them.
const SEEDED: Partial<Property>[] = [
  { street: '1234 Maple Grove Dr', city: 'Phoenix', state: 'AZ', zip: '85032', phase: 'on', investor: 'SPS' },
  { street: '5678 Oak Ave', city: 'Dallas', state: 'TX', zip: '75201', phase: 'pre', investor: 'SPS' },
  { street: '9101 Pine Rd', city: 'Atlanta', state: 'GA', zip: '30309', phase: 'on', investor: 'SPS' },
  { street: '2222 Cedar Ln', city: 'Orlando', state: 'FL', zip: '32801', phase: 'on', investor: 'SPS' },
  { street: '3456 Birch Ct', city: 'Charlotte', state: 'NC', zip: '28202', phase: 'on', investor: 'Calibr' },
  { street: '7890 Spruce Dr', city: 'Tampa', state: 'FL', zip: '33607', phase: 'on', investor: 'SPS' },
  { street: '1500 Palm Way', city: 'Las Vegas', state: 'NV', zip: '89144', phase: 'closing', investor: 'Onity/PHH' },
  { street: '4321 Elm St', city: 'Houston', state: 'TX', zip: '77002', phase: 'pre', investor: 'SPS' },
]

const PHASE_COUNTS: Record<Phase, number> = { pre: 88, on: 79, contract: 31, closing: 17, sold: 21 }

function makeProperty(i: number, phase: Phase, seed?: Partial<Property>): Property {
  const c = seed?.city ? CITIES.find((x) => x[0] === seed.city)! : pick(CITIES)
  const [city, state, zp, msa] = c
  const street = seed?.street ?? `${int(100, 9899)} ${pick(STREETS)}`
  const listBase = state === 'CA' ? 600000 : int(9, 52) * 10000 + int(0, 9) * 1000
  const stage =
    phase === 'pre' ? pick([2, 3, 3, 4, 4]) : phase === 'on' ? pick([5, 5, 6]) : phase === 'contract' ? 7 : phase === 'closing' ? 8 : 9
  const daysInInventory =
    phase === 'pre' ? int(3, 45) : phase === 'on' ? int(40, 140) : phase === 'contract' ? int(70, 170) : phase === 'closing' ? int(90, 190) : int(110, 220)
  const dom = phase === 'pre' ? null : phase === 'on' ? int(3, 28) : int(18, 80)
  const listed = phase !== 'pre'
  const bids = listed ? int(0, 7) : 0
  return {
    id: `P${String(i + 1).padStart(3, '0')}`,
    loan: `${pick(['0021', '0032', '7143', 'SPS1', 'LN00'])}${String(int(100000, 999999))}`,
    street,
    city,
    state,
    zip: seed?.zip ?? `${zp}${int(10, 99)}`,
    msa,
    investor: seed?.investor ?? pick(INVESTORS),
    phase,
    stage,
    daysInInventory,
    daysInPhase: Math.max(1, Math.round(daysInInventory * (phase === 'pre' ? 0.9 : 0.4))),
    dom,
    listPrice: listed ? listBase : null,
    valuation: stage >= 4 ? Math.round((listBase * (1 + (rnd() - 0.45) * 0.08)) / 1000) * 1000 : null,
    prevHighOffer: bids > 0 ? Math.round((listBase * (0.82 + rnd() * 0.12)) / 500) * 500 : null,
    bids,
    bidders: Math.max(0, bids - int(0, 2)),
    broker: BROKERS[state] ?? 'Keystone REO Brokers',
    occupancy: phase === 'pre' ? pick(['Vacant', 'Vacant', 'Vacant', 'Vacant', 'Occupied', 'Unknown']) : 'Vacant',
    type: pick(TYPES),
    beds: int(2, 5),
    baths: int(1, 3),
    sqft: int(9, 32) * 100,
    titleTrack: false,
    hubzuId: listed ? `H${int(2100000, 2199999)}` : null,
  }
}

function buildProperties(): Property[] {
  const out: Property[] = []
  SEEDED.forEach((s) => out.push(makeProperty(out.length, s.phase as Phase, s)))
  ;(Object.keys(PHASE_COUNTS) as Phase[]).forEach((ph) => {
    const already = out.filter((p) => p.phase === ph).length
    for (let k = already; k < PHASE_COUNTS[ph]; k++) out.push(makeProperty(out.length, ph))
  })
  // Title runs as a parallel track: all closings + 7 contracts.
  let contractTitle = 0
  out.forEach((p) => {
    if (p.phase === 'closing') p.titleTrack = true
    if (p.phase === 'contract' && contractTitle < 7) { p.titleTrack = true; contractTitle++ }
  })
  // Pin seeded facts that the wireframes show.
  const maple = out[0]
  Object.assign(maple, {
    loan: 'SPS1234567', stage: 5, daysInInventory: 72, daysInPhase: 40, dom: 42, listPrice: 425000,
    valuation: 404000, prevHighOffer: 380000, bids: 5, bidders: 3, type: 'Single Family', beds: 4,
    baths: 2, sqft: 2140, occupancy: 'Vacant', hubzuId: 'H2123456', msa: 'Phoenix–Mesa',
  })
  Object.assign(out[1], { loan: 'LN005678', stage: 3, daysInInventory: 22, occupancy: 'Vacant' })
  Object.assign(out[2], { loan: 'LN009101', stage: 5, dom: 32, listPrice: 289000, bids: 1, bidders: 1 })
  Object.assign(out[3], { loan: 'LN002222', stage: 5, dom: 47, listPrice: 254900 })
  Object.assign(out[4], { loan: 'LN003456', stage: 6, dom: 19, listPrice: 336000, bids: 4, bidders: 4, prevHighOffer: 331000 })
  Object.assign(out[5], { loan: 'LN007890', stage: 6, dom: 24, listPrice: 219900, bids: 3, bidders: 2, prevHighOffer: 214000 })
  Object.assign(out[6], { loan: 'LN001500', stage: 8, listPrice: 389000, titleTrack: true })
  Object.assign(out[7], { loan: 'LN004321', stage: 2, daysInInventory: 9, occupancy: 'Occupied' })
  // Keep valuations and best offers consistent with the overridden list prices.
  ;[2, 3, 6].forEach((i) => { const l = out[i].listPrice!; out[i].valuation = Math.round((l * 1.015) / 1000) * 1000; out[i].prevHighOffer = out[i].bids ? Math.round((l * 0.9) / 500) * 500 : null })
  ;[4, 5].forEach((i) => { out[i].valuation = Math.round((out[i].listPrice! * 1.02) / 1000) * 1000 })
  return out
}

export const PROPERTIES: Property[] = buildProperties()
export const propertyById = (id: string) => PROPERTIES.find((p) => p.id === id)!

// ---------- work items ----------
let wid = 0
const W = (p: Property, w: Omit<WorkItem, 'id' | 'propertyId'>): WorkItem => ({ id: `W${++wid}`, propertyId: p.id, ...w })

function take(phase: Phase, n: number, used: Set<string>, filter: (p: Property) => boolean = () => true) {
  const res: Property[] = []
  for (const p of PROPERTIES) {
    if (res.length >= n) break
    if (p.phase === phase && !used.has(p.id) && filter(p)) { res.push(p); used.add(p.id) }
  }
  return res
}

function buildItems(): WorkItem[] {
  const used = new Set<string>()
  const items: WorkItem[] = []
  const P = PROPERTIES
  const mark = (p: Property) => used.add(p.id)
  // Reserve the hand-seeded files so generic picks never double-assign them.
  P.slice(0, SEEDED.length).forEach(mark)

  // --- Exceptions (39) ---
  // Trash-out not complete, 15+ days (10)
  mark(P[1])
  const trash = [P[1], ...take('pre', 9, used, (p) => p.occupancy === 'Vacant')]
  trash.forEach((p, i) => {
    const d = i === 0 ? 22 : [15, 16, 17, 18, 19, 21, 24, 26, 28][i - 1]
    p.daysInInventory = d; p.stage = 3; p.occupancy = 'Vacant'
    items.push(W(p, {
      queue: 'exceptions', signal: 'trashout', reason: 'Trash-out not complete',
      detail: `Ordered with Triple R ${Math.max(3, d - 9)}d ago · no completion photos`, days: d, slaDays: 15,
      risk: d >= 20 ? 'High' : 'Medium', nextAction: 'Follow up with Triple R', actionKind: 'vendor',
      counterparty: 'Triple R', status: 'Waiting External',
    }))
  })
  // Initial valuation incomplete: 7 BD from order (3)
  take('pre', 3, used).forEach((p, i) => {
    const d = [9, 11, 14][i]
    p.daysInInventory = d + 4; p.stage = 4; p.valuation = null
    items.push(W(p, {
      queue: 'exceptions', signal: 'novalue', reason: 'Initial valuation incomplete',
      detail: `BPO ordered ${d} BD ago · ValuePoint BPO`, days: d, slaDays: 7,
      risk: d >= 12 ? 'High' : 'Medium', nextAction: 'Request BPO status', actionKind: 'vendor',
      counterparty: 'BPO vendor', status: 'Waiting External',
    }))
  })
  // Eviction (4)
  mark(P[7])
  const evic = [P[7], ...take('pre', 2, used)]
  evic.forEach((p, i) => {
    p.occupancy = 'Occupied'; p.stage = 2
    const routed = i >= 2
    const d = [4, 3, 33][i]
    p.daysInInventory = Math.max(p.daysInInventory, d + 2)
    items.push(W(p, {
      queue: 'exceptions', signal: 'eviction',
      reason: routed ? 'Eviction check-in due' : 'Eviction initiation delayed',
      detail: routed ? `Last ESD check-in ${d} days ago · attorney status unknown` : `Occupancy came back occupied ${d} BD ago · ESD not engaged`,
      days: d, slaDays: routed ? 30 : 2, risk: 'High',
      nextAction: routed ? 'Request ESD status' : 'Route to ESD (Pam’s team)', actionKind: 'eviction',
      counterparty: 'ESD · Pam’s team', status: routed ? 'Waiting External' : 'Review Required',
    }))
  })
  // Investor response overdue (9): 3 initial listing (pre) + 6 reduction (on)
  take('pre', 2, used).forEach((p, i) => {
    const d = [3, 5][i]
    p.stage = 4
    items.push(W(p, {
      queue: 'exceptions', signal: 'investor', reason: 'Initial listing approval pending', followUps: d - 2,
      detail: `Sent to ${p.investor} ${d} BD ago · no response`, days: d, slaDays: 2,
      risk: d >= 5 ? 'High' : 'Medium', nextAction: 'Send investor follow-up', actionKind: 'investor',
      counterparty: p.investor, status: 'Approval Pending',
    }))
  })
  mark(P[3])
  const invOn = [P[3], ...take('on', 2, used)]
  invOn.forEach((p, i) => {
    const d = [16, 4, 6][i]
    items.push(W(p, {
      queue: 'exceptions', signal: 'investor', reason: i === 2 ? 'Offer approval pending' : 'Reduction request pending', followUps: d - 2,
      detail: `${i === 2 ? 'Offer approval' : `Requested −${(4 + i * 0.75).toFixed(1)}%`} · sent ${d} BD ago`, days: d, slaDays: 2,
      risk: d >= 8 ? 'High' : 'Medium', nextAction: 'Send investor follow-up', actionKind: 'investor',
      counterparty: p.investor, status: 'Approval Pending',
    }))
  })
  // Price reduction due: 30+ DOM, no accepted offer (6)
  mark(P[0]); mark(P[2])
  const red = [P[0], P[2], ...take('on', 2, used)]
  red.forEach((p, i) => {
    if (i >= 2) { p.dom = [36, 44][i - 2]; p.stage = 5 }
    const d = p.dom! - 4
    items.push(W(p, {
      queue: 'exceptions', signal: 'reduction', reason: 'Reduction needed: no accepted offer',
      detail: `${d} days since last price change · ${p.bids} bids · ${p.bidders} bidders`,
      days: d, slaDays: 25, risk: d >= 40 ? 'High' : 'Medium', nextAction: 'Build reduction case',
      actionKind: 'recommendation', counterparty: p.investor, status: 'Review Required',
    }))
  })
  // Closing at risk (3)
  mark(P[6])
  const clo = [P[6], ...take('closing', 1, used)]
  const cloReasons = [
    ['Closing delayed — buyer not responding', 'Target close Oct 29 · per diem $85/day', 5],
    ['Title condition open — HOA lien', 'ResWare: lien payoff letter outstanding', 3],
    ['Closing date passed — amended date needed', 'Lender CD not issued · buyer financing', 2],
  ] as const
  clo.forEach((p, i) => {
    items.push(W(p, {
      queue: 'exceptions', signal: 'closing', reason: cloReasons[i][0], detail: cloReasons[i][1],
      days: cloReasons[i][2] + 2, slaDays: 3, risk: i === 0 ? 'High' : 'Medium',
      nextAction: 'Follow up with buyer / title', actionKind: 'closing', counterparty: 'Title · ResWare',
      status: 'Blocked',
    }))
  })

  // --- More exception types from the AM exception catalog (business-day rules) ---
  const X = (ph: Phase, n: number, f: (p: Property, i: number) => Omit<WorkItem, 'id' | 'propertyId'>, filter?: (p: Property) => boolean) =>
    take(ph, n, used, filter).forEach((p, i) => items.push(W(p, f(p, i))))
  X('pre', 2, (p, i) => { const d = [4, 5][i]; p.stage = 2; p.daysInInventory = d + 1
    return { queue: 'exceptions', signal: 'occupancy', reason: 'Initial occupancy delayed', detail: `Ordered with AFS ${d} BD ago · no result`, days: d, slaDays: 2, risk: 'High', nextAction: 'Chase occupancy result', actionKind: 'vendor', counterparty: 'AFS field services', status: 'Waiting External' } })
  X('pre', 1, (p) => { p.stage = 3
    return { queue: 'exceptions', signal: 'lockchange', reason: 'Lock change delayed', detail: 'Vacant confirmed 5 BD ago · re-key not confirmed', days: 5, slaDays: 3, risk: 'Medium', nextAction: 'Ask AFS to confirm re-key', actionKind: 'vendor', counterparty: 'AFS field services', status: 'Waiting External' } }, (p) => p.occupancy === 'Vacant')
  X('pre', 1, (p) => { p.stage = 4; p.valuation = null
    return { queue: 'exceptions', signal: 'valorder', reason: 'Initial valuation not ordered', detail: 'Lock change done 2 BD ago · no BPO order placed', days: 2, slaDays: 1, risk: 'Medium', nextAction: 'Order BPO', actionKind: 'vendor', counterparty: 'BPO vendor', status: 'Review Required' } })
  X('pre', 1, (p) => { p.stage = 4; const v = p.valuation ?? 212000; p.valuation = v
    return { queue: 'exceptions', signal: 'reconcile', reason: 'Listing reconciliation delayed', detail: `Both values in 3 BD ago · BPO ${money(v)} · bot-reviewed ${money(Math.round((v * 1.018) / 500) * 500)}`, days: 3, slaDays: 1, risk: 'Medium', nextAction: 'Agree value', actionKind: 'review', counterparty: 'Internal', status: 'Review Required' } })
  X('pre', 1, (p) => { p.stage = 4; p.valuation = p.valuation ?? 248000
    return { queue: 'exceptions', signal: 'initlist', reason: 'Initial listing delayed', detail: 'Value agreed and trash-out done 4 BD ago · not listed', days: 4, slaDays: 2, risk: 'High', nextAction: 'Send initial list request', actionKind: 'investor', counterparty: p.investor, status: 'Review Required' } })
  X('on', 1, () => ({ queue: 'exceptions', signal: 'relist', reason: 'Relisting delayed', detail: 'Hubzu auction ended 2 BD ago · no offers to negotiate', days: 2, slaDays: 1, risk: 'High', nextAction: 'Relist next cycle', actionKind: 'review', counterparty: 'Hubzu', status: 'Review Required' }), (p) => !!p.hubzuId)
  X('on', 2, (p, i) => { p.stage = 6; p.bids = Math.max(p.bids, 2); p.bidders = Math.max(p.bidders, 2); p.prevHighOffer = p.prevHighOffer ?? Math.round(((p.listPrice ?? 200000) * 0.93) / 500) * 500
    return { queue: 'exceptions', signal: 'offerreview', reason: i === 0 ? 'Offer review delayed (TLB auction)' : 'Offer review delayed', detail: i === 0 ? `Auction ended 2 BD ago · ${p.bids} offers received` : `Offer ${money(p.prevHighOffer)} received 3 BD ago`, days: i === 0 ? 2 : 3, slaDays: 1, risk: 'High', nextAction: 'Review offer', actionKind: 'review', counterparty: p.investor, status: 'Review Required' } })
  X('on', 1, (p) => { p.dom = 64
    return { queue: 'exceptions', signal: 'rma', reason: 'Revised marketing assessment due', detail: '64 DOM with no offer · reassess every 30 days after day 60', days: 64, slaDays: 60, risk: 'Medium', nextAction: 'Prepare marketing assessment', actionKind: 'recommendation', counterparty: p.investor, status: 'Review Required' } })
  X('on', 1, (p) => { p.dom = 126
    return { queue: 'exceptions', signal: 'broker', reason: 'Broker change review', detail: `126 DOM with no offer · ${p.broker}`, days: 126, slaDays: 120, risk: 'Medium', nextAction: 'Review broker performance', actionKind: 'review', counterparty: 'Internal', status: 'Review Required' } })
  X('on', 1, () => ({ queue: 'exceptions', signal: 'uvdue', reason: 'Updated value order due', detail: 'Last BPO 77 days ago · refresh every 75 days', days: 77, slaDays: 75, risk: 'Low', nextAction: 'Order updated BPO', actionKind: 'vendor', counterparty: 'BPO vendor', status: 'Review Required' }))
  X('pre', 1, (p) => { p.occupancy = 'Occupied'; p.stage = 2
    return { queue: 'exceptions', signal: 'occreview', reason: 'Occupancy review due', detail: 'Occupied · last occupancy check 31 days ago', days: 31, slaDays: 30, risk: 'Low', nextAction: 'Request occupancy update', actionKind: 'vendor', counterparty: 'AFS field services', status: 'Review Required' } })
  X('contract', 1, () => ({ queue: 'exceptions', signal: 'pts', reason: 'Confirm PTS closing update in Equator', detail: 'Contract executed · no closing update in 6 BD', days: 6, slaDays: 5, risk: 'Medium', nextAction: 'Confirm closing status', actionKind: 'review', counterparty: 'Title · ResWare', status: 'Review Required' }))
  X('contract', 1, () => ({ queue: 'exceptions', signal: 'relistcancel', reason: 'Relist after contract cancellation', detail: 'Buyer cancelled 2 BD ago · financing denied', days: 2, slaDays: 1, risk: 'High', nextAction: 'Relist on Hubzu', actionKind: 'review', counterparty: 'Hubzu', status: 'Review Required' }), (p) => !p.titleTrack)

  // --- Actions Ready (12) ---
  mark(P[5])
  const offerProps = [P[5], ...take('on', 2, used)]
  const offers = [
    { amount: 214000, financing: 'Conventional', buyer: 'A. Peterson', type: 'accept' as const, ago: '2 h ago' },
    { amount: 312500, financing: 'Cash', buyer: 'Harbor Homes LLC', type: 'counter' as const, ago: '47 min ago' },
    { amount: 189900, financing: 'FHA', buyer: 'J. Ramirez', type: 'accept' as const, ago: '3 h ago' },
  ]
  offerProps.forEach((p, i) => {
    const o = offers[i]
    p.stage = 6
    if (i > 0) { p.listPrice = Math.round((o.amount * 1.04) / 1000) * 1000; p.prevHighOffer = o.amount; p.bids = Math.max(p.bids, 2) }
    items.push(W(p, {
      queue: 'actions', actToday: true, approvedAgo: o.ago,
      reason: o.type === 'accept' ? `${p.investor} approved acceptance — contract not sent` : `${p.investor} approved counter at ${money(o.amount)}`,
      detail: `${o.buyer} · ${o.financing} · ${money(o.amount)}`, days: 0, slaDays: 1, risk: 'High',
      nextAction: o.type === 'accept' ? 'Accept & send contract' : 'Send counter', actionKind: 'contract',
      counterparty: o.buyer, offer: { amount: o.amount, financing: o.financing, buyer: o.buyer, type: o.type },
      status: 'Ready',
    }))
  })
  take('pre', 2, used).forEach((p, i) => {
    items.push(W(p, {
      queue: 'actions', advance: 'Triple R bid to approve', reason: 'Triple R trash-out bid ready', detail: `Bid ${money([1850, 2340][i])} · 22 cu yd · photos attached`,
      days: 1, slaDays: 2, risk: 'Medium', nextAction: 'Approve bid', actionKind: 'approve', counterparty: 'Triple R', status: 'Ready',
    }))
  })
  take('pre', 2, used).forEach((p) => {
    p.stage = 4
    items.push(W(p, {
      queue: 'actions', advance: 'Marketing plan ready', reason: 'Marketing plan drafted by CMP agent', detail: 'List price, commissions and listing type prepared',
      days: 0, slaDays: 2, risk: 'Medium', nextAction: 'Review plan', actionKind: 'review', counterparty: 'CMP agent', status: 'Ready',
    }))
  })
  take('on', 2, used).forEach((p) => {
    items.push(W(p, {
      queue: 'actions', advance: 'Reduction case ready', reason: 'Price reduction analysis ready', detail: 'Review Marketing Plan agent · 82% confidence',
      days: 0, slaDays: 2, risk: 'Medium', nextAction: 'Review recommendation', actionKind: 'recommendation', counterparty: p.investor, status: 'Ready',
    }))
  })
  mark(P[4])
  items.push(W(P[4], {
    queue: 'actions', advance: 'Offer recommendation ready', reason: '4 offers received — H&B analysis ready', detail: 'Highest $331,000 cash · 2 above reserve',
    days: 1, slaDays: 1, risk: 'High', nextAction: 'Review offers', actionKind: 'review', counterparty: 'Offer Acceptance agent', status: 'Ready',
  }))
  take('pre', 1, used).forEach((p) => items.push(W(p, {
    queue: 'actions', advance: 'Ready to list', reason: 'Listing agreement received from broker', detail: 'Signed by broker · ready for Hubzu',
    days: 1, slaDays: 2, risk: 'Low', nextAction: 'Approve & send to Hubzu', actionKind: 'approve', counterparty: p.broker, status: 'Ready',
  })))
  take('closing', 1, used).forEach((p) => items.push(W(p, {
    queue: 'actions', advance: 'Closing review', reason: 'Final HUD ready for review', detail: 'Seller credits $3,200 · per diem none',
    days: 0, slaDays: 1, risk: 'Medium', nextAction: 'Review settlement', actionKind: 'review', counterparty: 'Title · ResWare', status: 'Ready',
  })))

  take('pre', 2, used).forEach((p, i) => { p.stage = 4; const v = [149000, 318000][i]; p.valuation = v
    items.push(W(p, {
      queue: 'actions', advance: 'Values ready to agree', reason: 'Values in: agree the marketing value', detail: `BPO ${money(v)} · bot-reviewed ${money(Math.round((v * 1.02) / 500) * 500)} · within 2%`,
      days: 0, slaDays: 1, risk: 'Medium', nextAction: 'Agree value', actionKind: 'approve', counterparty: 'Internal', status: 'Ready',
    }))
  })
  take('on', 1, used, (p) => !!p.hubzuId).forEach((p) => items.push(W(p, {
    queue: 'actions', advance: 'Equator task to complete', reason: 'Set reserve price: Equator task open', detail: 'Agent prepared reserve · 2 Equator fields still required',
    days: 1, slaDays: 1, risk: 'High', nextAction: 'Complete reserve task', actionKind: 'review', counterparty: 'Equator', status: 'Ready',
  })))
  take('pre', 1, used, (p) => p.occupancy === 'Vacant').forEach((p) => { p.stage = 2
    items.push(W(p, {
      queue: 'actions', advance: 'Occupancy result in: route the file', reason: 'Occupancy result: vacant', detail: 'Order Triple R initial services and AFS re-secure',
      days: 0, slaDays: 1, risk: 'Medium', nextAction: 'Order services', actionKind: 'approve', counterparty: 'Triple R', status: 'Ready',
    }))
  })

  // --- Approvals Waiting (7) ---
  const appr: [Phase, string, number][] = [
    ['on', 'Reduction request', 1], ['on', 'Reduction request', 2], ['pre', 'Initial listing approval', 1],
    ['pre', 'Marketing plan approval', 0], ['on', 'Offer acceptance request', 0], ['on', 'Counter approval', 1], ['pre', 'Initial listing approval', 2],
  ]
  appr.forEach(([ph, what, d]) => take(ph, 1, used).forEach((p) => items.push(W(p, {
    queue: 'approvals', followUps: Math.max(0, d - 1), reason: `${what} · with ${p.investor}`, detail: d === 0 ? 'Sent today · Day 3 follow-up scheduled' : `Sent ${d}d ago · follow-up on day 3`,
    days: d, slaDays: 2, risk: 'Low', nextAction: 'View package', actionKind: 'view', counterparty: p.investor, status: 'Approval Pending',
  }))))

  // --- Watchlist (14) ---
  take('pre', 4, used).forEach((p, i) => {
    const d = [4, 5, 5, 6][i]
    p.daysInInventory = d + 3; p.stage = 4; p.valuation = null
    items.push(W(p, {
      queue: 'watch', signal: 'novalue', approaching: true, reason: 'Valuation pending: nearing the 7 BD limit',
      detail: `BPO ordered ${d} BD ago`, days: d, slaDays: 7, risk: 'Low', nextAction: 'Request BPO status', actionKind: 'vendor',
      counterparty: 'BPO vendor', status: 'Waiting External',
    }))
  })
  take('pre', 4, used).forEach((p, i) => {
    p.occupancy = 'Occupied'; p.stage = 2
    items.push(W(p, {
      queue: 'watch', reason: 'Eviction in progress', detail: `Hearing ${['Nov 12', 'Nov 18', 'Dec 2', 'Nov 21'][i]} · ESD weekly check-in on track`,
      days: [3, 5, 2, 6][i], slaDays: 7, risk: 'Low', nextAction: 'View', actionKind: 'view', counterparty: 'ESD · Pam’s team', status: 'Waiting External',
    }))
  })
  take('pre', 3, used).forEach((p, i) => items.push(W(p, {
    queue: 'watch', reason: 'Initial services in progress', detail: `Triple R confirmed · re-check in ${[18, 41, 66][i]} h`,
    days: [2, 1, 1][i], slaDays: 3, risk: 'Low', nextAction: 'View', actionKind: 'view', counterparty: 'Triple R', status: 'Waiting External',
  })))
  take('contract', 3, used, (p) => p.titleTrack).forEach((p, i) => items.push(W(p, {
    queue: 'watch', reason: 'Title search in progress', detail: `ResWare · commitment expected ${['Nov 5', 'Nov 6', 'Nov 8'][i]}`,
    days: [4, 3, 1][i], slaDays: 10, risk: 'Low', nextAction: 'View', actionKind: 'view', counterparty: 'Title · ResWare', status: 'Waiting External',
  })))

  return items
}

export function money(n: number | null | undefined, opts: { compact?: boolean } = {}) {
  if (n == null) return '—'
  if (opts.compact && Math.abs(n) >= 1000) return `${n < 0 ? '−' : ''}$${(Math.abs(n) / 1000).toFixed(n % 1000 === 0 ? 0 : 1)}k`
  return n.toLocaleString('en-US', { style: 'currency', currency: 'USD', maximumFractionDigits: 0 })
}

export const INITIAL_ITEMS: WorkItem[] = buildItems()

// ---------- Exception catalog (AM exception list · business-day SLAs) ----------
// Each type says when it fires, who owns the fix, the recommended resolution and the one-click action.
export interface SignalDef {
  key: SignalKey
  title: string
  /** Rule from the AM exception catalog, e.g. "15 BD from initiation, 2 BD afterwards". */
  rule: string
  threshold: string
  owner: string
  stage: string
  /** Recommended resolution shown next to every exception of this type. */
  resolution: string
  /** One-click button label. */
  action: string
  kind: 'admin' | 'advance'
  /** Price-related decisions get the market-data bullet picker. */
  market?: boolean
  guideline: string
  agent: string
  cta: (n: number) => string
  sentLabel: (n: number) => string
  severity: 'critical' | 'serious'
  recheck: string
  phase: Phase
  template: { name: string; to: string; toEmail: string; cc: string; subject: (n: number) => string; intro: string; ask: string }
}

const T = (name: string, to: string, toEmail: string, subject: (n: number) => string, intro: string, ask: string, cc = 'Srini') => ({ name, to, toEmail, cc, subject, intro, ask })
const plural = (n: number, one: string, many = `${one}s`) => `${n} ${n === 1 ? one : many}`

export const SIGNALS: SignalDef[] = [
  { key: 'trashout', title: 'Initial trash-out incomplete', rule: '15 BD from initiation, then every 2 BD', threshold: '15 BD from initiation', owner: 'Triple R', stage: 'Preservation',
    resolution: 'Send the trash-out status request to Triple R', action: 'Send follow-up', kind: 'admin', guideline: 'GL-PRS-03', agent: 'Pre-Marketing Agent',
    cta: (n) => `Review & send ${n}`, sentLabel: (n) => `${plural(n, 'follow-up')} sent to Triple R`, severity: 'critical', recheck: '2 BD', phase: 'pre',
    template: T('TR-TRASHOUT-01 · Trash-out follow-up', 'Triple R Operations', 'dispatch@triple-r.example', (n) => `Status request: trash-out for ${plural(n, 'property', 'properties')} past 15 BD`,
      'The properties below have passed our 15 business-day target without a completed trash-out.', 'Please confirm for each: has the debris been removed, has lawn service been done, and is the property safe to bring to market? Reply with an expected completion date where work is still open.') },
  { key: 'novalue', title: 'Initial valuation incomplete', rule: '7 BD from initiation, then every 2 BD', threshold: '7 BD from order', owner: 'BPO vendor', stage: 'Valuation',
    resolution: 'Ask the BPO vendor for the missing value (simple follow-up, no report)', action: 'Send follow-up', kind: 'admin', guideline: 'GL-VAL-01', agent: 'BPO Review Agent',
    cta: (n) => `Review & send ${n}`, sentLabel: (n) => `${plural(n, 'valuation request')} sent`, severity: 'critical', recheck: '2 BD', phase: 'pre',
    template: T('VAL-MISSING-01 · Valuation outstanding', 'ValuePoint BPO', 'orders@valuepoint.example', (n) => `Outstanding BPO: ${plural(n, 'property', 'properties')} past 7 BD`,
      'We have not yet received valuations for the properties below, which are past our 7 business-day target.', 'Please send each report, or an expected delivery date, today.', 'Triple R Operations') },
  { key: 'investor', title: 'Investor follow-up due', rule: '2 BD from submission, then every BD', threshold: '2 BD from submission', owner: 'Investor', stage: 'With investor',
    resolution: 'Send the daily investor nudge with days outstanding (cc REO management)', action: 'Send nudge', kind: 'admin', guideline: 'GL-INV-01', agent: 'Customer/Investor Approval Agent',
    cta: (n) => `Send ${plural(n, 'nudge')}`, sentLabel: (n) => `${plural(n, 'investor nudge')} sent`, severity: 'critical', recheck: '1 BD', phase: 'on',
    template: T('INV-NUDGE-01 · Decision reminder', 'Investor approvals team', 'reo-approvals@investor.example', (n) => `Decision needed: ${plural(n, 'outstanding request')}`,
      'The requests below remain outstanding. Each package was complete at submission and includes current market analysis.', 'Please review and respond today. Extended delays are adding days on market and putting active buyer interest at risk.', 'REO Client Manager') },
  { key: 'reduction', title: 'Reduction needed', rule: '25 days since the last list-price adjustment', threshold: '25 days since last price change', owner: 'Investor', stage: 'On market',
    resolution: 'Request an investor-approved reduction with a market summary', action: 'Review reduction', kind: 'advance', market: true, guideline: 'GL-RED-02', agent: 'Review Marketing Plan Agent',
    cta: (n) => `Build ${plural(n, 'reduction case')}`, sentLabel: (n) => `${plural(n, 'reduction request')} prepared`, severity: 'critical', recheck: '1 BD', phase: 'on',
    template: T('INV-REDUCTION-01 · Reduction request', 'Investor approvals team', 'reo-approvals@investor.example', (n) => `Request for approval: list price reductions (${plural(n, 'property', 'properties')})`,
      'Based on current market conditions, property performance and investor guidelines, we recommend the reductions below.', 'A market summary with the supporting data points is included for each property.', 'REO Client Manager') },
  { key: 'eviction', title: 'Eviction initiation / check-in', rule: '2 BD from occupancy received (daily after); check-in every 30 days', threshold: '2 BD from occupied result', owner: 'ESD (Pam’s team)', stage: 'Eviction (ESD)',
    resolution: 'Send the ESD eviction referral, or the 30-day status check', action: 'Send to ESD', kind: 'admin', guideline: 'GL-EVC-01', agent: 'CFK / Eviction Agent',
    cta: (n) => `Route ${plural(n, 'file')} to ESD`, sentLabel: (n) => `${plural(n, 'file')} routed to ESD`, severity: 'critical', recheck: '1 BD', phase: 'pre',
    template: T('ESD-REFERRAL-01 · Eviction referral / check-in', 'ESD Eviction Desk', 'desk@esd.example', (n) => `Eviction referral / status: ${plural(n, 'occupied property', 'occupied properties')}`,
      'The properties below are confirmed occupied and either need an eviction referral or are due their 30-day check-in.', 'Please confirm attorney engagement, the latest inspection, and whether an updated value is needed.') },
  { key: 'closing', title: 'Delayed closing review', rule: '3 BD after the HUD approval task is finalized', threshold: '3 BD after HUD approval', owner: 'Title · buyer agent', stage: 'Closing',
    resolution: 'Ask title and the buyer agent for the amended date and open conditions', action: 'Send follow-up', kind: 'admin', guideline: 'GL-CLS-02', agent: 'Closing Monitor',
    cta: (n) => `Follow up on ${plural(n, 'closing')}`, sentLabel: (n) => `${plural(n, 'closing follow-up')} sent`, severity: 'serious', recheck: '1 BD', phase: 'closing',
    template: T('CLS-DELAY-01 · Closing status', 'Title & buyer agents', 'closings@title.example', (n) => `Closing status needed: ${plural(n, 'file')} past target`,
      'The closings below are past target or blocked by an open condition.', 'Please confirm the amended closing date, outstanding conditions and any per diem owed by the buyer.', 'Closing team') },
  { key: 'occupancy', title: 'Delayed initial occupancy', rule: '2 BD from initiation, then daily', threshold: '2 BD from order', owner: 'AFS field services', stage: 'Occupancy',
    resolution: 'Chase the occupancy result with field services', action: 'Send follow-up', kind: 'admin', guideline: 'GL-OCC-01', agent: 'Pre-Marketing Agent',
    cta: (n) => `Review & send ${n}`, sentLabel: (n) => `${plural(n, 'occupancy follow-up')} sent`, severity: 'critical', recheck: '1 BD', phase: 'pre',
    template: T('AFS-OCC-01 · Occupancy result', 'AFS Field Services', 'occupancy@afs.example', (n) => `Occupancy result overdue: ${plural(n, 'property', 'properties')}`,
      'Occupancy inspections for the properties below were ordered and are past our 2 business-day target.', 'Please send the occupancy result (occupied / vacant, with photos) today.') },
  { key: 'lockchange', title: 'Lock change delayed', rule: '3 BD from occupancy confirmation, then daily', threshold: '3 BD from vacant', owner: 'AFS field services', stage: 'Preservation',
    resolution: 'Ask AFS to confirm the re-key', action: 'Send follow-up', kind: 'admin', guideline: 'GL-PRS-02', agent: 'Pre-Marketing Agent',
    cta: (n) => `Review & send ${n}`, sentLabel: (n) => `${plural(n, 'lock-change follow-up')} sent`, severity: 'serious', recheck: '1 BD', phase: 'pre',
    template: T('AFS-RESECURE-01 · Re-key confirmation', 'AFS Field Services', 'resecure@afs.example', (n) => `Re-key confirmation needed: ${plural(n, 'property', 'properties')}`,
      'The properties below were confirmed vacant and are past our 3 business-day target for the lock change.', 'Please confirm the re-key date and lockbox code.') },
  { key: 'valorder', title: 'Initial valuation not ordered', rule: '1 BD from lock change date', threshold: '1 BD from lock change', owner: 'Internal', stage: 'Valuation',
    resolution: 'Order the BPO now (agent prefilled the order)', action: 'Order BPO', kind: 'advance', guideline: 'GL-VAL-00', agent: 'BPO Review Agent',
    cta: (n) => `Order ${plural(n, 'BPO')}`, sentLabel: (n) => `${plural(n, 'BPO')} ordered`, severity: 'serious', recheck: '7 BD', phase: 'pre',
    template: T('VAL-ORDER-01 · BPO order', 'ValuePoint BPO', 'orders@valuepoint.example', (n) => `New BPO order: ${plural(n, 'property', 'properties')}`,
      'Please complete an interior/exterior BPO for the properties below.', 'Lockbox codes are attached. Target delivery is 7 business days.') },
  { key: 'reconcile', title: 'Delayed listing reconciliation', rule: '1 BD from receipt of both initial values, then every BD', threshold: '1 BD after both values', owner: 'Internal', stage: 'Valuation',
    resolution: 'Agree the marketing value (BPO and bot-reviewed value within 2%)', action: 'Agree value', kind: 'advance', guideline: 'GL-VAL-03', agent: 'Complete Marketing Plan Agent',
    cta: (n) => `Agree ${plural(n, 'value')}`, sentLabel: (n) => `${plural(n, 'value')} agreed`, severity: 'serious', recheck: '1 BD', phase: 'pre',
    template: T('INT-VALUE-01 · Value agreement', 'Equator', 'equator', (n) => `Value agreement: ${plural(n, 'file')}`, 'Values agreed in Control Tower.', 'Written to Equator.') },
  { key: 'initlist', title: 'Delayed initial listing', rule: '2 BD from reconciliation and trash-out completion, then every BD', threshold: '2 BD from ready', owner: 'Investor', stage: 'Listing',
    resolution: 'Send the initial list request with a market summary', action: 'Review list request', kind: 'advance', market: true, guideline: 'GL-LST-01', agent: 'Complete Marketing Plan Agent',
    cta: (n) => `Send ${plural(n, 'list request')}`, sentLabel: (n) => `${plural(n, 'initial list request')} sent`, severity: 'critical', recheck: '2 BD', phase: 'pre',
    template: T('INV-INITLIST-01 · Initial list approval', 'Investor approvals team', 'reo-approvals@investor.example', (n) => `Initial list approval: ${plural(n, 'property', 'properties')}`,
      'The properties below are cleaned out, valued and ready to list.', 'Please approve the initial list price. A market summary is included for each property.', 'REO Client Manager') },
  { key: 'relist', title: 'Delayed relisting', rule: '1 BD from auction end date, when there are no offers to negotiate', threshold: '1 BD after auction end', owner: 'Hubzu', stage: 'On market',
    resolution: 'Relist next Hubzu cycle with the reserve adjusted to market', action: 'Review relist', kind: 'advance', market: true, guideline: 'GL-AUC-02', agent: 'Set Reserve Price Agent',
    cta: (n) => `Relist ${plural(n, 'property', 'properties')}`, sentLabel: (n) => `${plural(n, 'property', 'properties')} relisted`, severity: 'critical', recheck: '1 BD', phase: 'on',
    template: T('HUB-RELIST-01 · Relist', 'Hubzu listings', 'listings@hubzu.example', (n) => `Relist request: ${plural(n, 'property', 'properties')}`, 'Please relist the properties below in the next auction cycle.', 'Reserve and start bid are included.') },
  { key: 'offerreview', title: 'Delayed offer review', rule: 'TLB: 1 BD from auction end with offers · NTLB: 1 BD from offer receipt; then every BD', threshold: '1 BD from offers', owner: 'Investor', stage: 'Offers',
    resolution: 'Review the offer recommendation and send it for approval with market support', action: 'Review offer', kind: 'advance', market: true, guideline: 'GL-OFR-01', agent: 'Offer Acceptance Agent',
    cta: (n) => `Review ${plural(n, 'offer')}`, sentLabel: (n) => `${plural(n, 'offer recommendation')} sent`, severity: 'critical', recheck: '1 BD', phase: 'on',
    template: T('INV-OFFER-01 · Offer approval', 'Investor approvals team', 'reo-approvals@investor.example', (n) => `Offer approval: ${plural(n, 'property', 'properties')}`,
      'We recommend the offer actions below.', 'Net-to-seller and market context are included for each.', 'REO Client Manager') },
  { key: 'rma', title: 'Revised marketing assessment', rule: '60 DOM with no offer, then every 30 days', threshold: '60 DOM, no offer', owner: 'Internal', stage: 'On market',
    resolution: 'Prepare the revised marketing assessment (price, listing type, broker)', action: 'Review assessment', kind: 'advance', market: true, guideline: 'GL-RMP-04', agent: 'Review Marketing Plan Agent',
    cta: (n) => `Review ${plural(n, 'assessment')}`, sentLabel: (n) => `${plural(n, 'assessment')} submitted`, severity: 'serious', recheck: '30 days', phase: 'on',
    template: T('INV-RMA-01 · Revised marketing plan', 'Investor approvals team', 'reo-approvals@investor.example', (n) => `Revised marketing assessment: ${plural(n, 'property', 'properties')}`,
      'The properties below have passed 60 days on market without an offer.', 'Our revised plan and market summary are included.', 'REO Client Manager') },
  { key: 'broker', title: 'Broker change review', rule: '120 DOM with no offer, then every 30 days', threshold: '120 DOM, no offer', owner: 'Internal', stage: 'On market',
    resolution: 'Review broker performance and propose a change if warranted', action: 'Review broker', kind: 'admin', guideline: 'GL-BRK-01', agent: 'Asset Management Agent',
    cta: (n) => `Review ${plural(n, 'broker')}`, sentLabel: (n) => `${plural(n, 'broker review')} logged`, severity: 'serious', recheck: '30 days', phase: 'on',
    template: T('BRK-REVIEW-01 · Broker review', 'Broker network team', 'brokers@reo.example', (n) => `Broker change review: ${plural(n, 'property', 'properties')}`, 'The listings below have passed 120 days on market with no offer.', 'Please review broker activity and recommend whether to reassign.') },
  { key: 'uvdue', title: 'Updated value order due', rule: 'Order every 75 days · overdue 7 BD after order, then every 2 BD', threshold: '75 days since last value', owner: 'BPO vendor', stage: 'On market',
    resolution: 'Order the updated BPO', action: 'Order BPO', kind: 'admin', guideline: 'GL-VAL-05', agent: 'BPO Review Agent',
    cta: (n) => `Order ${plural(n, 'update')}`, sentLabel: (n) => `${plural(n, 'updated BPO')} ordered`, severity: 'serious', recheck: '7 BD', phase: 'on',
    template: T('VAL-UPDATE-01 · Updated BPO', 'ValuePoint BPO', 'orders@valuepoint.example', (n) => `Updated BPO order: ${plural(n, 'property', 'properties')}`, 'Please complete updated BPOs for the properties below.', 'Target delivery is 7 business days.') },
  { key: 'occreview', title: 'Occupancy review / follow-up', rule: 'Every 30 days for occupied assets', threshold: '30 days', owner: 'AFS field services', stage: 'Eviction (ESD)',
    resolution: 'Request the 30-day occupancy update', action: 'Send follow-up', kind: 'admin', guideline: 'GL-OCC-02', agent: 'Pre-Marketing Agent',
    cta: (n) => `Review & send ${n}`, sentLabel: (n) => `${plural(n, 'occupancy update request')} sent`, severity: 'serious', recheck: '30 days', phase: 'pre',
    template: T('AFS-OCC-02 · Occupancy update', 'AFS Field Services', 'occupancy@afs.example', (n) => `30-day occupancy update: ${plural(n, 'property', 'properties')}`, 'The occupied properties below are due their 30-day occupancy check.', 'Please confirm occupancy status with photos.') },
  { key: 'pts', title: 'Confirm PTS closing update in Equator', rule: 'Every 5 BD from contract execution to close', threshold: '5 BD', owner: 'Internal', stage: 'Under contract',
    resolution: 'Confirm the closing status and write it to Equator', action: 'Confirm status', kind: 'admin', guideline: 'GL-CLS-01', agent: 'Closing Monitor',
    cta: (n) => `Confirm ${plural(n, 'update')}`, sentLabel: (n) => `${plural(n, 'closing update')} confirmed`, severity: 'serious', recheck: '5 BD', phase: 'contract',
    template: T('INT-PTS-01 · Closing update', 'Equator', 'equator', (n) => `Closing update: ${plural(n, 'file')}`, 'Closing status confirmed in Control Tower.', 'Written to Equator.') },
  { key: 'relistcancel', title: 'Delayed relist after contract cancellation', rule: '1 BD from contract cancellation, then every BD', threshold: '1 BD from cancellation', owner: 'Hubzu', stage: 'Under contract',
    resolution: 'Relist at the current price and notify backup offers', action: 'Review relist', kind: 'advance', market: true, guideline: 'GL-AUC-03', agent: 'Asset Management Agent',
    cta: (n) => `Relist ${plural(n, 'property', 'properties')}`, sentLabel: (n) => `${plural(n, 'property', 'properties')} relisted`, severity: 'critical', recheck: '1 BD', phase: 'contract',
    template: T('HUB-RELIST-02 · Relist after cancellation', 'Hubzu listings', 'listings@hubzu.example', (n) => `Relist after cancellation: ${plural(n, 'property', 'properties')}`, 'The contracts below were cancelled.', 'Please relist at the current price and notify backup offers.') },
]

export const signalDef = (k: SignalKey) => SIGNALS.find((s) => s.key === k)!

// ---------- Market (MSA) ----------
export const MARKET = {
  msa: 'Phoenix–Mesa MSA',
  source: 'Sample market feed (provider not yet selected)',
  asOf: 'Nov 3, 5:00 AM',
  metrics: [
    { key: 'inv', label: 'For-sale inventory', value: '8,421', delta: '+12%', dir: 'up', bad: true, spark: [6.9, 7.0, 7.1, 7.0, 7.3, 7.4, 7.6, 7.5, 7.8, 8.0, 8.2, 8.42] },
    { key: 'fall', label: 'Contract fallout rate', value: '18%', delta: '+4 pts', dir: 'up', bad: true, spark: [13, 14, 13, 14, 15, 15, 14, 16, 16, 17, 17, 18] },
    { key: 'red', label: 'Listings with reductions', value: '37%', delta: '+9 pts', dir: 'up', bad: true, spark: [26, 27, 28, 28, 29, 31, 31, 32, 33, 34, 36, 37] },
    { key: 'dom', label: 'Median days on market', value: '58', delta: '+14 d', dir: 'up', bad: true, spark: [41, 42, 44, 43, 46, 48, 49, 51, 52, 55, 56, 58] },
    { key: 'stl', label: 'Sale-to-list ratio', value: '96.2%', delta: '−2.1 pts', dir: 'down', bad: true, spark: [98.4, 98.3, 98.1, 98.0, 97.8, 97.6, 97.3, 97.1, 96.9, 96.6, 96.4, 96.2] },
  ],
}

// ---------- Systems ----------
export const SYSTEMS = [
  { name: 'Equator', role: 'Tasks, property, investor data', status: 'ok', sync: '9:38 AM' },
  { name: 'Hubzu', role: 'Listings, bids, offers, analytics', status: 'ok', sync: '9:37 AM' },
  { name: 'Palladium / AFS', role: 'Preservation, re-secure status', status: 'ok', sync: '9:36 AM' },
  { name: 'Triple R report', role: 'Occupancy, trash-out milestones', status: 'warn', sync: '6:00 AM' },
  { name: 'ResWare', role: 'Title & closing (read-only)', status: 'ok', sync: '9:31 AM' },
  { name: 'SAMS', role: 'Valuations', status: 'ok', sync: '9:30 AM' },
  { name: 'DocuSign', role: 'Listing agreements, contracts', status: 'ok', sync: '9:33 AM' },
] as const

export const KEY_DATES = [
  { mon: 'NOV', day: 3, title: 'Investor decision expected', who: '2222 Cedar Ln, Orlando', tag: 'Follow up', tone: 'orange' },
  { mon: 'NOV', day: 5, title: 'Contract expiration', who: '7890 Spruce Dr, Tampa', tag: 'At risk', tone: 'red' },
  { mon: 'NOV', day: 7, title: 'Closing date', who: '1500 Palm Way, Las Vegas', tag: 'Track', tone: 'blue' },
  { mon: 'NOV', day: 10, title: 'Price review (30 DOM)', who: '9101 Pine Rd, Atlanta', tag: 'Prepare', tone: 'yellow' },
] as const

// ---------- Agents ----------
export const AGENTS = [
  { key: 'pre', name: 'Pre-Marketing Monitor', desc: 'Watches occupancy, initial services, trash-out and securing progress. Flags delays and drafts vendor follow-ups.', mode: 'Shadow', impact: 'Advances property', eligible: 48, exceptions: 12, blockers: 3, last: '8:15 AM', phase: 'pre' },
  { key: 'cmp', name: 'Complete Marketing Plan', desc: 'Drafts the marketing plan with list price, commissions and listing type from valuations and investor rules.', mode: 'Supervised', impact: 'Saves admin time', eligible: 72, exceptions: 8, blockers: 5, last: '7:48 AM', phase: 'pre' },
  { key: 'reserve', name: 'Set Reserve Price', desc: 'Recommends auction reserve from valuations, market data and investor rules, then prepares the approval package.', mode: 'Shadow', impact: 'Saves admin time', eligible: 64, exceptions: 6, blockers: 4, last: '6:32 AM', phase: 'on' },
  { key: 'rmp', name: 'Review Marketing Plan', desc: 'Runs the 2-week review cadence. Recommends price reductions or amendments using MSA and Hubzu analytics.', mode: 'Supervised', impact: 'Advances property', eligible: 58, exceptions: 14, blockers: 7, last: '9:02 AM', phase: 'on' },
  { key: 'offer', name: 'Offer Acceptance', desc: 'Compares offers on net-to-seller, financing and history. Drafts the acceptance or counter request for the investor.', mode: 'Supervised', impact: 'Advances property', eligible: 36, exceptions: 9, blockers: 3, last: '7:21 AM', phase: 'on' },
  { key: 'investor', name: 'Investor Approval', desc: 'Tracks investor submissions, drafts day-3 and daily follow-ups, and monitors response times.', mode: 'Shadow', impact: 'Advances property', eligible: 52, exceptions: 18, blockers: 12, last: '8:45 AM', phase: 'on' },
  { key: 'closing', name: 'Closing Monitor', desc: 'Tracks contract-to-close milestones, title conditions, documents and per diem. Highlights required actions.', mode: 'Supervised', impact: 'Advances property', eligible: 28, exceptions: 7, blockers: 6, last: '9:02 AM', phase: 'closing' },
] as const

export const AI_RECS = [
  { id: 'R1', propertyId: 'P001', title: 'List price reduction ready', conf: 87, kind: 'price' },
  { id: 'R2', propertyId: 'P005', title: 'Multiple-offer analysis (H&B)', conf: 81, kind: 'offer' },
  { id: 'R3', propertyId: 'P004', title: 'Investor follow-up drafted', conf: 94, kind: 'mail' },
  { id: 'R4', propertyId: 'P003', title: 'Reduction case started', conf: 76, kind: 'price' },
  { id: 'R5', propertyId: 'P002', title: 'Pre-marketing checklist gaps', conf: 90, kind: 'check' },
] as const

// Portfolio-wide scope (all AMs) for the scope switch
export const ALL_SCOPE = { total: 2759, exceptions: 412, actions: 168, approvals: 121, avgDom: 63, closed: 1, ams: 14 }

// Aging buckets per phase for the Portfolio skyline
export const AGING_BUCKETS = ['0–15 d', '16–30 d', '31–60 d', '61–90 d', '90+ d']
export const AGING: Record<Exclude<Phase, 'sold'>, number[]> = {
  pre: [31, 27, 18, 8, 4],
  on: [12, 19, 26, 14, 8],
  contract: [9, 11, 7, 3, 1],
  closing: [5, 6, 4, 1, 1],
}
