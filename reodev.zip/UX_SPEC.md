# REO Control Tower — Asset Manager UX Spec (POC v0.1)

Sources: *Connect on REO Control Tower* transcript (2 Nov 2026), *Asset Manager REO Lifecycle* (end-to-end HTML), *Enhancement Requirements & Wireframes* (JIRA stories REOCT-UX/AI/AUTO/GOV/DQ), current My Dashboard and Executive Dashboard screenshots.

---

## 1. What is wrong with the current screens

| Observation (current My Dashboard) | Why it hurts the Asset Manager | Fix in this POC |
|---|---|---|
| Opens with KPI cards (Total Assets 2,759, Open Exceptions 30,047), many showing "N/A" or "Target · Not available" | It's built for reporting, not for doing work. A number with no path to act is noise. | The first screen is **Today**: six exception signals, each with a batch action. KPIs shrink to a single orientation strip. |
| "Properties Requiring Attention 7,864" of "6,785 active" | Counts are bigger than their base, so people stop trusting the screen (REOCT-DQ-01). | Every count is a set of properties you can drill into, and every KPI says how it's defined, its source and its as-of time. |
| Title shown as a 4th pipeline phase | Properties get counted twice. | Title is shown as a **parallel track** alongside Under Contract and Closing. |
| Service Providers Risk shows "28 pending · 9 red flags" | Generic red flags don't give a reason, an owner or a next step. | Every item shows the **reason, days vs SLA, owner, and a next-best action button**. |
| Action Center sits below the fold, under charts | The work you need to act on is the furthest away. | The work comes first and the charts come later (Portfolio page). |
| Exceptions are found through once-a-day or once-a-week reports | The transcript says this costs about 2 days per file. | A live command center: items go back into Exceptions as soon as a follow-up point passes. |

## 2. Experience principles

1. **Exceptions first.** If there's no exception, the property is probably moving. The front page calls out every exception (an AM with ~200 files typically has 20–40).
2. **Big, bold signals.** Six signals cover the critical peaks. If the AM manages these, the steps in between take care of themselves.
3. **Few clicks, batch by default.** Repetitive communication is templated: "Here are your 10 files. Send?" → **Send**. That turns 40 minutes of gathering data and writing into a 2-minute review.
4. **Separate actions that advance a property from admin.** Accepting offers and starting contracts move properties toward closing and get top billing. Drafting a CMP saves time but doesn't move the property.
5. **Humans decide; the system prepares.** Every write is explicit, shows the changed fields, re-checks for stale data and is attributed to the user's Equator session (REOCT-GOV-01).
6. **Explain everything.** Recommendations show supporting and contrary signals, the deterministic calculation, the rule version, source freshness, missing data and risks (REOCT-AI-04).

## 3. Information architecture

```
Today (Command center)      ← landing: 1 exceptions → 2 ready to advance → 3 track
My Work                     ← full queue: Exceptions · Actions Ready · Approvals Waiting · Watchlist
Properties  → Property Cockpit   (stage strip, occupancy filter, status chips)
Offers                      ← every live offer: execute today · needs decision · with investor
Investor follow-ups         ← requests with investors, nudge schedule, log response
Awaiting response           ← what was sent, to whom, expected by, countdown
Recommendations → Recommendation Review → Approval Package
AI Agents                   ← agent catalog, eligibility/blockers, live activity (not on Today)
Portfolio                   ← analytics: Your book, aging, velocity, KPI definitions
```
Global: ⌘K command palette (property / loan # / action), a **client filter** (All clients, SPS, FirstKey, Onity/PHH, Calibr, NRZ/Newrez) that scopes every view, scope switch **My Properties ↔ All Properties**, and light/dark mode.

## 4. Today: the Asset Manager's command center

Updated after the Nov 4 meeting with the manager and an asset manager. Today follows the meeting's three steps, **exception → recommended resolution → action button**, and drops everything that isn't work (Your book moved to Portfolio; the agent section was removed; the property journey view is deferred).

1. **Orient: compact hero.** "Good morning, Srini" and one sentence: *"42 exceptions and 13 decisions are waiting. Every one has a recommended resolution ready. The top 15 take about 60 minutes."* On the right, one **first-hour goal ring**: the share of the work open at the start of the day (exceptions + decisions + offers) that has been cleared since, with a tick at Mason's 90% target and "N more to reach 90%". It counts real progress only and follows the client filter. Under the hero, **stage cards** (Intake → Closing, 10 stages) show files per stage plus what can be acted on there (exceptions, decisions ready). Clicking a card filters both Exceptions and Ready to advance and scrolls to the first with work; stages with nothing to act on are greyed out.
2. **Act Today.** Investor approvals already in hand (accept or counter), unchanged.
3. **Exceptions.** One header row (title and count on the left; Top 15 · By type · All and a Sort menu on the right). The **top 15** by severity (or "most days over"), with **By type** and **All** views. Each row shows the exception, property, days over SLA (business days), the **recommended resolution**, whether it *moves the file forward* or *saves admin time*, the agent that prepared it, and a one-word action button. Tick rows for **bulk resolve**. (First-hour progress lives in the hero ring.)
4. **Review drawer** (one item or many). Three-step strip, the recommendation with its facts, guideline ID, confidence and evidence count, an editable decision value, Equator fields to complete in place when Equator rejected a task, the **market data picker**, and the message (To, Cc, Subject, body) from the catalog template. Footer: **Approve & send**, Snooze (1 BD / 2 BD / next week), Open property, Reject. Nothing is sent without the AM's approval.
5. **Ready to advance.** Decisions that move files forward (offer recommendation, reduction case, values to agree, ready to list, marketing plan, Equator task to complete) and ones that save admin time (Triple R bids, closing review, route an occupancy result). Groups with more than one item get **Review all N**.
6. **Follow-ups and offers.** Three cards into the tracking pages: Awaiting response, Investor follow-ups and Live offers. Anything without a reply by its date returns to Exceptions on its own.

The exception catalog (`exceptions.docx`, 19 types in the POC) drives thresholds, recurrence, owner, recommended resolution and template. Examples: trash-out 15 BD then every 2 BD; no value 7 BD; investor response 2 BD then daily; reduction 25 days since the last price change; closing review 3 BD; valuation order every 75 days.

### Click paths (target ≤ 3 clicks to a governed action)
| Task | Path | Clicks |
|---|---|---|
| Resolve one exception | Today row → **Approve & send** in the drawer | 2 |
| Bulk resolve several exceptions | Tick rows → **Review & approve N** → **Approve & send N** | 3 |
| Send today's investor nudges | Investor follow-ups → **Review & send N** → Approve | 2 |
| Chase 10 stalled trash-outs | By type → tile → **Send 10** | 2 |
| Accept an investor-approved offer | Act Today → **Accept & send contract** → Confirm | 2 |
| Set a reserve price Equator rejected | Ready to advance → Equator task → fill 2 fields → **Approve** | 2 |
| Approve a price reduction | Exception row → pick market points → **Approve & send** | 3 |
| Investigate one exception | Queue row (panel opens) → Open property | 1–2 |

## 5. Other screens in the POC
- **Property Cockpit:** facts header, 10-step lifecycle stepper with dates, phase checklist, open tasks, AI recommendation, system and vendor status with last sync, communications, key dates, and Previous/Next through the current queue.
- **Recommendation Review:** recommended price, a confidence ring, the approval route, market (MSA) vs property signals, why the recommendation was made, the deterministic calculation, a scenario comparison, sources and freshness, missing data, and risks. **Modify** lets you change the price live, with a check against the investor rule. **Approve & Submit** first shows a field diff and a stale-data check.
- **Approval Package:** recipients, the approval route, a Day 3 / 5 / 7 escalation cadence, an editable draft, attached evidence, and a Draft → Sent → Viewed → Approved → Written to Equator timeline.
- **AI Agents:** the 7 agents, each with its mode (Shadow / Supervised), eligible / exception / blocker counts, an "Advances property" vs "Saves admin time" tag, and a live activity feed.
- **Portfolio:** **Your book** (2D columns by phase, moved from Today), a 3D aging chart (phase × age bucket) with a table toggle, velocity tiles, and KPI definitions with source and as-of time.
- **Properties:** the stage strip, an occupancy filter, status chips (All · Overdue · Action today · Ready · Check-in due · Waiting · On track) and columns for stage, days, SLA status, next action, agent, investor and occupancy, and value / list.
- **Offers:** best offer, % of list, % of reserve, agent recommendation and confidence, and status (approved: execute today · needs decision · with investor N BD).
- **Investor follow-ups:** outstanding, oldest, due today and approved today; per request: submitted, days, nudges sent, next due; Review nudge and Log response (approved · declined · more info).
- **Awaiting response:** what was sent, to whom, sent, expected by and a countdown; Log response and Resend; "Simulate next business day" to show items coming back.

## 6. Design system — Apple HIG translated for the web
- **Type:** the system font (SF Pro on macOS). Large Title 34/41 at −0.022em, Title2 22, Headline 15 semibold, Body 14, Caption 12. Tracking depends on size, and tabular figures are used only in table columns.
- **Color:** Apple system colors with separate light and dark values. Blue #007AFF/#0A84FF is the accent, red marks exceptions, green means ready, orange means warning. Status color always comes with an icon and a label.
- **Materials:** the sidebar and toolbar use translucent vibrancy (backdrop blur and saturate), with a scroll-edge blur instead of hard dividers. Modal tasks get a dimming scrim; side panels don't.
- **Motion:** springs everywhere, using critical damping (bounce 0, ~0.4 s) by default. A small bounce is used only for momentum gestures. Animations can be interrupted, and press feedback happens on pointer-down. Sheets open and close from the element that triggered them. Scroll reveals use Framer Motion `whileInView`, and the hero parallax uses `useScroll`. `prefers-reduced-motion` switches to cross-fades and freezes the 3D drift.
- **3D (Three.js / R3F):** used where depth carries meaning (portfolio shape, flow, aging), always alongside exact numbers on hover and a table fallback. Dense work (queues, forms, emails) stays as crisp 2D.

## 7. Status vocabulary
Ready · Review Required · Blocked · Waiting External · Approval Pending · Completed · Failed. A precise reason always replaces a generic "red flag".

## 8. Open questions to validate with AMs
- Are the thresholds (5/10-day value, 15-day trash-out, 30-day DOM, 3-day investor) the same for every investor, or configured per client?
- Which batch communications can be sent straight from Control Tower in supervised mode, and which still need Outlook or Equator?
- Ranking: should a high-dollar offer at risk outrank a low-value property that's 20 days into a trash-out?
- Which Executive Dashboard content stays on Today and which moves to Portfolio?

## 9. Market-aware Recommendation Agents (leadership feedback, Nov 2026)

**Goal:** recommendations are data-driven and market-aware. They combine market/MSA trends with property-specific performance, judge whether a requested action is reasonable *even when valuations support a higher price*, and explain which signals drove the conclusion.

**Decision types covered** (each opens the same Recommendation Review layout: `/rec/:id?type=…`)
| Decision | Type | Agent |
|---|---|---|
| List price reduction approval | `list` | Review Marketing Plan |
| Reserve price reduction approval | `reserve` | Set Reserve Price |
| Marketing plan / plan amendment approval | `plan` | Review Marketing Plan (CMP drafts the original plan) |
| Buyer contract approval | `contract` | Offer Acceptance |
| Similar decisions (counter, H&B, relist) | shown as alternatives / scenarios | — |

**Signals evaluated**
- *Market / MSA (optionally REO-only):* for-sale inventory; contract fallout rate; listings with price reductions (count **and** %); average sale price vs list price (% **and** $); median days on market.
- *Property:* first list date; number of bidders; number of bids; days on market; previous highest offer. The current valuation is shown as an explicit contrary signal when it points higher.

**How the agent decides and explains**
1. **Geography and period:** the agent uses the most relevant geography with enough sample (ZIP → MSA → State, minimum 30 closed sales) over the last 30 days vs the prior 30. Fallbacks are disclosed ("Fell back from ZIP (n=9)"). Users can switch to 90 days, other geographies, or REO-only comparisons.
2. **Every signal is tagged** *Supports / Contrary / Neutral* for this specific action, with an influence weight and a one-line reason. Clicking any signal shows its reason and data availability.
3. **Verdict:** *Supported / Partially supported / Not supported by current market conditions*, with "N of M signals support", and an explicit note when the valuation says otherwise.
4. **"Why this recommendation"** ranks the strongest supporting and contrary signals.
5. **The deterministic calculation** (price, net-to-seller, % of valuation) stays in code. The narrative can't override it.
6. **The investor-ready brief** gives consistent, professional wording for customers. It's reused as the approval-package email body.

**Data inputs: available vs to source** (also shown in-app on Recommendation Review and AI Agents)
| Input | Status | Source / gap |
|---|---|---|
| For-sale inventory | Needs sourcing | Market/MSA provider not yet selected; needs ZIP + MSA, weekly refresh, licensed for automated decision support |
| Contract fallout rate | Needs sourcing | Market/MSA provider |
| Listings with price reductions (count & %) | Needs sourcing | Provider or MLS aggregates (access and licensing not confirmed) |
| Sale price vs list price (% and $) | Partial | Own REO closings in Equator today; market-wide needs provider/MLS |
| Market days on market | Needs sourcing | Market/MSA provider |
| REO-segment market trends | Needs sourcing | Few providers flag REO; could be derived from portfolio history (small samples) |
| First list date | Available | Equator / Hubzu (validate relists and fallen contracts) |
| Number of bidders | Available | Hubzu bid instances (confirm aggregation per submitter) |
| Number of bids | Available | Hubzu / Equator (decide treatment of backup and held bids) |
| Property days on market | Available | Derived from first list date |
| Previous highest offer | Available | Equator offers / Hubzu |
| Hubzu views, watchers, showings | Partial | Hubzu analytics API coverage to validate |
| Valuations (BPO, appraisal) | Available | Equator / SAMS (authoritative SPS source to confirm) |
| Investor rules & delegated authority | Available | Versioned rulebook |

All market values in the POC are **sample data**, labelled as such in the UI, until a provider is selected. Recommendations snapshot the market values they used, so history stays reproducible.


## 10. Resolution workflows (Nov 4 meeting)

**System purpose.** An intelligence-driven resolution capability that sits beyond Equator: it finds the gap, recommends the fix and lets the AM act in one place. The goal is about **70% more capacity and 70% faster throughput** per AM.

| Meeting ask | Where it lives |
|---|---|
| Home page in 3 steps: exceptions → recommended resolution → action button | Today exception rows and the review drawer's 3-step strip |
| Top 15 exceptions with recommended resolutions, bulk resolve | Today Exceptions (Top 15 · By type · All), row checkboxes, **Review & approve N** |
| Show both admin exceptions and advancement tasks | "Saves admin time" vs "Moves file forward" on every row; Ready to advance |
| Market data as selectable bullet points; summary generated from the picked ones | Market picker in the drawer and on Recommendation Review (Supports / Cuts against; generate summary) |
| Simple follow-up email for a missing value | No-value and valuation exceptions use a short BPO vendor template |
| Nudges in one centralized queue | Investor follow-ups page (plus Awaiting response for vendors) |
| Complete tasks such as set reserve price inside Control Tower, even when Equator reports missing fields | "Equator task to complete": the missing fields are filled in the drawer and written back |
| Filter by client (e.g. FirstKey) | Client filter in the header; scopes Today, My Work, Properties, tracking pages and Your book |
| Remove the agent section from the command center | Removed from Today; AI Agents stays in the sidebar |
| Property journey view | Deferred (not in this POC) |
