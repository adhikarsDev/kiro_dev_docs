# REO Control Tower: Asset Manager POC · Demo Script

**Audience:** CEO, CTO, VP / Directors, Asset Management SMEs · **Length:** ~25 minutes plus Q&A
**Presenter persona:** Srini, an Asset Manager with a 236-file SPS book, starting the day on Monday, Nov 3.

---

## 0. Local demo setup

**One-time setup (on any machine)**
1. Install **Node.js 22 LTS** (or 20.19+). Check with `node -v`.
2. Copy the project folder **without** `node_modules/` (zip it or use git).
3. In the project folder, run:
   ```bash
   npm install
   ```

**Start the demo**
```bash
npm run dev
```
Open **http://localhost:5180** in Chrome.

**Presenter tips**
- Use Chrome, full screen, with the window **at least 1440 px wide**. The layout adapts to smaller screens, but the hero looks best wide.
- Start in **light mode**. Show dark mode near the end with the moon/sun icon in the header.
- **Reload the page to reset all demo data.** Everything is in memory, so every action (sending follow-ups, accepting offers) starts fresh on reload. Do a quick dry run, then reload before presenting.
- Alternative designs we explored are in `design-options/` if anyone asks "what else did you try?".
- Port 5180 is set in `vite.config.ts`. Change it there if it's taken.

---

## 1. Demo at a glance

| # | Segment | Time | What the audience should take away |
|---|---|---|---|
| 1 | The problem | 2 min | Today's screens report on work; they don't help AMs do it. |
| 2 | Design principles | 1 min | Exceptions first, batch by default, humans decide. |
| 3 | Today: Orient | 3 min | In 5 seconds Srini knows her day and her book. |
| 4 | Today: Act Today + Exceptions | 5 min | Two clicks clear 10 stalled files. Same-day offers can't be missed. |
| 5 | Today: Queue + Action Center | 3 min | Every item says why, how late, and what to do next. |
| 6 | My Work + Property Cockpit | 3 min | One organized queue; one place for everything about a property. |
| 7 | Market-aware Recommendations | 5 min | Leadership's ask: evidence-backed, explainable, customer-ready. |
| 8 | Approval Package + AI Agents | 2 min | Approvals tracked to closure; agents as a visible automation team. |
| 9 | Portfolio, polish and next steps | 1 min | Analytics moved off the home page; what's real vs sample. |

---

## 2. The problem (no clicks; talk over the old screenshots if you have them)

**Say:**
> "We started by listening to practical asset managers. Mason put it simply: *'What we do is manage the exceptions. If there's not an exception, it's probably moving.'* Today an AM with a couple of hundred files has 20 to 40 exceptions on any day. They find them through exception reports that run once a day, and some only once a week. That costs about **two days per file** before anyone even notices the gap."

**What was wrong with the current My Dashboard:**
- **It reported on work instead of helping AMs do it.** It opened with KPI cards like *Total Assets 2,759* and *Open Exceptions 30,047*, and nothing on them told an AM what to do next.
- **There was a lot of noise.** Many tiles read *"Target · Not available"* or *N/A*.
- **The numbers didn't add up.** *"Properties requiring attention: 7,864"* was shown against *"6,785 active."* When counts don't add up, users stop trusting the screen.
- **Title was double-counted** as a fourth pipeline phase, when it actually runs in parallel with contract and closing.
- **Generic red flags.** *"29 pending · 9 red flags"* gave no reason, owner or next step.
- **The work was buried.** The Action Center sat at the bottom of the page, below the charts.
- **Communication was manual.** Gathering data and writing an investor request took about **40 minutes**. Mason's target is **2 minutes**: review the draft and send.

---

## 3. Design principles (one slide or one sentence each)

1. **Exceptions first.** The first screen calls out every exception, using **six big, bold signals** that map to the transcript's peaks.
2. **Batch by default.** *"Here are your 10 files. Send?"* Yes, and it's done and tracked.
3. **Separate work that advances a property from admin.** Accepting offers and starting contracts get top billing.
4. **Humans decide, the system prepares.** Every write shows its changes, re-checks the facts, and runs in the user's own Equator session.
5. **Explain everything.** Every recommendation shows its signals, calculation, rule version, data sources and gaps.
6. **Apple-grade craft.** System fonts, calm pastel accents, spring motion, translucent materials, light and dark mode, and support for reduced motion.

---

## 4. Walkthrough

### 4.1 Today: the landing page (Orient)

**Show:** Land on **Today**. Pause for 3 seconds. Don't click yet.

**Say:**
> "This is what Srini sees when she logs in. One greeting and one sentence: **39 files need attention, 3 offers are ready to move, and with batch follow-ups that's about 55 minutes of work.** No wall of KPIs."

**Today's progress (the rings):**
> "On the right are Apple-style activity rings for her day: exceptions cleared, offers moved and decisions made. They fill as she works, which gives her a sense of finishing rather than an endless list."

**Your book (the column chart):**
> "Below is her whole book of 236 properties by lifecycle phase. Each column's height is the number of properties. The **coral cap** is the share that needs attention: 24 in Pre-Marketing, 12 On-Market and 3 in Closing. Title isn't shown as a fake phase. The bracket under Contract and Closing shows **24 files running in parallel**, which fixes the double-counting in the old pipeline."

**Show:** Hover a column (the others dim). **Click On-Market.** The page scrolls to the queue, filtered to On-Market.
> "Every chart drills into the exact list behind it, so the counts always reconcile."

**Header (say it in passing):**
> "Search anything with ⌘K. Switch between **My Properties** and **All 2,759**. One refresh button, light and dark mode, and a single profile menu that also holds notifications."

**Show (optional):** Press ⌘K, type "Maple", press Enter (opens the property), then go back.

---

### 4.2 AI recommendations + Market pulse

**Show:** Scroll to the two cards under the hero.

**Say:**
> "We moved the AI recommendations and market pulse up, because these are what change Srini's decisions today. Each recommendation shows a confidence score and opens the full evidence. The Market pulse shows the five MSA signals leadership asked for, each with its trend."

---

### 4.3 Act Today (same-day investor approvals)

**Show:** The **Act today** card.

**Say:**
> "Mason was explicit: *as soon as the investor approves a counter or acceptance, it must be top priority on the screen.* This is that list. Three approvals are in hand, laid out as a clean table: property, investor decision, offer, and one action button."

**Show:** Click **Accept & send contract** on *7890 Spruce Dr, Tampa*.
> "Before anything is written, the system shows exactly what will change, re-checks the facts, and runs it in Srini's own Equator session: accept the offer, send the contract through DocuSign, open closing tasks, and order title."

**Show:** Click **Accept & send contract** in the sheet. The row slides out, a toast appears with **Undo**, and the "Offers moved today" ring fills.

---

### 4.4 Clear your exceptions (the six signals)

**Show:** Scroll to **Step 1 · Problem assets**.

**Say:**
> "These are the six signals from the operating model, live with no 48-hour report delay:
> - Trash-outs not complete after **15 days**
> - No valuation after **10 days** (with a warning at 5)
> - Investor response pending **3+ days**, followed up daily
> - **30+ days on market** with no accepted offer
> - Occupied properties not routed to eviction
> - Closings at risk
>
> Each tile shows the count, the oldest file, and a small aging chart. Hover a bar to see which property it is."

**Show:** On **Trash-outs not complete (10)**, click **Review & send 10 follow-ups**.
> "This is Mason's exact request: *'Here are the 10 files in this category. Are you good for us to send communication on all of these to Triple R?'* The email is templated per client and investor, the merge fields are filled in, and each property gets its own tracked thread."

**Show:** Click **Send 10 follow-ups**. Watch the checkmarks cascade, then the toast.
> "Done. That was two clicks. The tile turns green, the files move to the Watchlist with a 72-hour re-check, and if Triple R doesn't respond they **come back automatically**. Look at the hero: the ring moved from 6 to 16 cleared, and Pre-Marketing's coral cap shrank from 24 to 14. And Undo is always one click away."

---

### 4.5 Work the queue + Action Center

**Show:** Scroll to **Step 2 · Actionables**. The compact queue shows Property, Why, Days and Next best action.

**Say:**
> "This is the same queue as My Work, trimmed for the home page. Each row answers three questions: **why** it needs attention, **how late** it is against its SLA, and **what to do next**, with the button labelled with that exact action."

**Show:** Click a row. The **Action Center** panel slides in from the right without hiding the queue.
> "The detail opens beside the queue so Srini never loses her place. It shows why attention is needed, SLA versus target, the status of each source system (Equator, Triple R, AFS, BPO, Hubzu, ResWare), task history, missing data, and the AI's recommended next step with its reasoning."

**Show:** Press **↓** twice to move through items, then **Esc**.
> "She can work through it from the keyboard: arrows to move, Esc to close. Assign, Snooze and Open property are all here."

---

### 4.6 My Work (the full queue)

**Show:** Click **My Work** in the sidebar.

**Say:**
> "My Work is the full working list. The title appears once, and the toolbar is in two rows:
> - **Top row:** the queue tabs (Exceptions, Actions Ready, Approvals Waiting, Watchlist) and search. Press **/** to jump to search.
> - **Second row:** the phase filters and *Sorted by urgency*. Hover the ⓘ and it explains the ranking, so there are no opaque scores."

**Show:** Type "Cedar" in search, then clear it. Tick two rows and the **bulk bar** rises from the bottom. Use the **pagination** at the bottom.
> "She can select several rows to batch a follow-up, snooze or reassign. Pagination and rows-per-page keep it fast."

---

### 4.7 Property Cockpit

**Show:** From a row, click **Open property**, or open *1234 Maple Grove Dr*.

**Say:**
> "Everything about one property, in one place, so she doesn't switch between Equator, Hubzu and email:
> - A 3D model of the house: windows glow when it's occupied, and the beacon colour shows its status.
> - The 10-step lifecycle with dates, plus days in inventory, list price and highest offer.
> - The phase checklist, open tasks, the AI recommendation, system sync status, recent communications and key dates.
>
> Previous and Next move through her queue."

---

### 4.8 Recommendations: market-aware (leadership's recommendation)

**Show:** Click **Recommendations** in the sidebar.

**Say:**
> "This answers leadership's request directly: agents' recommendations should be **data-driven and market-aware**. They cover marketing plans and amendments, reserve price reductions, list price reductions, buyer contract approvals and similar decisions. On the left is everything the agents have prepared, filtered by Pricing, Offers & contracts, or Plans. On the right is a preview with a verdict on whether the market supports it."

**Show:** Click a few cards: **Buyer contract approval**, **Reserve price reduction**, **Multiple-offer analysis**. Point at the price ladder and the offer net-to-seller bars.

**Show:** Open **List price reduction · 1234 Maple Grove Dr**, then **Review & decide**. Walk top to bottom:

1. **Verdict banner.**
   > "*Supported by current market conditions: 9 of 11 signals support it.* It also says plainly that **the valuation of $404,000 points higher**, but the market evidence outweighs it. That's exactly the case leadership described: valuations may support a higher price, but the market doesn't."
2. **Recommendation, confidence and route.**
   > "$425,000 to $399,000, which is −6.1%, with 87% confidence. The approval route comes from the investor rules."

   **Show:** Click **Modify** and drag to **$404,000 (−4.9%)**.
   > "Watch the route change live. It's now within Srini's own authority, and the button says *Approve & write to Equator*. Above 5% it routes to SPS, and above 8% it needs a management exception."
3. **Market & property evidence.**
   > "These are the signals leadership listed. On the market side: inventory, contract fallout, price reductions as **count and %**, and sale-to-list as **% and dollars**. On the property side: first list date, bidders, bids, days on market and previous highest offer. Each one is tagged **Supports, Contrary or Neutral**, with an influence bar. Click any row for the reason."

   **Show:** Click **MSA / State**, then **REO only**, then **90 days**.
   > "It uses **the most relevant geography with enough sales**. This ZIP had only 9 sales, so it fell back to the MSA and says so. Leadership asked for REO trends where available, so here's REO-only: 38 sales in the MSA."
4. **Why this recommendation.**
   > "The strongest supporting signals and the contrary ones, ranked."
5. **Deterministic calculation.**
   > "The numbers are rule-based and computed in code. The AI narrative can't change them."
6. **Investor-ready brief.**
   > "A consistent, professional write-up for the customer. Leadership asked us to professionalise how we deliver recommendations, so this becomes the email to the investor."
7. **Data inputs: available vs to source.**
   > "We also answered *'which inputs do we have and which do we need?'*:
   > - **Available today:** first list date, bidders, bids, property days on market, highest offer, valuations and investor rules.
   > - **Partial:** sale-to-list, which we have from our own REO closings, and Hubzu views.
   > - **Needs sourcing:** inventory, fallout, reductions, market days on market and REO trends. These depend on choosing a market data provider. Until then, the market numbers here are **sample data**, and the screen says so."

**Show (optional):** Go back, open **Buyer contract approval → Review & decide**.
> "Same evidence model, different decision. It shows the contract terms, net to seller against the valuation and market sale-to-list, and the alternatives it considered."

---

### 4.9 Approval Package

**Show:** On the list price recommendation, click **Approve & send to SPS**, or **Route for approval**.

**Say:**
> "The approval package is ready: recipients, the approval route, a target response date, and the Day 3 / Day 5 / Day 7 escalation cadence from the operating model. The email body is the investor-ready brief, so customers see the same evidence. Five evidence files are attached."

**Show:** Click **Send for approval**. The timeline moves Draft → Sent.
> "From here it's tracked through Sent, Viewed, Approved and Written to Equator. If SPS goes quiet, the day-3 reminder is already drafted, and the item returns to Exceptions automatically."

---

### 4.10 AI Agents

**Show:** Click **AI Agents**.

**Say:**
> "We present the agents as Srini's automation team. The headline is what they're worth: **43 hours saved this week, 89 recommendations, 85% accepted as drafted.** Each card shows its mode: Shadow observes, Supervised queues the action for her review. Market-aware agents carry a badge. Each card also shows properties in scope, the acceptance rate, ready versus exceptions versus blocked, and hours saved."

**Show:** Hover a card (glow edge), hover ⓘ (description), click **Run agent → pick a property**. Watch the live activity feed move it through Queued, Analyzing and Ready for review.

**Show:** Scroll to the bottom: **What the agents use, and what we still need to source.**
> "The same data-availability table, for the product and data teams."

---

### 4.11 Portfolio

**Show:** Click **Portfolio**. Drag the 3D aging chart, then switch to **Table**.

**Say:**
> "The executive analytics moved here so the home page stays about the work. Aging by phase is in 3D with an exact-numbers table, alongside velocity trends. **Every metric has a definition, a source and an as-of time**, and dashboard counts reconcile to the drill-down lists."

---

### 4.12 Polish and close

**Show:** Toggle **dark mode** from the header. Scroll to the footer.

**Say:**
> "It follows Apple's design guidelines throughout: system type, calm pastels, spring motion that can be interrupted, light and dark modes, and reduced-motion support. To recap the shift: from reporting dashboards to a daily command center. Exceptions first, actions in two clicks, recommendations backed by market evidence, and every decision explained and audited."

---

## 5. Leadership recommendations: where each one lives

| Leadership ask | Where in the POC |
|---|---|
| Market-aware recommendations for marketing plan / amendment approvals | Recommendations → *Marketing plan amendment* → Review (`?type=plan`) |
| …reserve price reduction approvals | Recommendations → *Reserve price reduction* (`?type=reserve`) |
| …list price reduction approvals | Recommendations → *List price reduction* (`?type=list`) |
| …buyer contract approvals | Recommendations → *Buyer contract approval* (`?type=contract`) |
| …other similar decisions | Offer analysis (H&B), counter / relist / hold as scenarios and alternatives |
| MSA signals: inventory, fallout, reductions (count & %), sale-to-list (% & $), DOM | Evidence table on every Recommendation Review; Market pulse on Today |
| REO-segment trends where available | **REO only** toggle in the evidence controls |
| Property signals: first list date, bidders, bids, DOM, previous highest offer | Property performance table |
| Most relevant geography and an appropriate recent period | ZIP → MSA → State with fallback disclosed; 30 or 90 days vs prior |
| Judge reasonableness even when valuations support higher | Verdict banner; valuation shown as an explicit contrary signal |
| Explain which signals influenced the conclusion and why | Supports / Contrary / Neutral tags, influence bars, per-signal reasons, "Why this recommendation" |
| Transparent, consistent, professional delivery to customers | Investor-ready brief, reused as the approval-package email |
| Identify inputs available vs to be sourced | Data inputs table (Recommendation Review, AI Agents, `UX_SPEC.md` §9) |

---

## 6. Before → after

| Before | After |
|---|---|
| KPI wall with 30,047 exceptions and "N/A" tiles | One sentence: 39 files, 3 offers, ~55 minutes |
| Exceptions found by daily or weekly reports (~2-day lag) | Six live signals; files return automatically when follow-ups lapse |
| 40 minutes to gather data and write an email | Two clicks: review the templated batch and send |
| Generic red flags | Reason, days vs SLA, owner and next best action on every item |
| Title counted as a phase | Title shown as a parallel track |
| Counts that don't reconcile | Every number drills into its exact list, with definitions and sources |
| Recommendations without context | Market-aware evidence, a verdict, a deterministic calculation and a customer brief |
| Agents as a hidden back end | A visible automation team showing hours saved and acceptance rates |

---

## 7. What's real vs sample, and next steps

- **Sample data.** All properties, people and numbers are mock data for one AM book. Market values are **sample data** until a market/MSA provider is selected. The UI labels them that way.
- **Not connected yet.** No live integrations with Equator, Hubzu, ResWare, Triple R or DocuSign. The flows show the intended supervised behaviour.
- **Next steps:**
  1. Select a market data provider and confirm licensing.
  2. Validate thresholds per investor (5/10-day valuation, 15-day trash-out, 30 DOM, 3-day investor).
  3. Confirm which actions can be written back in supervised mode.
  4. Run usability sessions with 3–5 AMs.

## 8. Likely questions

- **"Can the AI change a price on its own?"** No. Autonomous mode is off. Every write needs explicit confirmation, shows the changed fields and re-checks the facts first.
- **"Where does the market data come from?"** The POC uses sample data. The table shows exactly which inputs need a provider, and recommendations store the market snapshot they used.
- **"What if the ZIP has too few sales?"** The agent falls back to MSA, then State, and tells the user.
- **"Are the thresholds fixed?"** No. They're configurable per client and investor. The POC uses the values from the operating-model transcript.
- **"How many clicks to clear a category of exceptions?"** Two: open the signal, then send.
