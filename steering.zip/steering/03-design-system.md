# 03 · Design system (Apple HIG, translated for the web)

Source skill: `skills/apple-design/SKILL.md` (read it for the reasoning). Implementation: `src/styles/index.css`.

## Principles to apply on every change
- **Purpose and simplicity.** Every element earns its place. Show the common path first and keep advanced options one level deeper. Simple doesn't mean minimal: a small amount of added context (a reason, an SLA) can make a screen simpler to use.
- **Hierarchy comes from order, weight and spacing,** not from more colour. There is one primary action per surface.
- **Familiarity.** Things that look the same behave the same: segmented controls, chips, pills and sheets work identically everywhere.
- **Feedback.** Respond on press (`:active` scale 0.97). Show status, completion, warnings and errors. Offer Undo instead of a confirmation, except for real writes, which get a confirm sheet.
- **Wayfinding.** Every screen answers: where am I, what's here, where can I go, and how do I get back.

## Typography (system font, size-specific tracking)
| Class | Size / line height / weight | Tracking |
|---|---|---|
| `.t-large` | 34 / 1.12 / 700 (greeting 40) | −0.026em |
| `.t-title1` | 28 / 1.15 / 700 | −0.022em |
| `.t-title2` | 22 / 1.2 / 650 | −0.02em |
| `.t-title3` | 18 / 1.25 / 600 | −0.016em |
| `.t-headline` | 15 / 1.33 / 600 | −0.012em |
| body | 14 / 1.45 | −0.006em |
| `.t-sub` 13, `.t-caption` 12, `.t-eyebrow` 11.5 caps 0.06em | | |

Big numbers use `var(--font-round)` (SF Pro Rounded) at weight 700–750 with negative tracking. Use tabular figures (`.num`) only in columns that need to line up.

## Colour tokens (light / dark both defined; never hard-code)
- **Surfaces.**
  - `--bg` #f5f5f7 / #000
  - `--elev` #fff / #1c1c1e
  - `--elev-2`, `--elev-3`
  - fills `--fill`, `--fill-2`, `--fill-3`
  - separators `--separator`, `--separator-strong`
- **Text.** `--label`, `--label-2`, `--label-3`, `--label-4`.
- **System accents** (Apple): `--blue` is primary, plus `--red`, `--orange`, `--yellow`, `--green`, `--teal`, `--indigo`, `--purple`, each with a darker `-text` variant for text.
- **Pastel identity palette** (calm accents, the product owner's choice):
  - `--rose`, `--peach`, `--lavender`, `--sky`, `--mint`, `--sand`, each with a `-text` variant
  - signal tiles: trash-out = peach, valuation = sky, investor = lavender, reduction = rose, eviction = sand, closing = mint
- **Progress rings:** `--ring-1` (rose-red), `--ring-2` (green), `--ring-3` (blue). Brighter than the pastels, so the rings read as active.
- **Phase colours (charts):** `--ph-pre` lavender, `--ph-on` sky, `--ph-contract` peach, `--ph-closing` mint, `--ph-sold` gray, plus `--att` coral for "needs attention".
- **Tone system.** Any element can take `data-tone="…"` (system, pastel, `ring1`–`ring3` or `ph-*`) and then use `var(--tone)` / `var(--tone-text)` / `var(--tone-bg)` / `var(--tone-bg-2)`.
- **Status colour never stands alone.** Pair it with an icon or a label.

## Materials and depth
- **Chrome is translucent.** The sidebar, toolbar, Action Center panel, palette, menus, bulk bar and action bar use `backdrop-filter: blur(24–40px) saturate(180%)` over semi-transparent `--material` / `--material-thick`.
- **Content is opaque.** Cards are `--elev` with `--shadow-2`, at radius 18–30 (`--r-l` 18, `--r-xl` 24, `--r-2xl` 30).
- **Modal tasks** (batch sheet, confirm sheet, palette) get a scrim. **Parallel work** (the Action Center panel) has no scrim.
- **Scroll edges.** The toolbar gets a hairline that fades in on scroll instead of a permanent border.
- **Accessibility.** `prefers-reduced-transparency` makes materials solid, and `prefers-contrast: more` adds borders.

## Component vocabulary (reuse these classes)
- **Buttons.** `.btn` is a capsule with modifiers:
  - `-primary`, `-tinted`, `-gray`, `-plain`, `-danger`, `-tone` (pastel), `-glass`
  - sizes `-sm` and `-lg`
- **Labels and selectors.**
  - `.pill` (with `data-tone`; `.pill-dot` adds a dot)
  - `.seg` / `Segmented` (sliding thumb via `layoutId`)
  - `.chip` / `.chip.on`
  - `.kbd`
- **Surfaces and containers.**
  - `.card`, `.card-pad`, `.card-h`, `.inset`, `.callout[data-tone]`
  - `.verdict` (recommendation verdict)
  - `.sheet` / `.sheet-wrap` / `.scrim`, `.panel`, `.toast`, `.menu`
- **Queues and timelines.**
  - `.qrow` / `.qcols` (`.compact` on Today)
  - `.pager`, `.q-search`, `.sort-note`
  - `.timeline` / `.tl-item`, `.stepper`
- **Effects and specials.**
  - `.spot-card` / `SpotlightCard`: pointer spotlight, edge glow and optional spring tilt (after React Bits SpotlightCard / TiltedCard)
  - `.agent2` (agent card): `.glass-icon` (after React Bits GlassIcons), and a conic shine border on hover (after 21st.dev Shine Border / React Bits BorderGlow)
  - `.signal` (exception tile), `.act-today` / `.act-table` (pastel Act Today table with equal-width `.act-btn`)
  - `.vc` ("Your book" columns), `.hero2`
- **Empty and loading states.** Show one sentence on what will appear and when (`.empty`). Never leave a blank card.

## Layout
- **Grid.** Use the 12-column grid `.grid.g-12` with `span-*`; `r-full` stacks a column under 1360 or 1180 px.
- **Sidebar** is 252 px, collapsing to a 76 px icon rail under 1180 px.
- **Content** is capped at 1560 px, with 28 px top and 36 px side padding.
- **The header** holds: search (⌘K), the My Properties / All scope switch, an icon-only refresh, the theme toggle, and a single-line profile (avatar with notification badge, then name, then chevron; the menu holds profile and notifications).
- **The footer** shows only the brand, Portfolio analytics, Help, Privacy and ©.
