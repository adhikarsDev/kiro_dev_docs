// Ask Claude (via the Claude API) to make a change, with the steering docs as a cached system prompt.
//
// Setup once:   npm install -D @anthropic-ai/sdk      and set ANTHROPIC_API_KEY
// Build context: npm run steering                     (or: npm run steering -- --with-skills)
// Use:          node steering/ask-claude.mjs "Make the Act Today rows denser" src/features/today.tsx src/styles/index.css
//
// Prints Claude's answer (full files or diffs + "How to verify") to stdout. Review it, then apply the changes yourself.
import fs from 'node:fs'
import path from 'node:path'
import { fileURLToPath } from 'node:url'

const here = path.dirname(fileURLToPath(import.meta.url))
const root = path.resolve(here, '..')
const [task, ...files] = process.argv.slice(2)
if (!task) {
  console.error('Usage: node steering/ask-claude.mjs "<what to change>" <file> [file...]')
  process.exit(1)
}

let Anthropic
try { ({ default: Anthropic } = await import('@anthropic-ai/sdk')) } catch {
  console.error('Install the SDK first:  npm install -D @anthropic-ai/sdk')
  process.exit(1)
}

const full = path.join(here, 'dist', 'context-full.md')
const small = path.join(here, 'dist', 'context.md')
const contextPath = fs.existsSync(full) ? full : small
if (!fs.existsSync(contextPath)) { console.error('Run `npm run steering` first.'); process.exit(1) }
const context = fs.readFileSync(contextPath, 'utf8')

const fileBlocks = files.map((f) => `<file path="${f}">\n${fs.readFileSync(path.join(root, f), 'utf8')}\n</file>`).join('\n\n')

const client = new Anthropic() // reads ANTHROPIC_API_KEY from the environment
const stream = client.beta.messages.stream({
  model: 'claude-opus-5-5',
  max_tokens: 64000,
  thinking: { type: 'adaptive' },
  output_config: { effort: 'high' },
  // If the primary model declines, the API retries on a fallback model in the same call.
  betas: ['server-side-fallback-2026-07-01'],
  fallbacks: 'default',
  // Steering docs are stable, so cache them: repeated requests read them at a fraction of the cost.
  system: [{ type: 'text', text: context, cache_control: { type: 'ephemeral', ttl: '1h' } }],
  messages: [{ role: 'user', content: `${fileBlocks}\n\n<task>\n${task}\n</task>` }],
})
stream.on('text', (t) => process.stdout.write(t))
const msg = await stream.finalMessage()
process.stdout.write('\n')
if (msg.stop_reason === 'refusal') console.error('\n[Claude declined this request]', msg.stop_details?.explanation ?? '')
if (msg.stop_reason === 'max_tokens') console.error('\n[Output hit max_tokens; ask for fewer files at a time]')
console.error(`\n[tokens] input ${msg.usage.input_tokens} · cache read ${msg.usage.cache_read_input_tokens ?? 0} · cache write ${msg.usage.cache_creation_input_tokens ?? 0} · output ${msg.usage.output_tokens}`)
