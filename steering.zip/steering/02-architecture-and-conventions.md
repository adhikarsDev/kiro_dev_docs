# 02 · Architecture and code conventions

## Layout
```
src/
  main.tsx              entry (React StrictMode intentionally OFF, see Three.js rules)
  App.tsx               shell: Sidebar, Toolbar, routed page (AnimatePresence), Footer, global sheets/panel/palette/toasts, error boundary
  styles/index.css      THE stylesheet: tokens (light + dark), components, utilities. No CSS modules, no Tailwind.
  data/
    mock.ts             deterministic seeded portfolio (PROPERTIES), work items (INITIAL_ITEMS), SIGNALS + email templates, MARKET, SYSTEMS, AGENTS
    rec.ts              recommendation math: recFor(p), tierFor(pct), routeFor(tier), AM_AUTHORITY 5%, INVESTOR_CAP 8%, RULE_VERSION
    market.ts           market-aware evidence: geography/segment/period data, resolveGeo(), evidenceFor(type,…), DECISIONS, DATA_INPUTS
  lib/
    store.ts            zustand useApp (items, queueTab, phaseFilter, selectedId, batch, confirm, toasts with undo, theme, scope, recDecision…)
    router.ts           tiny hash router: parse(), navigate(), useRoute(), per-path scroll restoration; query string in hash (?type=)
    motion.ts           spring presets + variants (spring, springSnappy, springSheet, fadeUp, stagger, inView)
  components/
    ui.tsx              primitives: AnimatedNumber, Segmented, Sparkline, PhasePill, RiskPill, Check, Stepper, ConfidenceRing, DayRings, SpotlightCard, SectionHead
    chrome.tsx          Sidebar, Toolbar (search, scope, refresh, theme, ProfileMenu with notifications), CommandPalette (⌘K), Toaster, AppFooter
  features/
    actions.ts          performAction(item, origin): ONE place that maps a work item's next action to its flow
    BatchSheet.tsx      templated batch follow-up (opens from the clicked tile)
    ConfirmSheet.tsx    confirm-before-write (diff, steps, Equator session)
    WorkQueue.tsx       queue (compact on Today, full on My Work: search, SortNote, Pager, bulk bar)
    WorkItemPanel.tsx   Action Center side panel (non-modal, ↑/↓/Esc)
    context.ts          per-item "why / sources / missing / next / history"
    today.tsx           ActToday, SignalBoard, right-rail cards
    evidence.tsx        VerdictBanner, MarketEvidence, Influences, CustomerBrief, briefText(), DataReadiness
    book/Bars.tsx       "Your book" vertical columns; book/types.ts
  three/
    HouseModel.tsx      low-poly property model (cockpit)
    AgingSkyline.tsx    3D aging bars (portfolio)
    overlay.tsx         Projector: projects 3D anchors to a DOM label overlay
  pages/                Today, lists (MyWork, Properties), PropertyCockpit, Recommendations, Recommendation, Approval, Agents, Portfolio
```

## Conventions
- **TypeScript strict.** Run `npm run typecheck` before you hand off.
- **Styling.** Use class names from `index.css` plus small inline `style` values for one-offs. Colour always comes from a token or the **tone system** (`data-tone="mint"` sets `--tone`, `--tone-text`, `--tone-bg` and `--tone-bg-2` on that element and its children).
- **State (zustand v5).** Never return a new array or object from a selector: `useApp(s => s.items.filter(...))` loops forever. Select the raw value, then `useMemo`.
- **Actions.** Every "next action" button calls `performAction(item, originOf(e))`. Writes go through `openConfirm`. Batches go through `openBatch`. Moves use `moveItems(ids, queue, patch)`, which **returns an undo function**, so pass it to `toast({ undo })`.
- **Exit animations.** Components inside `AnimatePresence` must **snapshot** their data on mount (`useState(() => store.getState().x)`), because the store clears it while the exit animation is still running.
- **Routing.** Use `navigate('/rec/P001?type=contract')`. To add a page: add it to the `Route` union, `parse()` and `Page()` in `App.tsx`, `TITLES`, and the sidebar NAV if it's top-level.
- **Copy.** Use specific verbs on buttons ("Send 10 follow-ups", "Accept & send contract"), sentence case, and no exclamation marks.

## Three.js rules (learned the hard way)
- **Labels.** Use the `Projector` overlay (`three/overlay.tsx`) and **not** drei `<Html>`. drei's per-label React roots race under React 19 and blank out labels.
- **Animated `InstancedMesh`.** Set `frustumCulled={false}`, or call `computeBoundingSphere()` after moving instances.
- **Custom shaders.** Create the `ShaderMaterial` yourself in `useMemo` and pass `material={…}`, so per-frame uniform writes hit the object the GPU is reading.
- **Animate on time, not frames.** Cap `dt` at about 0.25 s.
- **Pause off-screen.** Use `frameloop={visible ? 'always' : 'never'}` with `useInView`.
- **Reduced motion.** Under `prefers-reduced-motion`, settle immediately with no drift.
- **Fallback.** Every 3D chart has exact numbers on hover and a table fallback.

## How to add things
- **A new signal tile.** Add it to `SIGNALS` (title, threshold, CTA, template) in `mock.ts`, generate its work items in `buildItems()`, add its icon and tone in `BatchSheet.tsx` (`SIGNAL_ICON`, `SIGNAL_TONE`, which uses pastel tones), and add context in `context.ts`.
- **A new decision type.** Add it to `DecisionType`/`DECISIONS` in `market.ts`, give it signal weights and reasons in `evidenceFor`, add a proposal, diff and calculation in `pages/Recommendation.tsx`, and add a `Kind` entry in `pages/Recommendations.tsx`.
- **A new data input.** Add it to `DATA_INPUTS` with status `available | partial | sourcing`.
