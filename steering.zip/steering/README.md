# Steering docs (for working on this project with the Claude API, without Claude Code)

## Skills used to build this UI/UX
| Skill | Role in this project | Copy in this folder |
|---|---|---|
| **apple-design** | Apple HIG for the web: type scale, materials, springs, interruptibility, reduced motion, design principles | `skills/apple-design/SKILL.md` (original) |
| **motion-framer** | Framer Motion patterns: variants, `AnimatePresence`, `layoutId`, `whileInView`, gestures, springs | `skills/motion-framer/SKILL.md` (original) |
| **dataviz** | Chart method: form, colour by job, palette validation, marks, hover layer, accessibility | `skills/dataviz/references/*` + `scripts/validate_palette.js` (the main SKILL.md ships with Claude Code; it is summarized in `05-data-visualization.md`) |
| built-in-browser | Tooling only, used to preview the app; not needed for steering | — |
| claude-api | Tooling only, used to write `ask-claude.mjs` correctly | — |

Design references (websites, not skills): **React Bits** (SpotlightCard, TiltedCard, GlassIcons, MagicBento / BorderGlow, AnimatedList) and **21st.dev** (Shine Border), each re-implemented in-house in `src/components/ui.tsx` and `src/styles/index.css`.

## Files
- `SYSTEM_PROMPT.md`: role, way of working and non-negotiables. Send this first.
- `01`–`07`: project context, architecture and conventions, design system, motion, dataviz, market-aware agents, decision log.
- `skills/`: original skill files, for deeper reference.

## Using it with the Claude API
1. Build one context file:
   - `npm run steering` → `steering/dist/context.md` (project steering only)
   - `npm run steering -- --with-skills` → `context-full.md` (adds the original skills)
2. Send it as the **system prompt**, with `cache_control`, so repeat requests are cheap. Put the task and the relevant source files in the user message.
3. Or use the helper:
   - one time: `npm install -D @anthropic-ai/sdk` and set `ANTHROPIC_API_KEY`
   - then: `node steering/ask-claude.mjs "<change>" src/path/File.tsx src/styles/index.css`
4. Always include `src/styles/index.css` plus the files you want changed. Claude returns full files or diffs and a "How to verify" list.
5. After a design decision, append it to `07-decision-log.md` so future edits respect it.
