// Combines the steering docs into one file you can paste or send as a Claude API system prompt.
//   node steering/build-context.mjs              → steering/dist/context.md        (project steering only, ~small)
//   node steering/build-context.mjs --with-skills → steering/dist/context-full.md  (+ original skill files)
import fs from 'node:fs'
import path from 'node:path'
import { fileURLToPath } from 'node:url'

const here = path.dirname(fileURLToPath(import.meta.url))
const withSkills = process.argv.includes('--with-skills')
const read = (p) => fs.readFileSync(path.join(here, p), 'utf8').trim()

const parts = [
  read('SYSTEM_PROMPT.md'),
  ...['01-project-context.md', '02-architecture-and-conventions.md', '03-design-system.md', '04-motion-and-interaction.md',
    '05-data-visualization.md', '06-market-aware-agents.md', '07-decision-log.md'].map(read),
]
if (withSkills) {
  const skillFiles = [
    'skills/apple-design/SKILL.md',
    'skills/motion-framer/SKILL.md',
    ...fs.readdirSync(path.join(here, 'skills/dataviz/references')).sort().map((f) => `skills/dataviz/references/${f}`),
  ]
  for (const f of skillFiles) parts.push(`<skill_reference path="${f}">\n${read(f)}\n</skill_reference>`)
}

fs.mkdirSync(path.join(here, 'dist'), { recursive: true })
const out = path.join(here, 'dist', withSkills ? 'context-full.md' : 'context.md')
const text = parts.join('\n\n---\n\n') + '\n'
fs.writeFileSync(out, text)
console.log(`Wrote ${path.relative(process.cwd(), out)} (${(text.length / 1024).toFixed(1)} KB, ~${Math.round(text.length / 4).toLocaleString()} tokens)`)
