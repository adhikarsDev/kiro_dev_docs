# 06 · Market-aware Recommendation Agents (leadership requirement)

**The ask (CEO / CTO / VP):** agent recommendations should be **data-driven and market-aware**. They should combine market/MSA trends (and REO-segment trends where available) with property-specific performance. They should judge whether a requested action is reasonable **even when valuations support a higher price**, and explain which signals influenced the conclusion and why. They should also professionalize how recommendations reach customers, and identify which inputs are available and which must still be sourced.

## Decisions covered (one review layout: `pages/Recommendation.tsx`, `#/rec/:id?type=`)
`list` list price reduction · `reserve` reserve price reduction · `plan` marketing plan amendment · `contract` buyer contract approval. Similar decisions (counter, H&B, relist, hold) appear as scenarios or alternatives.

## Signals (`data/market.ts → evidenceFor`)
- **Market:**
  - for-sale inventory
  - contract fallout rate
  - listings with price reductions (**count and %**)
  - sale price vs list price (**% and $**)
  - median days on market
- **Property:**
  - first list date
  - number of bidders
  - number of bids
  - days on market (vs similar listings)
  - previous highest offer
- **The current valuation** is always shown as a contrary signal when it points higher.

## Rules the evidence engine follows
1. **Geography and period.** Pick the most relevant geography with enough sample: ZIP → MSA → State, with at least 30 closed sales (`MIN_SAMPLE`). Disclose any fallback. Default to the last 30 days vs the prior 30. The user can switch to 90 days, another geography, or **REO only**.
2. **Read each signal for this specific action.** Tag it `supports | contrary | neutral`, give it a weight from 0 to 1 and a one-line `why`, and record its availability.
3. **Verdict.** Score = weighted (supports − contrary) ÷ total weight. Above 0.35 is **Supported**, above 0 is **Partially supported**, otherwise **Not supported**. Always state "N of M signals support".
4. **Keep the money and authority maths deterministic in code.** The narrative never overrides it. Authority: AM up to 5%, investor 5–8%, management exception above the 8% / 28-day cap.
5. **Investor-ready brief.** `briefText()` gives consistent wording: the recommendation, market context, property performance, the valuation caveat and the rule version. It's reused as the Approval Package email body.
6. **Snapshot the market values** used for each recommendation, so history stays reproducible.

## UI pieces (`features/evidence.tsx`)
- `VerdictBanner`
- `MarketEvidence`: geography, segment and period controls, plus two `SignalTable`s with influence bars and expandable reasons
- `Influences`: the strongest supporting and contrary signals
- `CustomerBrief`: editable, with Copy and "Use in approval package"
- `DataReadiness`: grouped table with Available / Partial / Needs sourcing pills

## Data availability (`DATA_INPUTS`)
- **Available:** first list date, bidders, bids, property DOM, previous highest offer, valuations, investor rules.
- **Partial:** sale-to-list (own REO closings only), Hubzu views and showings.
- **Needs sourcing** (market provider not selected): inventory, fallout, reductions, market DOM, REO-segment trends.

**All market numbers are sample data** and must stay labelled that way ("Sample market data", "provider not yet selected") until a licensed provider is integrated.
