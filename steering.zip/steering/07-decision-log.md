# 07 · Decision log (product owner feedback; don't regress these)

| # | Area | Decision | Rejected alternatives / why |
|---|---|---|---|
| 1 | Today hero text | One greeting ("Good morning, **Srini**") plus one sentence (files, offers, minutes) and two buttons. | A 6-number KPI grid and long tooltips read as clutter and duplicated numbers. |
| 2 | Today's progress | **Circular activity rings**, brighter `ring1`–`ring3` colours, dark legend text so it feels active. | Pale pastel rings looked disabled. Linear meters and scorecards were offered, but the owner kept circles. |
| 3 | "Your book" | **2D vertical columns**: phase colours, a coral hatched attention cap, the count on top, phase and attention below, a Title bracket. | 3D spheres ("physics experiment"), a 3D ribbon ("snail/worm"), glossy 3D bars, a 3D donut (too many circles next to the rings), pipeline cards, a bento treemap and a storage strip (**no cards in this panel**). |
| 4 | Colour mood | **Pastel, calm, blended with white.** Signal tiles each have their own pastel identity and numbers in ink. | Vibrant gradients and all-red signal tiles were too harsh. |
| 5 | Act Today | Pastel card. One header (title, an "N investor approvals in hand" pill, one sentence), then an aligned table (Property, Investor decision, Offer) with **equal-width** action buttons and a chevron for details. | Split headers left and right, plus zig-zag buttons of different widths. |
| 6 | Today order | Hero → **AI recommendations + Market pulse** → Act Today → six signals → compact queue with Key dates and Systems. | Recommendations and market pulse buried at the bottom of the right rail. |
| 7 | Today queue | **Compact columns** (Property, Why, Days, Next action) with no overflow. My Work shows every column. | A full-width table overflowing on the home page. |
| 8 | My Work | Title once. Row 1: tabs + search (`/`). Row 2: phase chips + "Sorted by urgency ⓘ". **Pagination** with rows-per-page. Bulk bar on selection. | A duplicated "My Work" title and scattered filters. |
| 9 | Header | Icon-only refresh (no "Last refresh" text). **Single-line profile** (avatar with badge, then name), with **notifications inside the profile menu**. No separate bell. | A name and role stacked on two lines looked cluttered. |
| 10 | Footer | Brand, Portfolio analytics, Help, Privacy, ©. | "N of 7 systems current…" status and a Shortcuts link were removed. |
| 11 | Recommendations | **Side-by-side**: animated list on the left, spotlight and tilt preview on the right with a verdict and a type-specific visual. | A grid of text-only cards. |
| 12 | AI Agents | **Rich cards**: aura header, glass icon, shine border on hover, properties in scope, an acceptance ring, a ready / exceptions / blocked bar, hours saved, Run agent. Descriptions sit behind a ⓘ hover. A summary strip sits on top. | Plain cards with patchy numbers and long descriptions. The owner called the result "outstanding". |
| 13 | Portfolio | 3D aging with a Table toggle, velocity tiles, metric definitions. Approved as is. | — |
| 14 | Market data | Labelled **sample data, provider not yet selected**. | Naming a specific vendor implied a contract that doesn't exist. |
| 15 | Process | For hero visuals, **show screenshots of 2–3 options and get approval before applying**. Option screenshots are kept in `design-options/`. | — |
