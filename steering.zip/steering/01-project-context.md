# 01 · Project context

## Who it's for
**Asset Managers** with roughly 200–250 REO files each (the persona is "Srini", with an SPS book of 236 files). Each day they log in, find what's stuck, take the decisions that move properties forward, and chase vendors and investors.

## What practical AMs told us (Connect on REO Control Tower, Nov 2 2026)
- *"What we do is manage the exceptions."* On any day an AM has **20–40 exceptions**. Exception reports run once a day, some once a week, which costs about **2 days per file**.
- The first screen should show **every exception**, built around **big, bold signals**:
  - no valuation by 10 days (warn at 5)
  - no trash-out by 15 days
  - 30+ days on market with no accepted offer, so process a reduction
  - an investor response pending 3+ days, followed up daily
  - occupied properties routed to eviction (ESD), with a weekly check-in
  - closings at risk
- **Batch the boilerplate.** *"Here are the 10 files… send to Triple R? Click yes."* Track the replies, and re-surface a file if it isn't resolved.
- **The second window is actionables:** offers to accept, trash-out bids to approve. When an **investor approves an accept or counter**, it becomes the top priority, *"in bright bold letters."*
- Templates make investor messaging consistent: 40 minutes of drafting becomes a 2-minute review.
- Separate the agents that **advance a property** (offer acceptance) from those that only save admin time (CMP).

## Lifecycle (REO)
Foreclosure → Boarding → Occupancy → Initial Services → Valuation → Marketing → Offers → Contract → Closing → Sold.
Dashboard phases: **Pre-Marketing, On-Market, Under Contract, Closing, Sold (30 days)**. **Title is a parallel track**, never a phase.

## Systems
- **Equator** (the system of record; writes go through the user's own session)
- **Hubzu** (listings, auctions, bids)
- **Palladium / AFS** (field services)
- **Triple R** (occupancy, trash-out)
- **ResWare** (title and closing, read-only)
- **SAMS** (valuations)
- **DocuSign**
- the versioned investor rulebook

## Glossary
- **AM**: Asset Manager.
- **BPO**: broker price opinion (a valuation).
- **CMP / RMP**: complete / review marketing plan.
- **DOM**: days on market.
- **ESD**: the eviction team ("Pam's team").
- **H&B**: highest and best.
- **SLA**: the expected turnaround for a step.
- **SPS, Onity/PHH, Calibr, NRZ/Newrez**: investors and clients.
- **Shadow / Supervised**: agent modes. Shadow observes and recommends only. Supervised queues the exact action for human review. Autonomous is off.

## Daily loop (from the enhancement spec)
Orient → Prioritize → Understand → Decide → Act → Track. Unresolved work returns to Exceptions automatically when its follow-up point passes.

## Screens
| Route | Page | Purpose |
|---|---|---|
| `#/` | Today | Hero (greeting, progress rings, "Your book" columns) → AI recommendations + Market pulse → Act Today → six signals → compact queue + key dates + systems |
| `#/work` | My Work | The full queue: tabs, search, phase filters, sort explanation, pagination, bulk actions |
| `#/properties`, `#/property/:id` | Properties, Property Cockpit | List, then a single-property view (3D house, lifecycle, checklist, tasks, recommendation, systems, comms, dates) |
| `#/recs`, `#/rec/:id?type=` | Recommendations, Recommendation Review | Side-by-side list and preview; full market-aware review for `list`, `reserve`, `plan` and `contract` |
| `#/approval/:id?type=` | Approval Package | Recipients, route, escalation cadence, brief-based email, evidence, timeline |
| `#/agents` | AI Agents | Agent cards, live activity, audit, data-availability table |
| `#/portfolio` | Portfolio | 3D aging chart with a table toggle, velocity, metric definitions |

Source documents: `UX_SPEC.md` (full spec), `DEMO_SCRIPT.md` (presenter script).
