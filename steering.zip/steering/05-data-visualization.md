# 05 · Data visualization

Source skill: **dataviz** (bundled with Claude Code). Its reference files are copied to `skills/dataviz/references/`, and its palette validator to `skills/dataviz/scripts/validate_palette.js` (`node validate_palette.js "#hex,#hex" --mode light`). The skill's main SKILL.md is not a local file, so the core procedure is summarized here in our own words.

## Procedure (in order; colour comes last)
1. **Pick the form from the data's job.** Is it a magnitude, an identity, a polarity, a single headline (stat tile or hero number) or change over time? Sometimes the answer is not a chart.
2. **Assign colour by job.**
   - **Categorical (identity):** fixed hue order, never cycled.
   - **Sequential (magnitude):** one hue, light to dark (the Portfolio aging chart uses one blue ramp).
   - **Diverging:** two hues with a neutral midpoint.
   - **Status:** reserved, and always paired with an icon or label.
3. **Validate the palette** with the script rather than by eye: colour-blind separation, contrast, and lightness band, in light **and** dark.
4. **Marks.**
   - Thin marks with ~4 px rounded data ends anchored to the baseline.
   - 2 px lines, markers ≥ 8 px, and a 2 px surface gap between adjacent fills.
   - Recessive gridlines (dashed, `--separator-strong`).
   - Selective direct labels, never a number on every point.
5. **Hover layer by default.** Hit targets are bigger than the marks. Line and area charts get a crosshair and tooltip; bars and columns get per-mark hover. Filters sit in one row above the chart.
6. **Accessibility.**
   - A legend whenever there are two or more series. Up to four series are also direct-labelled.
   - Text uses text tokens, never the series colour.
   - A table view exists, and dark mode is designed rather than auto-flipped.
7. **Render it and look at it** for label collisions and overflow in both themes.

## Non-negotiables
- **No dual-axis charts.**
- **Colour follows the entity, not its rank.** A filter must not repaint the survivors.
- **Never a rainbow.**
- **3D is only for depth that carries meaning.** It always comes with exact numbers and a table fallback.

## Project chart inventory
| Chart | Where | Encoding |
|---|---|---|
| Today's progress rings | Today hero | 3 concentric rings (`ring1`–`ring3`), done ÷ total; the legend repeats the values as text |
| **"Your book" columns** | Today hero (`features/book/Bars.tsx`) | One rounded column per phase (`--ph-*`), height = properties, **coral hatched cap = needs attention**, a Title bracket under Contract and Closing, dashed gridlines with a 0–100 axis, hover dims the others, click filters My Work |
| Signal aging strips | Signal tiles | One bar per file, height = days, dashed SLA threshold line, hover names the file |
| Sparklines | Market pulse, velocity, evidence | 2 px line plus a soft area, end dot, tone red when the trend is bad |
| Price ladder | Recommendations preview | A track with markers (highest offer, MSA median, valuation, current, recommended); the reduction range is a gradient |
| Offer bars | Offers preview | Horizontal net-to-seller bars, best offer in mint |
| Evidence influence bars | Recommendation Review | Weight 0–1, tone by reading (mint supports, peach contrary, gray neutral) |
| 3D aging chart | Portfolio (`three/AgingSkyline.tsx`) | Phases × age buckets, one-hue blue sequential ramp, hover tooltip, **Table toggle** |
| Property model | Property Cockpit (`three/HouseModel.tsx`) | Windows glow when occupied; the beacon colour is the status |
