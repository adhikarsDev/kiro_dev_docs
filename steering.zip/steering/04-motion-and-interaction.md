# 04 · Motion and interaction

Source skills: `skills/apple-design/SKILL.md` (fluid interfaces, springs, interruptibility) and `skills/motion-framer/SKILL.md` (Framer Motion API). Presets live in `src/lib/motion.ts`.

## Spring presets (use these, don't invent new ones)
| Preset | Value | Use for |
|---|---|---|
| `spring` | `{type:'spring', bounce:0, duration:0.4}` | The default for layout, reveals and state changes |
| `springSnappy` | bounce 0, 0.28 s | Thumbs, toggles, small UI |
| `springSheet` | bounce 0.12, 0.42 s | Sheets, panels and popovers arriving |
| `springSoft` | bounce 0, 0.7 s | Large, slow reveals |
| `fadeUp` / `stagger(s, d)` | opacity, y 18 and blur 6 → 0 | Scroll reveals with `whileInView` and `viewport={inView}` (once, 20%) |

## Rules
- **Critically damped by default.** Add bounce only when a gesture carried momentum (a flick or a drag release).
- **Interruptible.** Never lock input during an animation. Animate transform and opacity, not layout properties, except where `layout` / `layoutId` is intended (segmented thumbs, the selected recommendation, the active nav).
- **Spatial consistency.** Sheets and confirms open **from the element that triggered them** and return there (we pass `origin` from `originOf(e)`). The panel slides in from the right and leaves to the right. Popovers scale from their anchor (`transformOrigin`).
- **Press feedback on pointer-down.** Use `whileTap={{ scale: 0.97 }}` (0.95 on small buttons).
- **Numbers.** Use `AnimatedNumber`, which springs from the value currently on screen, so updates count rather than jump.
- **Lists.** Use `AnimatePresence initial={false} mode="popLayout"` with `layout="position"`. Rows that leave exit sideways (x: 60) and fade.
- **Page transitions.** Use `AnimatePresence mode="wait"` with a fast exit (0.14 s) and a spring entry with a slight blur.
- **Scroll-linked effects.** `useScroll` + `useTransform` drive the hero copy parallax and the chart scale. Keep them subtle (≤ 50 px, ≤ 4% scale).
- **No perpetual motion** on data visuals. Auto-rotate is off, and the live dots pulse only on "live" status.
- **Reduced motion.** `MotionConfig reducedMotion="user"` is set globally. 3D scenes settle instantly, and pulsing stops.

## Keyboard
- **⌘K** opens the command palette.
- **/** focuses the queue search; **Esc** clears it.
- **↑ / ↓** (or **j / k**) move through items in the Action Center panel; **Esc** closes it.
- **↑ / ↓** also move through the Recommendations list.
- **Enter** activates a focused row.

## Interaction patterns to keep
- **Batch by default.** A signal tile opens a review sheet, then **Send N follow-ups**. A cascade of checkmarks plays, the tile turns "All clear", a toast offers **Undo**, and the files move to the Watchlist with a re-check timer.
- **Confirm before write.** The sheet shows a field diff and numbered steps (re-check facts, write to Equator, and so on), the action runs in the user's Equator session, and a receipt toast follows.
- **Non-modal detail.** The Action Center panel sits beside the queue, so the user keeps their place.
- **Hover dims the rest.** On charts, hovering highlights one series and dims the others to about 38% opacity.
